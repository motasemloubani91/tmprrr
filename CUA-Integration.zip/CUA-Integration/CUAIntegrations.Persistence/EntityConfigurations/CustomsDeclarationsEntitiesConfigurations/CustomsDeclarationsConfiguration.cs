﻿using CUAIntegrations.Kernel.Domain.Entities.CustomsDeclarationsEntities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace CUAIntegrations.Persistence.EntityConfigurations.CustomsDeclarationsEntitiesConfigurations
{
    public class CustomsDeclarationsConfiguration : IEntityTypeConfiguration<CustomsDeclarationsEntities>
    {
        public void Configure(EntityTypeBuilder<CustomsDeclarationsEntities> entity)
        {
            entity.ToTable("GCC_CustomsDeclarations", "GCC");
            entity.HasKey(a => a.Id);
            entity.Property(a => a.Version)
                  .IsRequired()
                  .HasDefaultValue(1);
            entity.Property(a => a.DeclarationNumber).IsRequired().HasMaxLength(100);
            entity.HasIndex(a => a.DeclarationNumber);

            entity.Property(a => a.DeclarationDate).IsRequired();
            entity.Property(a => a.DeclarationType).IsRequired().HasMaxLength(6);
            entity.Property(a => a.PortType).IsRequired().HasMaxLength(6);
            entity.Property(a => a.DeliveryOrderNumber).HasMaxLength(100);

            // Importer / Exporter Info
            entity.Property(a => a.ImporterExporterName).IsRequired().HasMaxLength(100);
            entity.Property(a => a.ImporterExporterCustomsId).IsRequired().HasMaxLength(70);
            entity.Property(a => a.CommercialRegistrationNumber).HasMaxLength(70);
            entity.Property(a => a.TinNumber).HasMaxLength(70);

            // Weights & Measurements
            entity.Property(a => a.NetWeight).IsRequired();
            entity.Property(a => a.GrossWeight).IsRequired();
            entity.Property(a => a.Measurement).IsRequired().HasMaxLength(6);

            // Transport & Logistics
            entity.Property(a => a.CarrierCaptainDriver);
            entity.Property(a => a.CarrierName);
            entity.Property(a => a.IntercessorCompany).HasMaxLength(100);
            entity.Property(a => a.VoyageFlightNumber).HasMaxLength(512);
            entity.Property(a => a.Route).HasMaxLength(512);
            entity.Property(a => a.ExitPort).HasMaxLength(512);

            // Ports & Countries
            entity.Property(a => a.PortOfLoading).HasMaxLength(512);
            entity.Property(a => a.PortOfDischarge).HasMaxLength(512);
            entity.Property(a => a.DestinationCountryCode).HasMaxLength(6);
            entity.Property(a => a.ExportedTo).HasMaxLength(100);

            // Packages & Docs
            entity.Property(a => a.NumberOfPackages);
            entity.Property(a => a.BlAwbManifestNo).HasMaxLength(100);
            entity.Property(a => a.MarksAndNumbers);
            entity.Property(a => a.DueNumber).HasMaxLength(100);
            entity.Property(a => a.UnifiedCustomsCode).HasMaxLength(70);

            // Financial Info
            entity.Property(a => a.TotalDuty).IsRequired();
            entity.Property(a => a.DefiniteFee).IsRequired();
            entity.Property(a => a.Vat);
            entity.Property(a => a.ExciseTax);
            entity.Property(a => a.OtherCharges);
            entity.Property(a => a.Insured);
            entity.Property(a => a.ValuationMethod).HasMaxLength(6);
            // Clearance / Licensing
            entity.Property(a => a.ClearingAgentName).HasMaxLength(100);
            entity.Property(a => a.ClearingAgentCode).HasMaxLength(70);
            entity.Property(a => a.LicenseNumber).HasMaxLength(70);
            entity.Property(a => a.RiskOutcome).HasMaxLength(10);

            // Remarks & Release
            entity.Property(a => a.OtherRemarks).HasMaxLength(512);
            entity.Property(a => a.ReleaseDate).IsRequired();

            entity.HasMany(d => d.Items)
              .WithOne()
              .HasForeignKey(i => i.DeclarationId)
              .OnDelete(DeleteBehavior.Cascade);

            // Payments relation (if one-to-many)
            entity.HasMany(d => d.Payments)
                  .WithOne()
                  .HasForeignKey(p => p.DeclarationId)
                  .OnDelete(DeleteBehavior.Cascade);


        }
    }

}


