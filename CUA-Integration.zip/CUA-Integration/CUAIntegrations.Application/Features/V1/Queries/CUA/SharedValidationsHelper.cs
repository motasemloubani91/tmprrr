﻿using CUAIntegrations.Repository.Base;
using System.Data.Entity;

namespace CUAIntegrations.Application.Features.V1.Queries.CUA
{
    public class SharedValidationsHelper: ISharedValidationHelper
    {
        private readonly ICUAIntegrationUnitOfWork _unitOfWork;

        public SharedValidationsHelper(ICUAIntegrationUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        public bool IsValidDeclarationYear(string year)
        {
            int declarationYear = Convert.ToInt32(year);
            var currentYear = DateTime.Now.Year;
            return currentYear >= declarationYear;
        }

        public async Task<bool> IsValidPortCode (string portCode)
        {
            return await _unitOfWork.PortCodesLookupRepository.Get().Where(p => p.Code == portCode).AnyAsync();
        }
        public async Task<bool> IsValidCountryCode (string countryCode)
        {
            return await _unitOfWork.CountryCodesLookupRepository.Get().Where(p => p.Code == countryCode).AnyAsync();
        }
    }
}
