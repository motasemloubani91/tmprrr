﻿using Microsoft.Data.SqlClient;

namespace CUAIntegrations.Persistence.DataAccess.ADO.NET
{
    public class MockDataRepository
    {
        private readonly string _connectionString;

        public MockDataRepository(string connectionString)
        {
            _connectionString = connectionString;
        }

        public async Task<string> GetMockJsonAsync(int entityId, string entityType)
        {
            string json = null;

            using (var connection = new SqlConnection(_connectionString))
            using (var command = new SqlCommand(@"
                SELECT TOP 1 ResponseJson
                FROM Gcc.GCC_ResponseMockData
                WHERE EntityId = @EntityId AND EntityType = @EntityType
                ORDER BY Id DESC", connection))
            {
                command.Parameters.AddWithValue("@EntityId", entityId);
                command.Parameters.AddWithValue("@EntityType", entityType);

                await connection.OpenAsync();
                var result = await command.ExecuteScalarAsync();
                json = result?.ToString();
            }

            return json;
        }
    }
}
