﻿namespace CUA_GCC_Integration.Core.Helpers
{
    public class RequestHeadersConstants
    {
        public static string X_CORRELATION_ID = "X-CORRELATION-ID";
        public static string X_AppKey = "X-AppKey";
        public static string X_SecretKey = "X-SecretKey";
        public static string X_LOGGING_ID = "X-LOGGING-ID";
        public static string X_REQUEST_ID = "X-request-ID";
        public static string X_Client_ID = "X-Client-ID"; 
        public static string X_Request_Timestamp = "X-Request-Timestamp"; 
        public static string Authorization = "Authorization"; 
    }

    public class ApplicationClientsConstants
    {
        public static string Qatar = "QA";
        public static string SaudiArabia = "SA";
        public static string UnitedArabEmirates = "AE";
        public static string Kuwait = "KW";
        public static string Oman = "OM";
        public static string Bahrain = "BH";
        public static string MC = "MC";
    }
}
