﻿using MediatR;

namespace CUAIntegrations.Application.Features.V1.Commands.CUA.AuthorizationCallBack
{
    public record AuthorizationCallBackCommand(
        string code
    ) : IRequest<bool>;
}
