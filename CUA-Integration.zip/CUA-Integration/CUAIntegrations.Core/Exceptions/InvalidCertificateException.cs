﻿using CUA_GCC_Integration.Core.Exceptions;
using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;
using System.Net;

namespace CUAIntegrations.Kernel.Core.Exceptions
{
    public class InvalidCertificateException : SystemIntegrationException
    {
        const string message = "Authentication failed. Invalid or expired credentials.";
        const string reason = "Certificate Validation Failed";

        public InvalidCertificateException() :
            base(errorCode: HttpStatusCode.Unauthorized,
                message: message,
                reason: reason)
        {
        }

        public InvalidCertificateException(
            string message = message,
            string reason = reason,
            List<ErrorDetail>? details = null) :
            base(errorCode: HttpStatusCode.Unauthorized,
                message: message,
                reason: reason,
                details: details)
        {
        }
    }
}

