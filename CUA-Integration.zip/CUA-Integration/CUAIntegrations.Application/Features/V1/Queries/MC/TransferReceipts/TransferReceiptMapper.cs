﻿using CUAIntegrations.Application.Features.V1.Queries.Mc.TransferReceipts;
using CUAIntegrations.Application.Features.V1.Queries.OutBoundedForMC.TransferReceipts;
using CUAIntegrations.Kernel.Domain.Entities.TransferReceipts;

namespace CUAIntegrations.Kernel.Domain.Dtos.TransferReceipts
{
    public static class TransferReceiptMapper
    {
        // TransferReceipt → TransferReceiptDto
        public static McTransferReceiptDto ToDto(TransferReceipt entity)
        {
            if (entity == null) return null;

            var dto = new McTransferReceiptDto();

            dto.Id = entity.Id;
            dto.Version = entity.Version;
            dto.FileName = entity.FileName;
            dto.ImageUrl = entity.ImageUrl;
            dto.FileDate = entity.FileDate;
            dto.Amount = entity.Amount;
            dto.DueNumber = entity.DueNumber;

            // Convert Entity ListOfDues → DTO List<string>
            dto.ListOfDues = entity.ListOfDues?
                .Select(x => x.DueReference)
                .ToList();

            return dto;
        }

        // TransferReceiptDto → TransferReceipt
        public static TransferReceipt ToEntity(McTransferReceiptDto dto)
        {
            if (dto == null) return null;

            var entity = new TransferReceipt();

            entity.Id = dto.Id;
            entity.Version = dto.Version;
            entity.FileName = dto.FileName;
            entity.ImageUrl = dto.ImageUrl;
            entity.FileDate = dto.FileDate;
            entity.Amount = dto.Amount;
            entity.DueNumber = dto.DueNumber;

            // Convert DTO List<string> → Entity List<TransferReceiptListOfDues>
            entity.ListOfDues = dto.ListOfDues?
              .Select(d => new TransferReceiptListOfDues
              {
                  DueReference = d,
                  TransferReceiptId = dto.Id > 0 ? dto.Id : 1
              })
              .ToList();


            return entity;
        }

        // TransferReceiptListOfDues → TransferReceiptListOfDuesDto
        public static McTransferReceiptListOfDuesDto ToDto(TransferReceiptListOfDues entity)
        {
            if (entity == null) return null;

            var dto = new McTransferReceiptListOfDuesDto();

            dto.Id = entity.Id;
            dto.TransferReceiptId = entity.TransferReceiptId;
            dto.DueReference = entity.DueReference;

            return dto;
        }

        // TransferReceiptListOfDuesDto → TransferReceiptListOfDues
        public static TransferReceiptListOfDues ToEntity(McTransferReceiptListOfDuesDto dto)
        {
            if (dto == null) return null;

            var entity = new TransferReceiptListOfDues();

            entity.Id = dto.Id;
            entity.TransferReceiptId = dto.TransferReceiptId;
            entity.DueReference = dto.DueReference;

            return entity;
        }

        // List mappings
        public static List<McTransferReceiptDto> ToDtoList(List<TransferReceipt> entities)
        {
            if (entities == null) return null;

            var list = entities.Select(ToDto).ToList();
            return list;
        }

        public static List<TransferReceipt> ToEntityList(List<McTransferReceiptDto> dtos)
        {
            if (dtos == null) return null;

            var list = dtos.Select(ToEntity).ToList();
            return list;
        }

        public static List<McTransferReceiptListOfDuesDto> ToDtoList(List<TransferReceiptListOfDues> entities)
        {
            if (entities == null) return null;

            var list = entities.Select(ToDto).ToList();
            return list;
        }

        public static List<TransferReceiptListOfDues> ToEntityList(List<McTransferReceiptListOfDuesDto> dtos)
        {
            if (dtos == null) return null;

            var list = dtos.Select(ToEntity).ToList();
            return list;
        }
    }
}
