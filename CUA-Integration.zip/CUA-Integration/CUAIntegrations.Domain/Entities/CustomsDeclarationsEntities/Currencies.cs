﻿
namespace CUAIntegrations.Kernel.Domain.Entities.CustomsDeclarationsEntities
{

    public class Currencies
    {
        public string Type { get; set; }
        public decimal Value { get; set; }
        public long Id { get; set; }
        public long ItemId { get; set; }

    }
}
