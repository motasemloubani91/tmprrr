﻿

using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using CUAIntegrations.Kernel.Domain.Entities.CustomsDeclarationsEntities;

namespace CUAIntegrations.Persistence.EntityConfigurations.CustomsDeclarationsEntitiesConfigurations
{
    public class RestrictionsConfiguration : IEntityTypeConfiguration<Restrictions>
    {
        public void Configure(EntityTypeBuilder<Restrictions> entity)
        {
            entity.ToTable("GCC_Restrictions", "GCC");
            entity.HasKey(a => a.Id);

            entity.Property(a => a.Agency).IsRequired().HasMaxLength(100);
            entity.Property(a => a.ReleaseRef).HasMaxLength(100);

        }
    }
}
