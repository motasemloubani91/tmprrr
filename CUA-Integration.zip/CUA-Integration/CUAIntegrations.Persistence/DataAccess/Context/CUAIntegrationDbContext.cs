﻿using CUAIntegrations.Kernel.Domain.Entities.CustomsDeclarationsEntities;
using CUAIntegrations.Kernel.Domain.Entities.DueNumbers;
using CUAIntegrations.Kernel.Domain.Entities.ProviderFeedbackEntities;
using CUAIntegrations.Kernel.Domain.Entities.TransferReceipts;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace CUAIntegrations.Persistence.DataAccess.Context
{
    public class CUAIntegrationDbContext : BaseDbContext<CUAIntegrationDbContext>
    {
        public CUAIntegrationDbContext(
            DbContextOptions<CUAIntegrationDbContext> options,
            IHttpContextAccessor httpContextAccessor)
            : base(options, httpContextAccessor)
        {
        }

        // ✅ DbSets
        public DbSet<DueNumber> DueNumbers { get; set; }
        public DbSet<TransferReceipt> TransferReceipts { get; set; }
        public DbSet<CustomsDeclarationsEntities> CustomsDeclarations { get; set; }
        public DbSet<ProviderFeedbackEntity> ProviderFeedbacks { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Register all IEntityTypeConfiguration classes dynamically
            RegisterMappings(modelBuilder);
            base.OnModelCreating(modelBuilder);
        }

        public override int SaveChanges()
        {
            HandleSaveChanges();
            return base.SaveChanges();
        }

        public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            HandleSaveChanges();
            return await base.SaveChangesAsync(cancellationToken);
        }
    }
}
