﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;

namespace CUA_GCC_Integration.Core.Exceptions.BusinessRules
{
    public class DeclarationDoesNotMeetExchangeRequirementsException : Exception
    {
        public int ErrorCode { get; private set; } //mapped to Status property in ErrorResponse
        public string Message { get; private set; } = "The request was rejected because the declaration does not meet the exchange requirements. ";
        public string Reason { get; private set; } = "ValidationError";
        public List<ErrorDetail>? Details { get; set; }

        public DeclarationDoesNotMeetExchangeRequirementsException()
        {
            ErrorCode = 422;
        }
        public DeclarationDoesNotMeetExchangeRequirementsException(List<ErrorDetail>? errorDetails)
        {
            ErrorCode = 422;
            Details = errorDetails;
        }

        protected DeclarationDoesNotMeetExchangeRequirementsException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }
    }

}
