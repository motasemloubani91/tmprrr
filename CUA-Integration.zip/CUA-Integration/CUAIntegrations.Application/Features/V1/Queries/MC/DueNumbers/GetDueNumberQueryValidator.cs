﻿using CUAIntegrations.Application.Features.V1.Queries.CUA;
using FluentValidation;
using System.Text.RegularExpressions;

namespace CUAIntegrations.Application.Features.V1.Queries.OutBoundedForMC.DueNumbers
{
    public class GetDueNumberQueryValidator : AbstractValidator<GetDueNumberQuery>
    {
        private readonly ISharedValidationHelper _validationHelper;

        public GetDueNumberQueryValidator(ISharedValidationHelper validationHelper)
        {
            _validationHelper = validationHelper;

             RuleFor(x => x.DueNumber)
                .NotEmpty()
                .WithErrorCode("ERR-02")
                .WithMessage("The request was rejected because a mandatory field is missing: DueNumber.");

            RuleFor(x => x.DueNumber)
               .Length(65)
               .WithErrorCode("ERR-03")
               .WithMessage("DueNumber must be exactly 65 characters.");

            RuleFor(x => x.DueNumber)
                .Matches("^[A-Za-z0-9]+$")
                .WithErrorCode("ERR-03")
                .WithMessage("DueNumber must be alphanumeric.");

             RuleFor(x => x.FirstExitCountryCode)
                .NotEmpty()
                .WithErrorCode("ERR-02")
                .WithMessage("FirstExitCountryCode is mandatory.");

            RuleFor(x => x.FirstExitCountryCode)
                .Length(2)
                .WithErrorCode("ERR-03")
                .WithMessage("FirstExitCountryCode must be exactly 2 characters.");

            //RuleFor(x => x.FirstExitCountryCode)
            //   .MustAsync(async (value, _) =>
            //   {
            //       return await _validationHelper.IsValidCountryCode(value);
            //   })
            //   .WithErrorCode("ERR-29")
            //   .WithMessage("FirstExitCountryCode must match the reference list.");

        
        }
    }
}
