﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;

namespace CUA_GCC_Integration.Core.Exceptions.ResponseValidation
{
    public class WrongLogicalDateException : Exception
    {
        public int ErrorCode { get; private set; } //mapped to Status property in ErrorResponse
        public string Message { get; private set; } = "Date value is logically invalid (e.g., future date where not allowed). ";
        public string Reason { get; private set; } = "ValidationError";
        public List<ErrorDetail>? Details { get; set; }

        public WrongLogicalDateException()
        {
            ErrorCode = 400;
        }
        public WrongLogicalDateException(string message)
        {
            ErrorCode = 400;
            Message = message;
            Details = new List<ErrorDetail>();
        }
        public WrongLogicalDateException(List<ErrorDetail>? errorDetails)
        {
            ErrorCode = 400;
            Details = errorDetails;
        }

        protected WrongLogicalDateException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }
    }

}
