﻿using CUA_GCC_Integration.Core.Exceptions.DataNotFound;
using CUA_GCC_Integration.Core.Helpers;
using CUAIntegrations.Persistence.DataAccess.ADO.NET;
using MediatR;
using Microsoft.AspNetCore.Http;

namespace CUAIntegrations.Application.Features.V1.Queries.CUA.DownloadDocument
{
    public class DownloadDocumentHandler
        : IRequestHandler<DownloadDocumentQuery, DownloadDocumentResponse>
    {
        private readonly ICUADataAccessDataAccess _dataAccessService;

        private readonly IHttpContextAccessor _httpContextAccessor;
        public DownloadDocumentHandler(
            ICUADataAccessDataAccess dataAccessService,
            IHttpContextAccessor httpContextAccessor)
        {
            _dataAccessService = dataAccessService;
            _httpContextAccessor = httpContextAccessor;
        }
        public async Task<DownloadDocumentResponse> Handle(DownloadDocumentQuery request, CancellationToken cancellationToken)
        {
            var response = new DownloadDocumentResponse()
            {
                SupportingDocumentDetailsEntity = new SupportingDocumentDetailsDTO
                {
                    RelatedDeclarationNumber = request.DeclarationNumber
                }
            };
            var requestingCountryCode = _httpContextAccessor.HttpContext.Request.Headers[RequestHeadersConstants.X_Client_ID].ToString();

            var issuingCountryCode = ApplicationClientsConstants.Kuwait;
            var declarationId = await _dataAccessService.GetDeclarationIdAsync(
                request.DeclarationNumber,
                request.DeclarationType,
                request.Year,
                request.Port,
                issuingCountryCode,
                requestingCountryCode
            );
            if (string.IsNullOrWhiteSpace(declarationId))
                throw new DeclarationNotFoundException();

            //var declarationId = "14190986"; //for test only 
            var docs = await _dataAccessService.GetSupportedDocumentListAsync(declarationId);

            var doc = docs.Documents.FirstOrDefault(a => a.DocumentIdNumber == request.DocumentId);
            if (doc == null)
            {
                throw new NoDocumentFoundException();
            }

            //var fileBytes = await _fileManagementService.DownloadDocumentFile(
            //    documentId: Convert.ToInt32(doc.DocumentIdNumber),
            //    declarationId: Convert.ToInt32(request.DeclarationNumber));

            //if (fileBytes is null)
            //{
            //    //todo: throw the correct exception
            //    throw new NoDocumentFoundException();
            //}

            //// Return successful response
            //response.SupportingDocumentDetailsEntity.DocumentCategory = doc.DocumentCategory;
            //response.SupportingDocumentDetailsEntity.DocumentContent = Convert.ToBase64String(fileBytes);
            //response.SupportingDocumentDetailsEntity.DocumentIdNumber = doc.DocumentIdNumber;
            //response.SupportingDocumentDetailsEntity.DocumentLanguage = doc.DocumentLanguage;
            //response.SupportingDocumentDetailsEntity.DocumentName = doc.DocumentName;
            return response;
        }
    }
}
