﻿using CUAIntegrations.Application.Features.V1.Queries.CUA.TransferReceipts;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace CUAIntegrations.Controllers.V1.Queries.CUA.TransferReceipt
{
    public class TransferReceiptController : BaseCUAController
    {
        private readonly IMediator _mediator;

        public TransferReceiptController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet("{dueNumber}")]
        [ApiVersion("1")]
        public async Task<OutBoundedGetTransferReceiptResponse> GetOutboundTransferReceipt(
                   [FromRoute] string dueNumber)
        {
            var query = new OutBoundedGetTransferReceiptQuery(
                dueNumber
                );

            return await _mediator.Send(query);
        }
    }
}
