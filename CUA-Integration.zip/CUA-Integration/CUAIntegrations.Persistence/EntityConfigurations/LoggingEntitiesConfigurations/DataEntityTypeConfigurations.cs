﻿using CUAIntegrations.Kernel.Domain.Entities.LoggingEntities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace CUAIntegrations.Persistence.EntityConfigurations.LoggingEntitiesConfigurations
{
    public class DataEntityTypeConfigurations : IEntityTypeConfiguration<DataEntityTypes>
    {
        public void Configure(EntityTypeBuilder<DataEntityTypes> entity)
        {
            entity.ToTable("GCC_DataEntityTypes", "GCC");
            entity.HasKey(e => e.DataEntityTypeId);

            entity.Property(e => e.DataEntityTypeId)
                  .ValueGeneratedOnAdd();

            entity.Property(e => e.EntityTypeName)
                  .HasMaxLength(100)
                  .IsRequired();

            entity.Property(e => e.Description)
                  .HasMaxLength(500);

            entity.Property(e => e.TableName)
                  .HasMaxLength(100)
                  .IsRequired();

            entity.Property(e => e.IsActive)
                  .IsRequired();

            entity.Property(e => e.CreatedAt)
                  .IsRequired();
        }
    }
}
