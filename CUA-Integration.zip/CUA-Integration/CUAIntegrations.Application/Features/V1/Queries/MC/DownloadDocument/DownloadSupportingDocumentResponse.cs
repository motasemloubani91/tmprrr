﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;

namespace CUAIntegrations.Application.Features.V1.Queries.Mc.DownloadDocument
{
    public class DownloadSupportingDocumentResponse
    {
        public McSupportingDocumentDetailsDto? SupportingDocumentDetailsEntity { get; set; }
        public ErrorResponse? ErrorResponse { get; set; }
    }

    public class McSupportingDocumentDetailsDto
    {
        public long Id { get; set; }

        public string RelatedDeclarationNumber { get; set; }
        //TODO Lookups  gcc.GCC_DocumentTypesLookup
        public string DocumentCategory { get; set; }
        public string DocumentName { get; set; }
        public string DocumentIdNumber { get; set; }
        //TODO Lookups gcc.GCC_LanguageCodesLookup
        public string? DocumentLanguage { get; set; }
        public string DocumentContent { get; set; }

    }
}
