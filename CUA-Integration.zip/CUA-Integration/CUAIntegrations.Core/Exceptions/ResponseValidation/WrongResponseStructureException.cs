﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CUA_GCC_Integration.Core.Exceptions.ResponseValidation
{
    public class WrongResponseStructureException : Exception
    {
        public int ErrorCode { get; private set; } //mapped to Status property in ErrorResponse
        public string Message { get; private set; } = "The response was rejected because the response structure does not match the required format. ";
        public string Reason { get; private set; } = "ValidationError";
        public List<ErrorDetail>? Details { get; set; }

        public WrongResponseStructureException()
        {
            ErrorCode = 400;
        }
        public WrongResponseStructureException(List<ErrorDetail>? errorDetails)
        {
            ErrorCode = 400;
            Details = errorDetails;
        }

        protected WrongResponseStructureException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }
    }

}
