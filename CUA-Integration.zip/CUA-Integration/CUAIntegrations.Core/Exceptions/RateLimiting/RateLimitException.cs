﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;

namespace CUA_GCC_Integration.Core.Exceptions.RateLimiting
{
    public class RateLimitException : Exception
    {
        public int ErrorCode { get; private set; } //mapped to Status property in ErrorResponse
        public string Message { get; private set; } = "Rate limit exceeded. Too many requests in given time period.";
        public string Reason { get; private set; } = "RateLimitError";
        public List<ErrorDetail>? Details { get; set; }

        public RateLimitException()
        {
            ErrorCode = 429;
        }
        public RateLimitException(List<ErrorDetail>? errorDetails)
        {
            ErrorCode = 429;
            Details = errorDetails;
        }

        protected RateLimitException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }
    }

}
