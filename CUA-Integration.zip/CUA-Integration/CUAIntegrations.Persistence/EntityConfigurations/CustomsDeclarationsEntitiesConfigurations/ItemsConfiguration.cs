﻿using CUAIntegrations.Kernel.Domain.Entities.CustomsDeclarationsEntities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

public class ItemsConfiguration : IEntityTypeConfiguration<Items>
{
    public void Configure(EntityTypeBuilder<Items> entity)
    {
        entity.ToTable("GCC_Items", "GCC");

        entity.HasKey(a => a.Id);

        entity.Property(a => a.HsCode).IsRequired().HasMaxLength(20);
        entity.Property(a => a.GoodsDescription).IsRequired().HasMaxLength(512);
        entity.Property(a => a.OriginCountryCode).IsRequired().HasMaxLength(6);
        entity.Property(a => a.CifForeignValue).IsRequired();
        entity.Property(a => a.CifLocalValue).IsRequired();
        entity.Property(a => a.DutyRate).IsRequired().HasMaxLength(200);
        entity.Property(a => a.IncomeType).HasMaxLength(200);
        entity.Property(a => a.TotalDuty).IsRequired();
        entity.Property(a => a.NetWeight).IsRequired();
        entity.Property(a => a.GrossWeight).IsRequired();
        entity.Property(a => a.ExemptionApprovalRef).HasMaxLength(70);

        entity.Property(a => a.DeclarationId).IsRequired();

        // 🔗 Relationships:

        entity.HasOne<CustomsDeclarationsEntities>()
             .WithMany(d => d.Items)
             .HasForeignKey(i => i.DeclarationId)
             .OnDelete(DeleteBehavior.Cascade);

        // Other relations
        entity.HasOne(i => i.Currency)
              .WithOne()
              .HasForeignKey<Currencies>(c => c.ItemId)
              .OnDelete(DeleteBehavior.Cascade);

        entity.HasOne(i => i.Packages)
              .WithOne()
              .HasForeignKey<Packages>(p => p.ItemId)
              .OnDelete(DeleteBehavior.Cascade);

        entity.HasOne(i => i.Item)
              .WithOne()
              .HasForeignKey<ItemDetails>(d => d.ItemId)
              .OnDelete(DeleteBehavior.Cascade);

        entity.HasOne(i => i.AIP)
              .WithOne()
              .HasForeignKey<AIPs>(a => a.ItemId)
              .OnDelete(DeleteBehavior.Cascade);

        entity.HasMany(i => i.Restrictions)
              .WithOne()
              .HasForeignKey(r => r.ItemId)
              .OnDelete(DeleteBehavior.Cascade);
        

    }
}
