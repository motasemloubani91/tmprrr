﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;

namespace CUAIntegrations.Application.Features.V1.Queries.CUA.SupportingDocumentsList
{
    public class SupportingDocumentsListResponse
    {
        public SupportingDocumentsListDTO? SupportingDocumentListEntity { get; set; }

        public ErrorResponse? ErrorResponse { get; set; }
    }

    public class SupportingDocumentsListDTO
    {
        public string RelatedDeclarationNumber { get; set; }
        public List<GetSupportingDocumentDTO> Documents { get; set; } = new();
    }

    public class GetSupportingDocumentDTO
    {
        //TODO Lookups  gcc.GCC_DocumentTypesLookup
        public string DocumentCategory { get; set; }
        public string DocumentName { get; set; }
        public string DocumentIdNumber { get; set; }
        //TODO Lookups gcc.GCC_LanguageCodesLookup
        public string DocumentLanguage { get; set; }
        public string DocumentLink { get; set; }
    }
}
