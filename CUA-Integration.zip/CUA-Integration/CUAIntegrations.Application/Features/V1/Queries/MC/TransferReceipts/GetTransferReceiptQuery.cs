﻿using CUAIntegrations.Application.Features.V1.Queries.CUA.TransferReceipts;
using CUAIntegrations.Application.Features.V1.Queries.Mc.TransferReceipts;
using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;
using MediatR;
namespace CUAIntegrations.Application.Features.V1.Queries.OutBoundedForMC.TransferReceipts
{
    public record GetTransferReceiptQuery(
        string DueNumber,
        string FirstExitCountryCode
    ) : IRequest<MCGetTransferReceiptResponse>;



   


}
