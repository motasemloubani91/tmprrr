﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;

namespace CUA_GCC_Integration.Core.Exceptions.ServerError
{
    internal class ServiceTempirorilyUnavailableException
    {
    }
    public class RateLimitException : Exception
    {
        public int ErrorCode { get; private set; } //mapped to Status property in ErrorResponse
        public string Message { get; private set; } = "Service temporarily unavailable. System overloaded or under maintenance.";
        public string Reason { get; private set; } = "ServiceUnavailableError";
        public List<ErrorDetail>? Details { get; set; }

        public RateLimitException()
        {
            ErrorCode = 502;
        }
        public RateLimitException(List<ErrorDetail>? errorDetails)
        {
            ErrorCode = 502;
            Details = errorDetails;
        }

        protected RateLimitException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }
    }
}
