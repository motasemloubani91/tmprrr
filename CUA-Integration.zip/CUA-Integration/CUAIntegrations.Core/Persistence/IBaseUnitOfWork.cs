﻿namespace CUAIntegrations.Kernel.Core.Persistence.UnitOfWork
{
    /// <summary>
    /// Defines the interface(s) for unit of work.
    /// </summary>
    public partial interface IBaseUnitOfWork : IDisposable
    {
        /// <summary>
        /// Commits the changes made within the unit of work to the underlying data store.
        /// </summary>
        /// <returns>True if the changes are successfully committed; otherwise, false.</returns>
        bool Commit();

        /// <summary>
        /// Asynchronously commits the changes made within the unit of work to the underlying data store.
        /// </summary>
        /// <returns>A task representing the asynchronous operation, returning true if the changes are successfully committed; otherwise, false.</returns>
        Task<bool> CommitAsync();

        /// <summary>
        /// Rolls back any changes made within the unit of work.
        /// </summary>
        void RollBack();
    }
}
