﻿using System.Net;

namespace CUAIntegrations.Kernel.Core.Exceptions
{
    public class ForbiddenException : Exception
    {
        public int ErrorCode { get; private set; }
        public ForbiddenException()
        {
            ErrorCode = (int)HttpStatusCode.Forbidden;
        }
        public ForbiddenException(string message) : base(message) { }
        public ForbiddenException(string message, int errorCode)
            : base(message)
        {
            this.ErrorCode = errorCode;
        }
        public ForbiddenException(string message, Exception inner) : base(message, inner) { }
        public ForbiddenException(string message, Exception inner, int errorCode)
            : base(message, inner)
        {
            this.ErrorCode = errorCode;
        }
        protected ForbiddenException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }
    }
}
