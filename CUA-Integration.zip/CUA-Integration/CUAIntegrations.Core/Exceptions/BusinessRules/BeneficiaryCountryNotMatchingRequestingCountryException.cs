using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;

namespace CUA_GCC_Integration.Core.Exceptions.BusinessRules
{
    public class BeneficiaryCountryNotMatchingRequestingCountryException : Exception
    {
        public int ErrorCode { get; private set; } //mapped to Status property in ErrorResponse
        public string Message { get; private set; } = "The request was rejected because the beneficiary country in the transfer receipt does not match the requesting GCC country.";
        public string Reason { get; private set; } = "BusinessRuleError";
        public List<ErrorDetail>? Details { get; set; }

        public BeneficiaryCountryNotMatchingRequestingCountryException()
        {
            ErrorCode = 422;
        }

        public BeneficiaryCountryNotMatchingRequestingCountryException(List<ErrorDetail>? errorDetails)
        {
            ErrorCode = 422;
            Details = errorDetails;
        }

        protected BeneficiaryCountryNotMatchingRequestingCountryException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }
    }
}