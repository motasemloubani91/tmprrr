﻿using FluentValidation;

namespace CUAIntegrations.Application.Features.V1.Commands.CUA.AuthorizationCallBack
{
    public class AuthorizationCallBackCommandValidator
        : AbstractValidator<AuthorizationCallBackCommand>
    {
        public AuthorizationCallBackCommandValidator()
        {
            RuleFor(x => x.code)
                .NotNull()
                .WithErrorCode("ERR-02")
                .WithMessage("code is required.");
        }
    }
}
