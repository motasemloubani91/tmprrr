﻿using CUAIntegrations.Kernel.Core.InstanseScopeTypes;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace CUAIntegrations.Kernel.Core.Logging
{
    public class RequestLogger : IScoped, IRequestLogger
    {
        private readonly ILogger _logger;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public RequestLogger(/*ILogger logger,*/ IHttpContextAccessor httpContextAccessor)
        {
            //_logger = logger;
            _httpContextAccessor = httpContextAccessor;
        }

        public void LogInformation(string message, params object?[]? propertyValues)
        {
            //_logger.LogInformation(
            //    message: message,
            //    propertyValues: propertyValues,
            //    requestId: _httpContextAccessor.HttpContext.TraceIdentifier.ToString());
        }

        public void LogException(Exception exception, string message = "", params object?[]? propertyValues)
        {
            //_logger.LogException(
            //    exception, message: message,
            //    propertyValues: propertyValues,
            //    requestId: _httpContextAccessor.HttpContext.TraceIdentifier.ToString());
        }
    }
}
