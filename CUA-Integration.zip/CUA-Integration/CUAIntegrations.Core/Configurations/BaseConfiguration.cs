﻿namespace CUAIntegrations.Kernel.Core.Configurations
{
    public interface IBaseConfiguration
    {
        public ConnectionString ConnectionStrings { get; set; }
        public string CustomsDeclarationUrl { get; set; }
        public string DueNumberUrl { get; set; }
        public string SupportingDocumentsUrl { get; set; }
        public string TransferReceiptsUrl { get; set; }
    }

    public class BaseConfiguration : IBaseConfiguration
    {
        public ConnectionString ConnectionStrings { get; set; }
        public string CustomsDeclarationUrl { get; set; }
        public string DueNumberUrl { get; set; }
        public string SupportingDocumentsUrl { get; set; }
        public string TransferReceiptsUrl { get; set; }
    }
}
