﻿namespace CUAIntegrations.Kernal.Domain.Entities.LoggingEntities
{
    public class GCCLogging
    {
        public int Id { get; set; }
        public DateTime DateCreated { get; set; }
        public string Exception { get; set; }
        public string Message { get; set; }
        public string Level { get; set; }
        public int? RequestLoggingId { get; set; }
    }

}
