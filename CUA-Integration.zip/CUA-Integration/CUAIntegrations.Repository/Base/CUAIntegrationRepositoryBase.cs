﻿using CUAIntegrations.Kernel.Core.Persistence;
using CUAIntegrations.Persistence.DataAccess.Context;

namespace CUAIntegrations.Repository.Base
{
    public class CUAIntegrationRepositoryBase<T> : IRepositoryBase<T> where T : class
    {
        protected readonly CUAIntegrationDbContext context;

        public CUAIntegrationRepositoryBase(CUAIntegrationDbContext context)
        {
            this.context = context;
        }

        public IQueryable<T> Get(/*bool isActive = true*/)
        {
            //if (typeof(T).BaseType.Name == "AuditableEntity" && isActive)
            //{
            //    var t = typeof(AuditableEntity); 

            //    return context.Set<T>().Where(x => t.GetType().GetProperty("IsActive").GetValue(t, null).ToString() == isActive.ToString());
            //}
            return context.Set<T>();
        }

        public IQueryable<T> Get(System.Linq.Expressions.Expression<Func<T, bool>> predicate/*, bool isActive = true*/)
        {
            //if (typeof(T).BaseType.Name == "AuditableEntity" && isActive)
            //{
            //    var t = typeof(AuditableEntity);
            //    var pi = t.GetProperty("IsActive");

            //    return context.Set<T>().Where(x => pi.GetValue(x).ToString() == isActive.ToString()).Where(predicate);
            //}
            return context.Set<T>().Where(predicate);
        }
    }
}
