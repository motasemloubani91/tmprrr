﻿using CUA_GCC_Integration.Core.Exceptions;
using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;
using System.Net;

namespace CUAIntegrations.Application.Services.CUAServices.Exceptions
{
    public class CUAAuthorizationFailedException : SystemIntegrationException
    {
        const string message = "Failed to authorize the request to CUA platform.";
        const string reason = "Authorization Failed.";

        public CUAAuthorizationFailedException() :
            base(errorCode: HttpStatusCode.NotFound,
                message: message,
                reason: reason)
        {
        }

        public CUAAuthorizationFailedException(
            string message = message,
            string reason = reason,
            List<ErrorDetail>? details = null) :
            base(errorCode: HttpStatusCode.NotFound,
                message: message,
                reason: reason,
                details: details)
        {
        }
    }
}
