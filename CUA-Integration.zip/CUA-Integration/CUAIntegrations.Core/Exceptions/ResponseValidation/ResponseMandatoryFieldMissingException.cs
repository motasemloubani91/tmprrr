﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;

namespace CUA_GCC_Integration.Core.Exceptions.ResponseValidation
{
    public class ResponseMandatoryFieldMissingException : Exception
    {
        public int ErrorCode { get; private set; } //mapped to Status property in ErrorResponse
        public string Message { get; private set; } = "The response was rejected because a mandatory field is missing.";
        public string Reason { get; private set; } = "ValidationError";
        public List<ErrorDetail>? Details { get; set; }

        public ResponseMandatoryFieldMissingException()
        {
            ErrorCode = 400;
        }
        public ResponseMandatoryFieldMissingException(List<ErrorDetail>? errorDetails)
        {
            ErrorCode = 400;
            Details = errorDetails;
        }

        protected ResponseMandatoryFieldMissingException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }
    }

}
