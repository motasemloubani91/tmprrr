﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;

namespace CUAIntegrations.Application.Features.V1.Queries.CUA.TransferReceipts
{
    public class OutBoundedGetTransferReceiptResponse
    {
        public CUATransferReceiptDTO? TransferReceiptEntity { get; set; }
        public ErrorResponse? ErrorResponse { get; set; }
    }

    public class CUATransferReceiptDTO
    {
        public string FileName { get; set; }
        public string Image { get; set; }
        public DateTime FileDate { get; set; }
        public decimal Amount { get; set; }
        public List<string> ListOfDues { get; set; }
    }
}
