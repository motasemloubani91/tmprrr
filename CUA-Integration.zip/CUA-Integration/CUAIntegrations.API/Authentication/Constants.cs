﻿namespace CUAIntegrations.Authentication
{
    public class Constants
    {
        public static class AuthenticationScheme
        {
            public const string ApiKey = "ApiKey";
            public const string Basic = "Basic";
        }
    }
}
