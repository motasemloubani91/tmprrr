﻿namespace CUAIntegrations.Kernel.Domain.DTO.ProviderFeedback
{
    public class ProviderFeedbackDto
    {
        public int Id { get; set; }
        public string FeedbackId { get; set; } = string.Empty;
        public string OriginalRequestId { get; set; } = string.Empty;
        public string ApiEndpoint { get; set; } = string.Empty;
        public string? ErrorResponseJson { get; set; }
        public string? OutboundRequestHeader { get; set; }
        public DateTime CreatedOn { get; set; }
    }

}
