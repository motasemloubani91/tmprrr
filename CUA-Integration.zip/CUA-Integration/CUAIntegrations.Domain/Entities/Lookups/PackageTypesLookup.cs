﻿namespace CUAIntegrations.Kernel.Domain.Entities.Lookups
{
    public class PackageTypesLookup
    {
        public long Id { get; set; }
        public string? Code { get; set; }
        public string? EnglishName { get; set; }
        public string? ArabicName { get; set; }
        public string? AdditionalEnglishDescription { get; set; }
        public string? AdditionalArabicDescription { get; set; }
        public string? EnglishCategory { get; set; }
        public string? ArabicCategory { get; set; }
        
    }
}
