﻿
namespace CUAIntegrations.Kernel.Core.Domain.BaseEntities
{
    public abstract class AuditableEntity<T> : EntityBase<T>, IAuditableEntity
    {
        public int CreatedById { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.Now;
        public int? LastModifiedById { get; set; }
        public DateTime? LastModifiedAt { get; set; }
        public int? DeactivatedById { get; set; }
        public DateTime? DeactivatedAt { get; set; }
        public bool IsActive { get; set; }


        public void EntityCreated(int userId, DateTime creationTime)
        {
            CreatedById = userId;
            CreatedAt = creationTime;
            LastModifiedAt = null;
            LastModifiedById = null;
            DeactivatedAt = null;
            DeactivatedById = null;
        }

        public void EntityUpdated(int userId, DateTime dateTime, bool isActivated)
        {
            LastModifiedById = userId;
            LastModifiedAt = dateTime;
            if (isActivated)
            {
                DeactivatedAt = null;
                DeactivatedById = null;
            }
        }

        public void EntityDeactivated(int userId, DateTime dateTime)
        {
            DeactivatedById = userId;
            DeactivatedAt = dateTime;
        }

        public void Activate()
        {
            IsActive = true;
        }

        public void DeActivate()
        {
            IsActive = false;
        }
    }
}
