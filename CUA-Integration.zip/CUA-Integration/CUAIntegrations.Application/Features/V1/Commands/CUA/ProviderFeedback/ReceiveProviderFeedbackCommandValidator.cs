﻿using FluentValidation;
using System.Text.RegularExpressions;

namespace CUAIntegrations.Application.Features.V1.Commands.CUA.ProviderFeedback
{
    public class ReceiveProviderFeedbackCommandValidator
        : AbstractValidator<ReceiveProviderFeedbackCommand>
    {
        public ReceiveProviderFeedbackCommandValidator()
        {
            // --------------------------------------------------------------------
            // 1) Feedback object
            // --------------------------------------------------------------------
            RuleFor(x => x.Feedback)
                .NotNull()
                .WithErrorCode("ERR-02")
                .WithMessage("Feedback payload is required.");

            RuleFor(x => x.Feedback.FeedbackId)
                .NotEmpty()
                .WithErrorCode("ERR-02")
                .WithMessage("feedbackId is required.");

            //RuleFor(x => x.Feedback.FeedbackId)
            //    .Matches(@"^[0-9a-fA-F-]{36}$")
            //    .WithErrorCode("ERR-03")
            //    .WithMessage("feedbackId must be a valid UUID of 36 characters.");

            RuleFor(x => x.Feedback.OriginalRequestId)
                .NotEmpty()
                .WithErrorCode("ERR-02")
                .WithMessage("originalRequestId is required.");

            //RuleFor(x => x.Feedback.OriginalRequestId)
            //    .Matches(@"^[0-9a-fA-F-]{36}$")
            //    .WithErrorCode("ERR-03")
            //    .WithMessage("originalRequestId must be a valid UUID of 36 characters.");

            RuleFor(x => x.Feedback.ApiEndpoint)
                .NotEmpty()
                .WithErrorCode("ERR-02")
                .WithMessage("apiEndpoint is required.");

            RuleFor(x => x.Feedback.ApiEndpoint)
                .MaximumLength(256)
                .WithErrorCode("ERR-03")
                .WithMessage("apiEndpoint must not exceed 256 characters.");
        }
    }
}
