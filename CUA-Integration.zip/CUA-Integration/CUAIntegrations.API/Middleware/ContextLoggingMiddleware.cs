﻿using CUA_GCC_Integration.Core.Helpers;
using CUAIntegrations.Kernel.Domain.Entities.LoggingEntities;
using CUAIntegrations.Repository.Base;
using System.Text;
using System.Text.Json;

namespace CUAIntegrations.Kernel.Host.API.Middleware
{
    public static class ContextLoggingMiddlewareExtension
    {
        public static IApplicationBuilder UseAPIContextLoggingMiddleware(
            this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<APIContextLoggingMiddleware>();
        }
    }

    public class APIContextLoggingMiddleware
    {
        private readonly RequestDelegate _next;

        public APIContextLoggingMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task InvokeAsync(HttpContext context, ICUAIntegrationUnitOfWork unitOfWork)
        {
            if (true)
            {
                try
                {
                    var request = new RequestLogging();
                    request.Endpoint = String.Concat(context.Request.Host, context.Request.Path);
                    request.Direction = request.Endpoint.Contains("mc") ? 'I' : 'O';
                    request.HttpMethod = context.Request.Method;
                    if (context.Request.Headers.TryGetValue(RequestHeadersConstants.X_Client_ID, out var clientId) && !string.IsNullOrWhiteSpace(clientId))
                    {
                        request.ClientId = clientId;
                    }
                    if (context.Request.Headers.TryGetValue(RequestHeadersConstants.X_REQUEST_ID, out var xRequestId) && !string.IsNullOrWhiteSpace(xRequestId))
                    {
                        request.XRequestId = xRequestId;
                    }
                    if (context.Request.Headers.TryGetValue(RequestHeadersConstants.X_CORRELATION_ID, out var correlationId) && !string.IsNullOrWhiteSpace(correlationId))
                    {
                        request.XCorrelationId = correlationId;
                    }
                    request.Headers = JsonSerializer.Serialize(
                                                    context.Request.Headers.ToDictionary(h => h.Key, h => h.Value.ToString()));

                    string requestBody = "";
                    HttpRequestRewindExtensions.EnableBuffering(context.Request);
                    Stream body = context.Request.Body;
                    byte[] buffer = new byte[Convert.ToInt32(context.Request.ContentLength)];
                    await context.Request.Body.ReadAsync(buffer, 0, buffer.Length);
                    requestBody = Encoding.UTF8.GetString(buffer);
                    body.Seek(0, SeekOrigin.Begin);
                    context.Request.Body = body;
                    request.RequestBody = requestBody;
                    request.RequestTime = DateTime.Now;

                    var addedLog = await unitOfWork.RequestLoggingRepository.AddAsync(request);
                    await unitOfWork.CommitAsync();
                    context.Request.Headers.Add(RequestHeadersConstants.X_LOGGING_ID, addedLog.Id.ToString());


                    using (var responseBodyMemoryStream = new MemoryStream())
                    {
                        var originalResponseBodyReference = context.Response.Body;
                        context.Response.Body = responseBodyMemoryStream;
                        //LogContext.PushProperty(LoggingConstants.DB.ResponseBody, "testtest");

                        await _next(context);

                        context.Response.Body.Seek(0, SeekOrigin.Begin);
                        var responseBody = await new StreamReader(context.Response.Body).ReadToEndAsync();
                        context.Response.Body.Seek(0, SeekOrigin.Begin);

                        var responseLogging = new ResponseLogging();
                        responseLogging.ResponseTime = DateTime.Now;
                        responseLogging.ResponseBody = responseBody;
                        responseLogging.RequestId = request.Id;
                        responseLogging.StatusCode = context.Response.StatusCode;
                        responseLogging.ResponseHeaders = JsonSerializer.Serialize(
                                                context.Response.Headers.ToDictionary(h => h.Key, h => h.Value.ToString())
                                            );
                        await unitOfWork.ResponseLoggingRepository.AddAsync(responseLogging);

                        // Todo: calling savechanges is causing invalid entities to be saved to database
                        await unitOfWork.CommitAsync();

                        await responseBodyMemoryStream.CopyToAsync(originalResponseBodyReference);

                    }
                }
                catch (Exception ex)
                {
                    throw;
                }
            }
            else
            {
                await _next(context);
            }
        }
    }
}
