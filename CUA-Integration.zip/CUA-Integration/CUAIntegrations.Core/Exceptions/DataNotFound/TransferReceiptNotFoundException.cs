﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;
using System.Net;

namespace CUA_GCC_Integration.Core.Exceptions.DataNotFound
{
    public class TransferReceiptNotFoundException : SystemIntegrationException
    {
        const string message ="No transfer receipt was found for the specified due number in the first exit country's system. ";
        const string reason = "Data Not Found.";

        public TransferReceiptNotFoundException() :
            base(errorCode: HttpStatusCode.NotFound,
                message: message,
                reason: reason)
        {
        }

        public TransferReceiptNotFoundException(
            string message = message,
            string reason = reason,
            List<ErrorDetail>? details = null) :
            base(errorCode: HttpStatusCode.NotFound,
                message: message,
                reason: reason,
                details: details)
        {
        }
    }
}
