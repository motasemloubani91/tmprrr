﻿
namespace CUAIntegrations.Kernel.Domain.Entities.CustomsDeclarationsEntities
{

    public class CustomsDeclarationsEntities
    {
        public long Id { get; set; }
        public int Version { get; set; }

        public string DeclarationNumber { get; set; }

        public DateTime DeclarationDate { get; set; }

        public string DeclarationType { get; set; }
        public string PortType { get; set; }
        public string? DeliveryOrderNumber { get; set; }
        public string ImporterExporterName { get; set; }
        public string ImporterExporterCustomsId { get; set; }
        public decimal NetWeight { get; set; }
        public string? CarrierCaptainDriver { get; set; }
        public string? IntercessorCompany { get; set; }
        public decimal GrossWeight { get; set; }
        public string? CarrierName { get; set; }
        public string? CommercialRegistrationNumber { get; set; }
        public string? TinNumber { get; set; }
        public string Measurement { get; set; }
        public string? VoyageFlightNumber { get; set; }
        public string? ExportedTo { get; set; }
        public int? NumberOfPackages { get; set; }
        public string? BlAwbManifestNo { get; set; }
        public string? PortOfLoading { get; set; }
        public string? MarksAndNumbers { get; set; }
        public string? PortOfDischarge { get; set; }
        public string? DestinationCountryCode { get; set; }
        public string? ClearingAgentName { get; set; }
        public string? ClearingAgentCode { get; set; }
        public string? LicenseNumber { get; set; }
        public string? RiskOutcome { get; set; }
        public string? ValuationMethod { get; set; }
        public string? OtherRemarks { get; set; }
        public DateTime ReleaseDate { get; set; }
        public string? Route { get; set; }
        public string? ExitPort { get; set; }
        public decimal TotalDuty { get; set; }
        public decimal? Vat { get; set; }
        public decimal? ExciseTax { get; set; }
        public decimal? OtherCharges { get; set; }
        public string? DueNumber { get; set; }
        public string? UnifiedCustomsCode { get; set; }
        public decimal DefiniteFee { get; set; }
        public decimal? Insured { get; set; }

        public List<Items> Items { get; set; } 

        public List<Payments>? Payments { get; set; }





    }
}

