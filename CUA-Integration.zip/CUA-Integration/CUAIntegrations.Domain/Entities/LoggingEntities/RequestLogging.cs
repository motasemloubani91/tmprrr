﻿namespace CUAIntegrations.Kernel.Domain.Entities.LoggingEntities
{
    public class RequestLogging
    {
        public long Id { get; set; }
        /// <summary>I = Inbound, O = Outbound</summary>
        public char Direction { get; set; }
        public string? Endpoint { get; set; }
        public string? HttpMethod { get; set; }
        public string? ClientId { get; set; }
        public string? XRequestId { get; set; }
        public string? XCorrelationId { get; set; }
        public string? XClientId { get; set; }
        public string? Headers { get; set; }
        public string? RequestBody { get; set; }
        public long? DataEntityId { get; set; }
        public string? DataEntityTypeId { get; set; }
        public DateTime RequestTime { get; set; }
    }
}
