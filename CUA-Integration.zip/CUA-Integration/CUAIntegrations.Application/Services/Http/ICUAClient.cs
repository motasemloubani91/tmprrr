﻿using CUAIntegrations.Kernel.Core.Wrappers;

namespace CUAIntegrations.Application.Services.Http
{
    public interface ICUAClient
    {
        Task<Response<T>> GetAsync<T>(string url);
    }
}
