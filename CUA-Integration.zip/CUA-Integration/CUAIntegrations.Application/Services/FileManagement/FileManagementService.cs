using CUAIntegrations.Kernel.Core.InstanseScopeTypes;
using CUAIntegrations.Persistence.DataAccess.ADO.NET;
using Microsoft.Extensions.Configuration;
using System.Collections.Specialized;
using System.Security.Cryptography;
using System.Text;

namespace CUAIntegrations.Application.Services.FileManagement
{
    public class FileManagementService : IScoped, IFileManagementService
    {
        static string PasswordHash = "PasswordHash";
        static string SaltKey = "SaltKey";
        static string VIKey = "VIKeyVIKey";
        static int OwnerLocId = 8998;
        static int OwnerOrgId = 0;
        static string DownloadWebApiURI = "";

        private readonly IFileTokenDataAccess _fileTokenDataAccess;

        public FileManagementService(
            IConfiguration configuration,
            IFileTokenDataAccess fileTokenDataAccess)
        {
            PasswordHash = configuration["FileManagementConfigurations:PasswordHash"].ToString();
            SaltKey = configuration["FileManagementConfigurations:SaltKey"].ToString();
            VIKey = configuration["FileManagementConfigurations:VIKey"].ToString();
            OwnerLocId = Convert.ToInt32(configuration["FileManagementConfigurations:OwnerLocId"]);
            OwnerOrgId = Convert.ToInt32(configuration["FileManagementConfigurations:OwnerOrgId"]);
            DownloadWebApiURI = configuration["FileManagementConfigurations:DownloadWebApiURI"].ToString();
            _fileTokenDataAccess = fileTokenDataAccess;
        }

        public async Task<byte[]> DownloadDocumentFile(
            int documentId,
            int declarationId)
        {
            //////// Generate a token for download.
            string[] arrTokenInfo = _fileTokenDataAccess.GetTokenForDownload(
                                    documentId,
                                    declarationId,
                                    SaltKey,
                                    OwnerOrgId,
                                    OwnerLocId);

            if (arrTokenInfo != null && arrTokenInfo.Length > 0)
            {
                string sTokenInfo = arrTokenInfo[0] + "|" + arrTokenInfo[1] + "|" + SaltKey;
                sTokenInfo = CsUploadEncrypt(sTokenInfo);
                string sDocumentId = CsUploadEncrypt(documentId.ToString());


                NameValueCollection nvcFormParam = new NameValueCollection();
                nvcFormParam.Add("tokenInfo", sTokenInfo);
                nvcFormParam.Add("DocumentId", sDocumentId);

                var downloadResult = await FileUploadHelperUsingHTTPWebClient.HttpDownloadFile(nvcFormParam);

                if (downloadResult.IsResponseAvailable)
                {
                    return downloadResult.FileDataBytes;
                }
                else
                {
                    return null;
                }
            }
            return null;
        }

        private string CsUploadEncrypt(string plainText)
        {
            byte[] plainTextBytes = Encoding.UTF8.GetBytes(plainText);
            byte[] keyBytes = new Rfc2898DeriveBytes(PasswordHash, Encoding.ASCII.GetBytes(SaltKey)).GetBytes(256 / 8);
            var symmetricKey = new RijndaelManaged() { Mode = CipherMode.CBC, Padding = PaddingMode.Zeros };
            var encryptor = symmetricKey.CreateEncryptor(keyBytes, Encoding.ASCII.GetBytes(VIKey));

            byte[] cipherTextBytes;

            using (var memoryStream = new MemoryStream())
            {
                using (var cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write))
                {
                    cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length);
                    cryptoStream.FlushFinalBlock();
                    cipherTextBytes = memoryStream.ToArray();

                    cryptoStream.Close();
                }

                memoryStream.Close();
            }

            return Convert.ToBase64String(cipherTextBytes);
        }

        private class WebAPIFileDownloadResponse
        {
            //// This class is created to contain the WebApi response
            public bool IsResponseAvailable { get; set; }
            public byte[] FileDataBytes { get; set; }
            public string ErrorDetails { get; set; }
        }

        private class FileUploadHelperUsingHTTPWebClient
        {
            private static readonly HttpClientHandler _httpClientHandler = CreateHttpClientHandler();

            private static HttpClientHandler CreateHttpClientHandler()
            {
                var handler = new HttpClientHandler
                {
                    ServerCertificateCustomValidationCallback = (message, cert, chain, errors) => true
                };
                return handler;
            }

            private static readonly HttpClient _httpClient = new HttpClient(_httpClientHandler, disposeHandler: false)
            {
                Timeout = TimeSpan.FromMinutes(5)
            };

            /// <summary>
            /// Downloads a file using HttpClient (modern .NET 7 approach).
            /// Replaces deprecated HttpWebRequest with modern HttpClient implementation.
            /// </summary>
            /// <param name="sUrl">The URL to download from</param>
            /// <param name="sFileNameToDownloadAs">The local file path where the file will be saved</param>
            /// <param name="nvc">Name-value collection of form parameters to POST</param>
            /// <returns>Empty string on success, or error message on failure</returns>
            public static async Task<WebAPIFileDownloadResponse> HttpDownloadFile(NameValueCollection nvc)
            {
                var result = new WebAPIFileDownloadResponse();

                try
                {
                    //////// Build form content from NameValueCollection
                    var formContent = new List<KeyValuePair<string, string>>();
                    if (nvc != null)
                    {
                        foreach (string key in nvc.Keys)
                        {
                            formContent.Add(new KeyValuePair<string, string>(key, nvc[key]));
                        }
                    }

                    using (var content = new FormUrlEncodedContent(formContent))
                    {
                        //////// Make POST request with form data
                        using (var response = await _httpClient.PostAsync(DownloadWebApiURI, content))
                        {
                            //////// Check if response is successful
                            if (!response.IsSuccessStatusCode)
                            {
                                int iStatusCode = (int)response.StatusCode;
                                string sStatusCodeTemp = $"StatusCode: {iStatusCode} ({response.StatusCode})";
                                result.ErrorDetails = "WebApi returned following response:\r\n";
                                result.ErrorDetails += sStatusCodeTemp + "\r\n" + response.ReasonPhrase;
                            }
                            else
                            {
                                try
                                {
                                    result.FileDataBytes = await response.Content.ReadAsByteArrayAsync();
                                    result.IsResponseAvailable = true;
                                }
                                catch (Exception exFileWriteIssue)
                                {
                                    result.ErrorDetails = $"Error occurred while creating download file from WebApi response stream \r\n{exFileWriteIssue}";
                                }
                            }
                        }
                    }
                }
                catch (TaskCanceledException ex)
                {
                    string sErrMsg = $"File download request timed out: {ex.Message}";
                    result.ErrorDetails = sErrMsg;
                }
                catch (HttpRequestException ex)
                {
                    string sErrMsg = $"Error occurred during file download WebApi call: {ex.Message}";
                    result.ErrorDetails = sErrMsg;
                }
                catch (Exception ex)
                {
                    string sErrMsg = $"Error occurred during file download WebApi call:\r\n{ex}";
                    result.ErrorDetails = sErrMsg;
                }

                return result;
            }
        }
    }
}
