using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;
using System.Net;

namespace CUA_GCC_Integration.Core.Exceptions.DataNotFound
{
    public class NotFoundTransferReceiptException : SystemIntegrationException
    {
        const string message = "No transfer receipt was found for the specified due number.";
        const string reason = "Data Not Found.";

        public NotFoundTransferReceiptException() :
            base(errorCode: HttpStatusCode.NotFound,
                message: message,
                reason: reason)
        {
        }

        public NotFoundTransferReceiptException(
            string message = message,
            string reason = reason,
            List<ErrorDetail>? details = null) :
            base(errorCode: HttpStatusCode.NotFound,
                message: message,
                reason: reason,
                details: details)
        {
        }
    }
}