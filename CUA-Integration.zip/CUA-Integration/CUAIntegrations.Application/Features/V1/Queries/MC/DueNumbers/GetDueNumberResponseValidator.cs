﻿using CUAIntegrations.Application.Features.V1.Queries.Mc.DueNumbers;
using CUAIntegrations.Application.Features.V1.Queries.OutBoundedForMC.DueNumbers;
using FluentValidation;
using System.Globalization;

public class GetDueNumberResponseValidator : AbstractValidator<GetCUADueNumberResponse>
{
    public GetDueNumberResponseValidator()
    {

        RuleFor(x => x.DueNumberEntity)
                    .SetValidator(new GetDueNumberModelValidator());

    }
}


public class GetDueNumberModelValidator : AbstractValidator<CUADueNumberModel>
{
    public GetDueNumberModelValidator()
    {
        // TransferDeclarationNumber
        RuleFor(x => x.TransferDeclarationNumber)
            .NotEmpty()
            .WithErrorCode("ERR-08")
            .WithMessage("Missing mandatory field: transferDeclarationNumber.");

        RuleFor(x => x.TransferDeclarationNumber)
            .MaximumLength(70)
            .WithErrorCode("ERR-11")
            .WithMessage("Invalid field length: transferDeclarationNumber max length is 70.");

        // TransferPort
        RuleFor(x => x.TransferPort)
            .NotEmpty()
            .WithErrorCode("ERR-08")
            .WithMessage("Missing mandatory field: transferPort.");

        RuleFor(x => x.TransferPort)
            .Length(3)
            .WithErrorCode("ERR-11")
            .WithMessage("Invalid format: transferPort must be 3 characters.");

        // TransferDeclarationDate
        RuleFor(x => x.TransferDeclarationDate)
            .NotNull()
            .WithErrorCode("ERR-08")
            .WithMessage("Missing mandatory field: transferDeclarationDate.");

        RuleFor(x => x.TransferDeclarationDate)
            .Must(BeValidDate)
            .WithErrorCode("ERR-22")
            .WithMessage("Invalid date format:pad time with 000000 (YYYYMMDD000000) transferDeclarationDate must be in YYYYMMDDHHMMSS format.");

        // DueAmount
        RuleFor(x => x.DueAmount)
            .NotNull()
            .WithErrorCode("ERR-08")
            .WithMessage("Missing mandatory field: dueAmount.");

        RuleFor(x => x.DueAmount)
            .Must(x => x >= 0)
            .WithErrorCode("ERR-11")
            .WithMessage("Invalid field value: dueAmount cannot be negative.");

        // DestinationCountry
        RuleFor(x => x.DestinationCountry)
            .NotEmpty()
            .WithErrorCode("ERR-08")
            .WithMessage("Missing mandatory field: destinationCountry.");

        RuleFor(x => x.DestinationCountry)
            .Length(2)
            .WithErrorCode("ERR-11")
            .WithMessage("Invalid format: destinationCountry must be alpha2 code.");

        // FirstEntryCountry
        RuleFor(x => x.FirstEntryCountry)
            .NotEmpty()
            .WithErrorCode("ERR-08")
            .WithMessage("Missing mandatory field: firstEntryCountry.");

        RuleFor(x => x.FirstEntryCountry)
            .Length(2)
            .WithErrorCode("ERR-11")
            .WithMessage("Invalid format: firstEntryCountry must be alpha2 code.");

        // FirstEntryPort
        RuleFor(x => x.FirstEntryPort)
            .NotEmpty()
            .WithErrorCode("ERR-08")
            .WithMessage("Missing mandatory field: firstEntryPort.");

        RuleFor(x => x.FirstEntryPort)
            .Length(3)
            .WithErrorCode("ERR-11")
            .WithMessage("Invalid format: firstEntryPort must be 3 characters.");

        // FirstEntryDeclarationNumber
        RuleFor(x => x.FirstEntryDeclarationNumber)
            .NotEmpty()
            .WithErrorCode("ERR-08")
            .WithMessage("Missing mandatory field: firstEntryDeclarationNumber.");

        RuleFor(x => x.FirstEntryDeclarationNumber)
            .MaximumLength(70)
            .WithErrorCode("ERR-11")
            .WithMessage("Invalid field length: firstEntryDeclarationNumber max length is 70.");

        // FirstEntryDeclarationDate
        RuleFor(x => x.FirstEntryDeclarationDate)
            .NotEmpty()
            .WithErrorCode("ERR-08")
            .WithMessage("Missing mandatory field: firstEntryDeclarationDate.");

        RuleFor(x => x.FirstEntryDeclarationDate)
            .Must(BeValidDate)
            .WithErrorCode("ERR-22")
            .WithMessage("Invalid date format:pad time with 000000 (YYYYMMDD000000) firstEntryDeclarationDate must be YYYYMMDDHHMMSS.");

        // Status
        RuleFor(x => x.Status)
            .NotEmpty()
            .WithErrorCode("ERR-08")
            .WithMessage("Missing mandatory field: status.");

        RuleFor(x => x.Status)
            .Length(3)
            .WithErrorCode("ERR-11")
            .WithMessage("Invalid field length: status must be size 3.");

        // ReceiptFileRef 
        RuleFor(x => x.ReceiptFileRef)
            .MaximumLength(70)
            .When(x => !string.IsNullOrEmpty(x.ReceiptFileRef))
            .WithErrorCode("ERR-11")
            .WithMessage("Invalid field length: receiptFileRef max length is 70.");
    }


    private bool BeValidDate(string date)
    {
        return DateTime.TryParseExact(
            date,
            "yyyyMMddHHmmss",
            null,
            System.Globalization.DateTimeStyles.None,
            out _
        );
    }

}
