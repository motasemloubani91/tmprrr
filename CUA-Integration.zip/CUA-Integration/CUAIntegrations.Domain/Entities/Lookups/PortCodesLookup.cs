﻿using System.Diagnostics.Metrics;

namespace CUAIntegrations.Kernel.Domain.Entities.Lookups
{
    public class PortCodesLookup
    {
        public long Id { get; set; }
        public string? Code { get; set; }
        public string? Country { get; set; }
        public string? EnglishPortType { get; set; }
        public string? ArabicPortType { get; set; }
        public string? ArabicDescription { get; set; }
        public string? EnglishDescription { get; set; }


       
    }
}
