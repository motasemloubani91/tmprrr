﻿using System.Security.Cryptography.X509Certificates;

namespace CUAIntegrations.Authentication
{
    public interface IClientCertificateValidator
    {
        bool ValidateCertificate(X509Certificate2 certificate);
    }
    public class ClientCertificateValidator : IClientCertificateValidator
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<ClientCertificateValidator> _logger;

        public ClientCertificateValidator(
            IConfiguration configuration,
            ILogger<ClientCertificateValidator> logger)
        {
            _configuration = configuration;
            _logger = logger;
        }

        public bool ValidateCertificate(X509Certificate2 certificate)
        {
            if (certificate == null)
            {
                return false;
            }

            try
            {
                // Validate certificate is not expired
                if (certificate.NotAfter < DateTime.Now || certificate.NotBefore > DateTime.Now)
                {
                    _logger.LogWarning("Certificate expired or not yet valid");
                    return false;
                }

                // Validate thumbprint against allowed certificates
                var allowedThumbprints = _configuration.GetSection("CUA:AllowedCertificateThumbprints")
                    .Get<string[]>();

                if (allowedThumbprints != null &&
                    allowedThumbprints.Contains(certificate.Thumbprint, StringComparer.OrdinalIgnoreCase))
                {
                    return true;
                }

                // Validate certificate chain
                var chain = new X509Chain
                {
                    ChainPolicy =
                {
                    RevocationMode = X509RevocationMode.Online,
                    RevocationFlag = X509RevocationFlag.ExcludeRoot,
                    VerificationFlags = X509VerificationFlags.NoFlag
                }
                };

                bool isValid = chain.Build(certificate);

                if (!isValid)
                {
                    _logger.LogWarning("Certificate chain validation failed");
                }

                return isValid;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error validating certificate");
                return false;
            }
        }
    }
}
