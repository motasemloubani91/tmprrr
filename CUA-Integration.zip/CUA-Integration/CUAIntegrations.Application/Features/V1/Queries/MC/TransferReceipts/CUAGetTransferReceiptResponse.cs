﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;


namespace CUAIntegrations.Application.Features.V1.Queries.Mc.TransferReceipts
{
    public class CUAGetTransferReceiptResponse
    {
        public CUATransferReceiptFromCuaDto? TransferReceiptEntity { get; set; }
        public ErrorResponse? ErrorResponse { get; set; }

    }
    public class CUATransferReceiptFromCuaDto
    {

        public string FileName { get; set; }
        public string Image { get; set; }
        public DateTime FileDate { get; set; }
        public decimal Amount { get; set; }
        public string DueNumber { get; set; }

        public List<string> ListOfDues { get; set; }
    }

}
