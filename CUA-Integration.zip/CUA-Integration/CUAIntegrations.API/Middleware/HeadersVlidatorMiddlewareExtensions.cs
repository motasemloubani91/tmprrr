﻿using CUA_GCC_Integration.Core.Helpers;
using CUAIntegrations.Kernel.Core.Exceptions;
using CUAIntegrations.Kernel.Core.Logging;
using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;

namespace CUAIntegrations.Kernel.Host.API.Middleware
{
    public static class HeadersValidatorMiddlewareExtension
    {
        public static IApplicationBuilder UsHeadersValidatorMiddleware(
            this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<HeadersValidatorMiddleware>();
        }
    }

    public class HeadersValidatorMiddleware
    {
        private readonly RequestDelegate next;

        /// <summary>
        /// ExceptionMiddleware
        /// </summary>
        /// <param name="next"></param>
        public HeadersValidatorMiddleware(RequestDelegate next)
        {
            this.next = next;
        }

        /// <summary>
        /// Invoke
        /// </summary>
        /// <param name="context"></param>
        /// <param name="logger"></param>
        /// <returns></returns>
        public async Task Invoke(HttpContext context, IRequestLogger requestLogger) /* other dependencies */
        {
            var listOfMissingHeaders = new List<string>();
            if (!context.Request.Headers.TryGetValue(RequestHeadersConstants.X_Client_ID, out var clientId) || string.IsNullOrWhiteSpace(clientId))
            {
                listOfMissingHeaders.Add(RequestHeadersConstants.X_Client_ID);
            }
            if (!context.Request.Headers.TryGetValue(RequestHeadersConstants.X_REQUEST_ID, out var xRequestId) || string.IsNullOrWhiteSpace(xRequestId))
            {
                listOfMissingHeaders.Add(RequestHeadersConstants.X_REQUEST_ID);
            }
            if (!context.Request.Headers.TryGetValue(RequestHeadersConstants.X_CORRELATION_ID, out var correlationId) || string.IsNullOrWhiteSpace(correlationId))
            {
                listOfMissingHeaders.Add(RequestHeadersConstants.X_CORRELATION_ID);
            }
            if (!context.Request.Headers.TryGetValue(RequestHeadersConstants.X_Request_Timestamp, out var requestTimeStamp) || string.IsNullOrWhiteSpace(requestTimeStamp))
            {
                listOfMissingHeaders.Add(RequestHeadersConstants.X_Request_Timestamp);
            }
            if (!string.IsNullOrWhiteSpace(clientId) &&
                (clientId == ApplicationClientsConstants.Qatar ||
                clientId == ApplicationClientsConstants.SaudiArabia ||
                clientId == ApplicationClientsConstants.UnitedArabEmirates ||
                clientId == ApplicationClientsConstants.Oman ||
                clientId == ApplicationClientsConstants.Bahrain) &&
                !context.Request.Headers.TryGetValue(RequestHeadersConstants.Authorization, out var authorization) || string.IsNullOrWhiteSpace(authorization))
            {
                listOfMissingHeaders.Add(RequestHeadersConstants.Authorization);
            }
            //if (!string.IsNullOrWhiteSpace(clientId) &&
            //    (clientId == ApplicationClientsConstants.MC) &&
            //    !context.Request.Headers.TryGetValue(RequestHeadersConstants.X_AppKey, out var appKey) || string.IsNullOrWhiteSpace(appKey))
            //{
            //    listOfMissingHeaders.Add(RequestHeadersConstants.X_AppKey);
            //}
            //if (!string.IsNullOrWhiteSpace(clientId) &&
            //    (clientId == ApplicationClientsConstants.MC) &&
            //    !context.Request.Headers.TryGetValue(RequestHeadersConstants.X_SecretKey, out var secretKey) || string.IsNullOrWhiteSpace(secretKey))
            //{
            //    listOfMissingHeaders.Add(RequestHeadersConstants.X_SecretKey);
            //}

            //if (listOfMissingHeaders.Any())
            //{
            //    throw new InvalidHeadersException(details: listOfMissingHeaders.Select(a => new ErrorDetail
            //    {
            //        Location = $@"Headers",
            //        Message = $@"Missing '{a}' header",
            //        Severity = "High",
            //        Reason = $@"'{a} header is mandatory",
            //    }).ToList());
            //}

            await next(context);
        }
    }
}