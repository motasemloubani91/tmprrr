﻿using CUAIntegrations.Application.Features.V1.Queries.Mc.DownloadDocument;
using MediatR;

namespace CUAIntegrations.Application.Features.V1.Queries.OutBoundedForMC.DownloadDocument
{
    public record DownloadSupportingDocumentQuery(
        string DeclarationNumber,
        string IssuingCountryCode,
        string DocumentId,
        string? DeclarationType,
        string? Year,
        string? Port
    ) : IRequest<DownloadSupportingDocumentResponse>;



 

}
