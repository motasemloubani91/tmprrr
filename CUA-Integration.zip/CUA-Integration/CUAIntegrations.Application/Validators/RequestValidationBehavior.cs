﻿using CUA_GCC_Integration.Core.Exceptions.RequestValidation;
using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;
using FluentValidation;
using MediatR;

public class RequestValidationBehavior<TRequest, TResponse> : IPipelineBehavior<TRequest, TResponse>
    where TRequest : notnull
{
    private readonly IEnumerable<IValidator<TRequest>> _validators;

    public RequestValidationBehavior(IEnumerable<IValidator<TRequest>> validators)
    {
        _validators = validators;
    }

    public async Task<TResponse> Handle(
        TRequest request,
        RequestHandlerDelegate<TResponse> next,
        CancellationToken cancellationToken)
    {
        var typedValidators = _validators
            .Where(v => v is IValidator<TRequest>)
            .Cast<IValidator<TRequest>>()
            .ToList();

        if (!typedValidators.Any())
            return await next();

        var context = new ValidationContext<TRequest>(request);

        var validationResults = await Task.WhenAll(
            typedValidators.Select(v => v.ValidateAsync(context, cancellationToken))
        );

        var failures = validationResults
            .SelectMany(r => r.Errors)
            .Where(f => f != null)
            .ToList();

        if (failures.Any())
        {
            var errorsDetails = failures.Select(error => new ErrorDetail
            {
                InnerCode = error.ErrorCode,
                Message = error.ErrorMessage,
                Reason = error.ErrorMessage,
                Location = error.PropertyName,
                Severity = error.Severity.ToString()
            })
            .ToList();

            throw new InvalidFieldValueException(details: errorsDetails);
        }

        return await next();
    }
}
