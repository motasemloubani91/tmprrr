﻿using CUAIntegrations.Kernal.Domain.Entities.LoggingEntities;
using CUAIntegrations.Kernel.Core.Persistence;
using CUAIntegrations.Kernel.Core.Persistence.UnitOfWork;
using CUAIntegrations.Kernel.Domain.Entities.AuthenticationsEntities;
using CUAIntegrations.Kernel.Domain.Entities.CustomsDeclarationsEntities;
using CUAIntegrations.Kernel.Domain.Entities.DueNumbers;
using CUAIntegrations.Kernel.Domain.Entities.LoggingEntities;
using CUAIntegrations.Kernel.Domain.Entities.Lookups;
using CUAIntegrations.Kernel.Domain.Entities.ProviderFeedbackEntities;
using CUAIntegrations.Kernel.Domain.Entities.TransferReceipts;

namespace CUAIntegrations.Repository.Base
{
    public interface ICUAIntegrationUnitOfWork : IBaseUnitOfWork
    {
        public IRepository<IntegrationsAuthentication> IntegrationsAuthenticationRepository { get; }

        #region CustomDeclarations

        public IRepository<AIPs> AIPsRepository { get; }
        public IRepository<Currencies> CurrenciesRepository { get; }
        public IRepository<CustomsDeclarationsEntities> CustomsDeclarationsEntitiesRepository { get; }
        public IRepository<ItemDetails> ItemDetailsRepository { get; }
        public IRepository<Items> ItemsRepository { get; }
        public IRepository<Packages> PackagesRepository { get; }
        public IRepository<Payments> PaymentsRepository { get; }
        public IRepository<Restrictions> RestrictionsRepository { get; }
        public IRepository<ProviderFeedbackEntity> ProviderFeedbackRepository { get; }


        #endregion

        #region DueNumber

        public IRepository<DueNumber> DueNumberRepository { get; }
        #endregion

        #region TransferReceipt

        public IRepository<TransferReceipt> TransferReceiptRepository { get; }
        public IRepository<TransferReceiptListOfDues> TransferReceiptListOfDuesRepository { get; }

        #endregion

        #region logging
        public IRepository<RequestLogging> RequestLoggingRepository { get; }
        public IRepository<ResponseLogging> ResponseLoggingRepository { get; }
        public IRepository<GCCLogging> GCCExceptionLoggingRepository { get; }
        #endregion

        #region Lookups
        public IRepository<CountryCodesLookup> CountryCodesLookupRepository { get; }
        public IRepository<CurrencyCodesLookup> CurrencyCodesLookupRepository { get; }
        public IRepository<CustomsDataTypesLookup> CustomsDataTypesLookupRepository { get; }
        public IRepository<CustomsPortTypesLookup> CustomsPortTypesLookupRepository { get; }
        public IRepository<DocumentTypesLookup> DocumentTypesLookupRepository { get; }
        public IRepository<DueNumberStatusesLookup> DueNumberStatusesLookupRepository { get; }
        public IRepository<LanguageCodesLookup> LanguageCodesLookupRepository { get; }
        public IRepository<PackageTypesLookup> PackageTypesLookupRepository { get; }
        public IRepository<PaymentMethodsLookup> PaymentMethodsLookupRepository { get; }
        public IRepository<PortCodesLookup> PortCodesLookupRepository { get; }
        public IRepository<RiskResultsLookup> RiskResultsLookupRepository { get; }
        public IRepository<UnitCodesLookup> UnitCodesLookupRepository { get; }
        public IRepository<ValuationMethodsLookup> ValuationMethodsLookupRepository { get; }
        #endregion

        public void DeAttach();
    }
}
