﻿namespace CUAIntegrations.Kernel.Core.Logging
{
    public interface IJobLogger
    {
        void LogInformation(string message, string requestTraceId);
        void LogException(string message, string requestTraceId);
        void LogException(System.Exception exception, string requestTraceId);
    }
}
