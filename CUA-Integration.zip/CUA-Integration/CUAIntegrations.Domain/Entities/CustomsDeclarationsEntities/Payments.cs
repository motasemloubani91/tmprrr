﻿namespace CUAIntegrations.Kernel.Domain.Entities.CustomsDeclarationsEntities
{
    public class Payments
    {


        public long Id { get; set; }
        public long DeclarationId { get; set; }
        public string? Method { get; set; }
        public string? No { get; set; }
        public DateTime? Date { get; set; }
        public string? Bank { get; set; }
    }
}
