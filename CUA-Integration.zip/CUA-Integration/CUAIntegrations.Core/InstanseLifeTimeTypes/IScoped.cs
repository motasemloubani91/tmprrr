﻿namespace CUAIntegrations.Kernel.Core.InstanseScopeTypes
{
    public interface IScoped
    {
    }
}
