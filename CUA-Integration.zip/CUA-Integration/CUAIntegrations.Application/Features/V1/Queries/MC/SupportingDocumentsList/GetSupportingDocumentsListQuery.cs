﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;
using MediatR;

namespace CUAIntegrations.Application.Features.V1.Queries.OutBoundedForMC.SupportingDocuments
{
    public record GetSupportingDocumentsListQuery(
            string DeclarationNumber,
            string IssuingCountryCode,
            string? DeclarationType,
            string? Year,
            string? Port
        ) : IRequest<MCGetSupportingDocumentsListResponse>;

    public class MCGetSupportingDocumentsListResponse
    {
        public McSupportingDocumentListDto SupportingDocumentListEntity { get; set; }
        public ErrorResponse? ErrorResponse { get; set; }
    }



    public class McSupportingDocumentDto
    {
        public string RelatedDeclarationNumber { get; set; }
        //TODO Lookups  gcc.GCC_DocumentTypesLookup
        public string DocumentCategory { get; set; }
        public string DocumentName { get; set; }
        public string DocumentIdNumber { get; set; }
        //TODO Lookups gcc.GCC_LanguageCodesLookup
        public string DocumentLanguage { get; set; }
        public string DocumentLink { get; set; }




    }

    public class McSupportingDocumentListDto
    {
        public string RelatedDeclarationNumber { get; set; }
        public List<McSupportingDocumentDto> Documents { get; set; }
    }
}
