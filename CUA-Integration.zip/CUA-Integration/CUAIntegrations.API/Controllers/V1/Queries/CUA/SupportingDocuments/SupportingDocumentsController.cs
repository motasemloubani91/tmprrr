﻿using CUAIntegrations.Application.Features.V1.Queries.CUA.SupportingDocumentsList;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using CUAIntegrations.Application.Features.V1.Queries.CUA.DownloadDocument;

namespace CUAIntegrations.Controllers.V1.Queries.CUA.SupportingDocuments
{
    public class SupportingDocumentsController : BaseCUAController
    {
        private readonly IMediator _mediator;

        public SupportingDocumentsController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet("{declarationNumber}")]
        [ApiVersion("1")]
        public async Task<SupportingDocumentsListResponse> GetOutBoundedSupportingDocuments(
            [FromRoute] string declarationNumber,
            [FromQuery] string declarationType,
            [FromQuery] string year,
            [FromQuery] string port)
        {
            var query = new GetCUASupportingDocumentsListQuery(
                declarationNumber,
                declarationType, 
                year,
                port
                );

            return await _mediator.Send(query);
        }

        [HttpGet("{declarationNumber}/{documentID}")]
        [ApiVersion("1")]
        public async Task<DownloadDocumentResponse> OutBoundedDownloadDocument(
            [FromRoute] string declarationNumber,
            [FromRoute] string documentID,
            [FromQuery] string declarationType,
            [FromQuery] string year,
            [FromQuery] string port)
        {
            var query = new DownloadDocumentQuery(
                declarationNumber,
                documentID,
                declarationType,
                year,
                port);

            var result = await _mediator.Send(query);
            return result;
        }
    }
}


