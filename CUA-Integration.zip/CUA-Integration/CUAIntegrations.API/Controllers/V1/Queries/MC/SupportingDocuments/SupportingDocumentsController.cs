﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using CUAIntegrations.Application.Features.V1.Queries.OutBoundedForMC.DownloadDocument;
using CUAIntegrations.Application.Features.V1.Queries.OutBoundedForMC.SupportingDocuments;

namespace CUAIntegrations.Controllers.V1.Queries.MC.SupportingDocuments
{
    [ApiController]
    public class SupportingDocumentsController : BaseMCController
    {
        private readonly IMediator _mediator;

        public SupportingDocumentsController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet("{declarationNumber}/{issuingCountryCode}")]
        [ApiVersion("1")]
        public async Task<MCGetSupportingDocumentsListResponse> GetSupportingDocuments(
            [FromRoute] string declarationNumber,
            [FromRoute] string issuingCountryCode,
            [FromQuery] string? declarationType,
            [FromQuery] string? year,
            [FromQuery] string? port)
        {
            var query = new GetSupportingDocumentsListQuery(
                declarationNumber,
                issuingCountryCode,
                declarationType,
                year,
                port);

            return await _mediator.Send(query);
        }


        [HttpGet("{declarationNumber}/{issuingCountryCode}/{documentID}")]
        [ApiVersion("1")]
        public async Task<IActionResult> DownloadSupportingDocument(
            [FromRoute] string declarationNumber,
            [FromRoute] string issuingCountryCode,
            [FromRoute] string documentID,
            [FromQuery] string? declarationType,
            [FromQuery] string? year,
            [FromQuery] string? port)
        {
            var query = new DownloadSupportingDocumentQuery(
                declarationNumber,
                issuingCountryCode,
                documentID,
                declarationType,
                year,
                port
                );

            var result = await _mediator.Send(query);
            return StatusCode(200, result);
        }
    }
}


