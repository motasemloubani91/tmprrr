﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CUAIntegrations.Kernel.Domain.Entities.LoggingEntities
{
    public class DataEntityTypes
    {
        public int DataEntityTypeId { get; set; }
        public string EntityTypeName { get; set; } = default!;
        public string? Description { get; set; }
        public string TableName { get; set; } = default!;
        public bool IsActive { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
