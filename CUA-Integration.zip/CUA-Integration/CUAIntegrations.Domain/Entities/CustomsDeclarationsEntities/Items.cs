﻿namespace CUAIntegrations.Kernel.Domain.Entities.CustomsDeclarationsEntities
{
    public class Items
    {

        public long Id { get; set; }
        public long DeclarationId { get; set; }
        public string HsCode { get; set; }
        public string GoodsDescription { get; set; }
        public string OriginCountryCode { get; set; }
        public decimal CifForeignValue { get; set; }
        public decimal CifLocalValue { get; set; }
        public string DutyRate { get; set; }
        public string? IncomeType { get; set; }
        public decimal TotalDuty { get; set; }
        public decimal NetWeight { get; set; }
        public decimal GrossWeight { get; set; }
        public string? ExemptionApprovalRef { get; set; }


        public Currencies Currency { get; set; } 
        public Packages? Packages { get; set; }
        public ItemDetails Item { get; set; } 
        public AIPs? AIP { get; set; }
        public List<Restrictions>? Restrictions { get; set; }





    }

}
