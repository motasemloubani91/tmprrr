﻿namespace CUAIntegrations.Kernel.Domain.Entities.CustomsDeclarationsEntities
{

    public class ItemDetails
    {

        public long Id { get; set; }
        public long ItemId { get; set; }
        public decimal Quantity { get; set; }
        public string Unit { get; set; } 

    }

}
