﻿namespace CUAIntegrations.Kernel.Domain.Entities.DueNumbers
{
    public class DueNumber
    {
        public long Id { get; set; }
        public int Version { get; set; }
        public long DeclarationId { get; set; }
        public string TransferDeclarationNumber { get; set; }
        public string TransferPort { get; set; }
        public DateTime TransferDeclarationDate { get; set; }
        public decimal DueAmount { get; set; }
        public string DestinationCountry { get; set; }
        public string FirstEntryCountry { get; set; }
        public string FirstEntryPort { get; set; }
        public string FirstEntryDeclarationNumber { get; set; }
        public DateTime FirstEntryDeclarationDate { get; set; }
        public string Status { get; set; }
        public string? ReceiptFileRef { get; set; }
    }
}
