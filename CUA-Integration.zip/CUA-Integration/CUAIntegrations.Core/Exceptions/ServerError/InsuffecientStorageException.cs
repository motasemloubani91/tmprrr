﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;

namespace CUA_GCC_Integration.Core.Exceptions.ServerError
{
    public class InsuffecientStorageException : Exception
    {
        public int ErrorCode { get; private set; } //mapped to Status property in ErrorResponse
        public string Message { get; private set; } = "Insufficient storage. Cannot store validation results. ";
        public string Reason { get; private set; } = "StorageError";
        public List<ErrorDetail>? Details { get; set; }

        public InsuffecientStorageException()
        {
            ErrorCode = 507;
        }
        public InsuffecientStorageException(List<ErrorDetail>? errorDetails)
        {
            ErrorCode = 507;
            Details = errorDetails;
        }

        protected InsuffecientStorageException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }
    }
}
