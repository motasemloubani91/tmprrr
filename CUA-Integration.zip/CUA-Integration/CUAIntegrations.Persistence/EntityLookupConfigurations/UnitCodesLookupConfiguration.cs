﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using CUAIntegrations.Kernel.Domain.Entities.Lookups;

namespace CUAIntegrations.Persistence.EntityLookupConfigurations
{
    public class UnitCodesLookupConfiguration : IEntityTypeConfiguration<UnitCodesLookup>
    {
        public void Configure(EntityTypeBuilder<UnitCodesLookup> entity)
        {
            entity.ToTable("GCC_UnitCodesLookup", "GCC");
            entity.HasKey(e => e.Id);

            entity.Property(e => e.Code).HasMaxLength(255);
            entity.Property(e => e.ArabicDescription).HasMaxLength(255);
            entity.Property(e => e.EnglishDescription).HasMaxLength(255);
            //entity.Property(e => e.Notes).HasMaxLength(255);
        }
    }
}
