﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;

namespace CUAIntegrations.Application.Features.V1.Queries.Mc.TransferReceipts
{
    public class MCGetTransferReceiptResponse
    {
        public ErrorResponse? ErrorResponse { get; set; }
        public string Id { get; set; }
    }

    public class McTransferReceiptDto
    {
        public long Id { get; set; }
        public int Version { get; set; }
        public string FileName { get; set; }
        public string ImageUrl { get; set; }
        public DateTime FileDate { get; set; }
        public decimal Amount { get; set; }
        public string DueNumber { get; set; }
        public string FirstExitCountryCode { get; set; }
        public List<string> ListOfDues { get; set; }
    }


    public class McTransferReceiptListOfDuesDto
    {
        public long Id { get; set; }
        public long TransferReceiptId { get; set; }
        public string DueReference { get; set; }
    }
}
