﻿using static CUAIntegrations.Application.Services.CUAServices.DTOs.AuthenticationServiceDTOs;

namespace CUAIntegrations.Application.Services.CUAServices
{
    public interface ICUAAuthenticationService
    {
        Task<HttpClient> PrepareClient(HttpClient _httpClient);
        Task<GetAuthenticateDTO> Authenticate(AuthenticateDTO authenticateDTO);
    }
}