﻿using CUAIntegrations.Application.Features.V1.Queries.OutBoundedForMC.DueNumbers;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace CUAIntegrations.Controllers.V1.Queries.MC.CUA.DueNumber
{
    [ApiController]
    public class DueNumberController : BaseMCController
    {
        private readonly IMediator _mediator;

        public DueNumberController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet("{dueNumber}/{firstExitCountryCode}")]
        [ApiVersion("1")]
        public async Task<GetDueNumberResponse> GetDueNumber(
               [FromRoute] string dueNumber,
               [FromRoute] string firstExitCountryCode)
        {
            var query = new GetDueNumberQuery(dueNumber, firstExitCountryCode);

            return await _mediator.Send(query);
        }
    }
}
