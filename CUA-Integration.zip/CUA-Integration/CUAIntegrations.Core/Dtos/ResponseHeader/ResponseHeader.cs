﻿namespace CUAIntegrations.Kernel.Domain.Dtos.ResponseHeader
{
    public class ResponseHeader
    {
        public string RequestId { get; set; } = default!;
        public int StatusCode { get; set; }
        public string Message { get; set; } = "Success";
        public DateTime ResponseTimestamp { get; set; } = DateTime.UtcNow;
    }

}
