﻿
namespace CUAIntegrations.Kernel.Domain.Dtos.ProviderFeedbackRequest
{
    public class ProviderFeedbackRequest
    {
        public string FeedbackId { get; set; }
        public string OriginalRequestId { get; set; }
        public string ApiEndpoint { get; set; }
        public ErrorResponse.ErrorResponse ErrorResponse { get; set; } 
    }

}
