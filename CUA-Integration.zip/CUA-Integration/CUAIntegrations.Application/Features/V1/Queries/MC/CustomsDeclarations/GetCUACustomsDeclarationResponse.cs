﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;

namespace CUAIntegrations.Application.Features.V1.Queries.OutBoundedForMC.CustomsDeclarations
{
    public class GetCUACustomsDeclarationResponse
    {
        public ErrorResponse? ErrorResponse { get; set; }
        public CUACustomsDeclarationsDto? CustomsDeclarationEntity { get; set; }
    }
    public class CUACustomsDeclarationsDto
    {
        public long Id { get; set; }

        public int Version { get; set; }

        public string DeclarationNumber { get; set; }


        public DateTime DeclarationDate { get; set; }
        //TODO Lookups TableName =>  gcc.GCC_CustomsDataTypesLookup
        public string DeclarationType { get; set; }
        //TODO Lookups TableName => gcc.GCC_CustomsPortTypesLookup
        public string PortType { get; set; }
        public string? DeliveryOrderNumber { get; set; }
        public string ImporterExporterName { get; set; }
        public string ImporterExporterCustomsId { get; set; }

        public decimal NetWeight { get; set; }
        public decimal GrossWeight { get; set; }
        //TODO Lookups TableName => GCC_UnitCodesLookup
        public string Measurement { get; set; }

        public string? CarrierCaptainDriver { get; set; }
        public string? CarrierName { get; set; }
        public string? CommercialRegistrationNumber { get; set; }
        public string? TinNumber { get; set; }

        public string? VoyageFlightNumber { get; set; }
        public string? ExportedTo { get; set; }

        public int? NumberOfPackages { get; set; }
        public string? BlAwbManifestNo { get; set; }
        public string? PortOfLoading { get; set; }
        public string? MarksAndNumbers { get; set; }
        public string? PortOfDischarge { get; set; }


        //TODO Lookups TableName => GCC_CountryCodesLookup
        public string? DestinationCountryCode { get; set; }
        public string? IntercessorCompany { get; set; }

        public string? ClearingAgentName { get; set; }
        public string? ClearingAgentCode { get; set; }
        public string? LicenseNumber { get; set; }
        //TODO Lookups TableName =>GCC_RiskResultsLookup
        public string? RiskOutcome { get; set; }
        //TODO Lookups TableName => gcc.GCC_ValuationMethodsLookup
        public string? ValuationMethod { get; set; }
        public string? OtherRemarks { get; set; }
        public DateTime ReleaseDate { get; set; }

        public string? Route { get; set; }
        public string? ExitPort { get; set; }

        public decimal TotalDuty { get; set; }
        public decimal DefiniteFee { get; set; }
        public decimal? Vat { get; set; }
        public decimal? ExciseTax { get; set; }
        public decimal? OtherCharges { get; set; }
        public decimal? Insured { get; set; }

        public string? DueNumber { get; set; }
        public string? UnifiedCustomsCode { get; set; }

        public List<CUAItemsDto> Items { get; set; } = new();
        public List<CUAPaymentsDto>? Payments { get; set; }



    }

    public class CUAPaymentsDto
    {

        public long Id { get; set; }
        public long DeclarationId { get; set; }
        //TODO Lookups TableName => GCC_PaymentMethodsLookup
        public string? Method { get; set; }
        public string? No { get; set; }
        public DateTime? Date { get; set; }
        public string? Bank { get; set; }
    }

    public class CUAItemsDto
    {

        public long Id { get; set; }
        public long DeclarationId { get; set; }
        public string HsCode { get; set; }
        public string GoodsDescription { get; set; }
       //TODO Lookups TableName => GCC_CountryCodesLookup
        public string OriginCountryCode { get; set; }
        public decimal CifForeignValue { get; set; }
        public decimal CifLocalValue { get; set; }
        public string DutyRate { get; set; }
        public string? IncomeType { get; set; }
        public decimal TotalDuty { get; set; }
        public decimal NetWeight { get; set; }
        public decimal GrossWeight { get; set; }
        public string? ExemptionApprovalRef { get; set; }

        public CUACurrenciesDto Currency { get; set; }
        public CUAPackagesDto? Packages { get; set; }
        public CUAItemDetailsDto Item { get; set; }
        public CUAAIPsDto? AIP { get; set; }
        public List<CUARestrictionsDto>? Restrictions { get; set; }
    }
    
    public class CUACurrenciesDto
    {
        public long? Id { get; set; }
        public long? ItemId { get; set; }
        //TODO Lookups TableName => GCC_CurrencyCodesLookup
        public string Type { get; set; }
        public decimal Value { get; set; }
    }

    public class CUAPackagesDto
    {
        public long Id { get; set; }
        public long ItemId { get; set; }
        public decimal? Quantity { get; set; }
        //TODO Lookups TableName => GCC_PackageTypesLookup
        public string? Type { get; set; }
    }
   
    public class CUAItemDetailsDto
    {
        public long Id { get; set; }
        public long ItemId { get; set; }
        public decimal Quantity { get; set; }
        //TODO Lookups TableName => GCC_UnitCodesLookup
        public string Unit { get; set; }
    }
    
    public class CUAAIPsDto
    {
        public long Id { get; set; }
        public long ItemId { get; set; }
        public string? GazetteNumber { get; set; }
        public decimal? Duty { get; set; }
    }
 
    public class CUARestrictionsDto
    {
        public long Id { get; set; }
        public long ItemId { get; set; }
        public string Agency { get; set; }
        public string? ReleaseRef { get; set; }
    }
}
