﻿using System.Text.Json.Serialization;

namespace CUAIntegrations.Application.Services.CUAServices.DTOs
{
    public class AuthenticationServiceDTOs
    {
        public class AuthenticateDTO
        {
            [JsonPropertyName("grant_type")]
            public string GrantType { get; set; }

            [JsonPropertyName("code")]
            public string Code { get; set; }

            [JsonPropertyName("refresh_token")]
            public string RefreshToken { get; set; }
        }

        public class GetAuthenticateDTO
        {
            [JsonPropertyName("access_token")]
            public string Access_Token { get; set; }

            [JsonPropertyName("token_type")]
            public string Token_Type { get; set; }

            [JsonPropertyName("expires_in")]
            public int Expires_In { get; set; }

            [JsonPropertyName("refresh_token")]
            public string Refresh_Token { get; set; }

            [JsonPropertyName("scope")]
            public string Scope { get; set; }
        }
    }
}
