﻿using CUA_GCC_Integration.Core.Helpers;
using CUAIntegrations.Application.Services.CUAServices;
using CUAIntegrations.Kernel.Core.InstanseScopeTypes;
using CUAIntegrations.Kernel.Core.Logging;
using CUAIntegrations.Kernel.Core.Wrappers;
using CUAIntegrations.Kernel.Domain.Entities.LoggingEntities;
using CUAIntegrations.Repository.Base;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System.Security.Cryptography.X509Certificates;

namespace CUAIntegrations.Application.Services.Http
{
    public class CUAClient : IScoped, ICUAClient
    {
        private readonly IConfiguration _configuration;
        private readonly IRequestLogger _logger;
        private readonly ICUAIntegrationUnitOfWork _unitOfWork;
        private readonly ITimeHelper _timeHelper;
        private readonly ICUAAuthenticationService _cuaAuthenticationService;

        private HttpClient _client;
        HttpClientHandler _clientHandler;

        public CUAClient(
            IRequestLogger logger,
            ICUAIntegrationUnitOfWork unitOfWork,
            ITimeHelper timeHelper,
            ICUAAuthenticationService cuaAuthenticationService,
            IConfiguration configuration)
        {
            _clientHandler = new HttpClientHandler()
            {
                SslProtocols = System.Security.Authentication.SslProtocols.Tls12
            };

            _clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
            _logger = logger;
            _unitOfWork = unitOfWork;
            _timeHelper = timeHelper;
            _cuaAuthenticationService = cuaAuthenticationService;

            AttachCertificate();
            _client = new HttpClient(_clientHandler);
            _configuration = configuration;
        }

        private void AttachCertificate()
        {
            X509Store x509Store = new X509Store(StoreName.My, StoreLocation.LocalMachine);
            x509Store.Open(OpenFlags.ReadOnly | OpenFlags.OpenExistingOnly);

            X509Certificate2Collection certificate2Collection =
                x509Store.Certificates.Find(X509FindType.FindByThumbprint, _configuration["Authentication:ProxyToCUA:CertificateThumbPrint"], false);

            if (certificate2Collection == null ||
                certificate2Collection.Count == 0 ||
                certificate2Collection.Count > 1)
            {
                throw new Exception("Certificate not found");
            }
            var cert = certificate2Collection[0];
            _clientHandler.ClientCertificates.Add(cert);
        }

        public async Task<Response<T>> GetAsync<T>(string url)
        {
            await _cuaAuthenticationService.PrepareClient(_client);

            var requestLoggingId = await LogRequestAsync(url, _client.DefaultRequestHeaders.ToDictionary(a => a.Key, a => a.Value), "GET");

            var res = await _client.GetAsync(url);
            var response = await res.Content.ReadAsStringAsync();
            var resHeaders = res.Headers.ToDictionary(a => a.Key, a => a.Value);

            await LogResponseAsync((int)res.StatusCode, response, resHeaders, requestLoggingId);

            if (res.IsSuccessStatusCode)
            {
                return new Response<T> { Succeeded = true, Data = JsonConvert.DeserializeObject<T>(response), JSONData = response, RequestLogId = requestLoggingId };
            }
            return new Response<T> { StatusCode = (int)res.StatusCode, Message = response, RequestLogId = requestLoggingId };
        }

        private async Task<long> LogRequestAsync(
         string url,
         Dictionary<string, IEnumerable<string>> headers,
         string method,
         string? requestBody = "")
        {
            var request = new RequestLogging();
            request.Endpoint = url;
            request.Direction = 'O';
            request.HttpMethod = method;
            request.ClientId = "Proxy";

            request.XRequestId = Guid.NewGuid().ToString();
            request.XCorrelationId = headers[RequestHeadersConstants.X_CORRELATION_ID].ToString();

            request.Headers = JsonConvert.SerializeObject(headers ?? new Dictionary<string, IEnumerable<string>>());
            request.RequestBody = requestBody ?? "";

            request.RequestTime = _timeHelper.GetCurrentTime();

            // Save in DB
            var addedLog = await _unitOfWork.RequestLoggingRepository.AddAsync(request);
            await _unitOfWork.CommitAsync();

            // return logging id
            return addedLog.Id;
        }

        private async Task LogResponseAsync(
            int statusCode,
            string? responseBody,
            Dictionary<string, IEnumerable<string>> headers,
            long requestId
        )
        {
            var responseLogging = new ResponseLogging();
            responseLogging.RequestId = requestId;
            responseLogging.ResponseTime = _timeHelper.GetCurrentTime();

            // Add response body
            responseLogging.ResponseBody = responseBody ?? "";

            // Add status code
            responseLogging.StatusCode = statusCode;

            // Correct serialization — do NOT serialize twice!
            responseLogging.ResponseHeaders = JsonConvert.SerializeObject(headers ?? new Dictionary<string, IEnumerable<string>>());

            await _unitOfWork.ResponseLoggingRepository.AddAsync(responseLogging);
            await _unitOfWork.CommitAsync();
        }

        public Task<Response<T>> GetMokAsync<T>(string entityId, string entityType, string url, Dictionary<string, string> headers = null)
        {
            throw new NotImplementedException();
        }
    }
}