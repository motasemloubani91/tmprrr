using CUAIntegrations.Kernal.Domain.Dtos.ErrorResponse;

namespace CUA_GCC_Integration.Core.Exceptions.ResponseValidation
{
    public class RequestedDueNumbersNotExistException : Exception
    {
        public int ErrorCode { get; private set; } //mapped to Status property in ErrorResponse
        public string Message { get; private set; } = "The response was rejected because the list of due numbers in the response does not include the requested due number.";
        public string Reason { get; private set; } = "ResponseValidation";
        public List<ErrorDetail>? Details { get; set; }

        public RequestedDueNumbersNotExistException()
        {
            ErrorCode = 400;
        }

        public RequestedDueNumbersNotExistException(List<ErrorDetail>? errorDetails)
        {
            ErrorCode = 400;
            Details = errorDetails;
        }

        protected RequestedDueNumbersNotExistException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }
    }
}