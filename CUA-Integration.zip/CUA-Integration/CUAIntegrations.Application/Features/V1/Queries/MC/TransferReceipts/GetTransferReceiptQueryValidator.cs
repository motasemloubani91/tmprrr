﻿using FluentValidation;
using CUAIntegrations.Application.Features.V1.Queries.CUA;

namespace CUAIntegrations.Application.Features.V1.Queries.OutBoundedForMC.TransferReceipts
{
    public class GetTransferReceiptQueryValidator : AbstractValidator<GetTransferReceiptQuery>
    {
        private readonly ISharedValidationHelper _validationHelper;

        public GetTransferReceiptQueryValidator(ISharedValidationHelper validationHelper)
        {
            _validationHelper = validationHelper;

            // --------------------------------------------------------------------
            // DueNumber 
            // --------------------------------------------------------------------
            //commentedForTestOnly
            RuleFor(x => x.DueNumber)
                .NotEmpty()
                .WithErrorCode("ERR-02")
                .WithMessage("DueNumber is mandatory.");

            RuleFor(x => x.DueNumber)
                .Length(65)
                .WithErrorCode("ERR-03")
                .WithMessage("DueNumber must be exactly 65 digits.");


            // --------------------------------------------------------------------
            // FirstExitCountryCode 
            // --------------------------------------------------------------------
            RuleFor(x => x.FirstExitCountryCode)
                .NotEmpty()
                .WithErrorCode("ERR-02")
                .WithMessage("FirstExitCountryCode is mandatory.");

            RuleFor(x => x.FirstExitCountryCode)
                .Length(2)
                .WithErrorCode("ERR-03")
                .WithMessage("FirstExitCountryCode must be exactly 2 characters.");

            //RuleFor(x => x.FirstExitCountryCode)
            //    .MustAsync(async (code, _) => await _validationHelper.IsValidCountryCode(code))
            //    .WithErrorCode("ERR-29")
            //    .WithMessage("FirstExitCountryCode does not match the reference list.");


        }
    }
}
