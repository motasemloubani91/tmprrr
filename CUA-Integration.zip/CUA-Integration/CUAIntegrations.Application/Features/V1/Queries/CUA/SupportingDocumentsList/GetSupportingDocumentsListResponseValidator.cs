﻿using CUAIntegrations.Application.Features.V1.Queries.Mc.SupportingDocumentsList;
using FluentValidation;

namespace CUAIntegrations.Application.Features.V1.Queries.CUA.SupportingDocumentsList
{
    public class GetSupportingDocumentListResponseValidator : AbstractValidator<CUASupportingDocumentsListResponse>
    {
        public GetSupportingDocumentListResponseValidator()
        {

            {

                RuleFor(x => x.SupportingDocumentListEntity)
                .SetValidator(new SupportingDocumentsListDTOValidator());
            }

        }
    }
    public class GetSupportingDocumentsListDTOValidator : AbstractValidator<SupportingDocumentsListDTO>
    {
        public GetSupportingDocumentsListDTOValidator()
        {
            RuleFor(x => x.RelatedDeclarationNumber)
              .NotEmpty()
              .WithErrorCode("ERR-08")
              .WithMessage("Missing mandatory field: RelatedDeclarationNumber.");

            RuleForEach(x => x.Documents)
                .SetValidator(new CUASupportingDocumentDtoValidator());
        }
    }

    public class CUASupportingDocumentDtoValidator : AbstractValidator<GetSupportingDocumentDTO>
    {
        public CUASupportingDocumentDtoValidator()
        {
            RuleFor(x => x.DocumentCategory)
                .NotEmpty()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: documentCategory.");

            RuleFor(x => x.DocumentCategory)
                .Length(3)
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: documentCategory must be 3 characters.");

            RuleFor(x => x.DocumentCategory)
                .Matches("^[A-Za-z0-9]+$")
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid format: documentCategory must be alphanumeric.");

            // documentName 
            RuleFor(x => x.DocumentName)
                .NotEmpty()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: documentName.");

            RuleFor(x => x.DocumentName)
                .MaximumLength(70)
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: documentName max length is 70.");

            RuleFor(x => x.DocumentName)
                .Matches("^[A-Za-z0-9 _\\-\\.]+$")
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid format: documentName must be alphanumeric or include _ - .");

            // documentIdNumber - 
            RuleFor(x => x.DocumentIdNumber)
                .NotEmpty()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: documentIdNumber.");

            RuleFor(x => x.DocumentIdNumber)
                .MaximumLength(70)
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: documentIdNumber max length is 70.");

            RuleFor(x => x.DocumentIdNumber)
                .Matches("^[A-Za-z0-9]+$")
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid format: documentIdNumber must be alphanumeric.");

            // documentLanguage 
            RuleFor(x => x.DocumentLanguage)
                .MaximumLength(2)
                .When(x => !string.IsNullOrEmpty(x.DocumentLanguage))
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: documentLanguage must be 2 characters.");

            RuleFor(x => x.DocumentLanguage)
                .Matches("^[a-zA-Z]+$")
                .When(x => !string.IsNullOrEmpty(x.DocumentLanguage))
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid format: documentLanguage must be alphabetic.");

            // documentLink
            RuleFor(x => x.DocumentLink)
                .MaximumLength(512)
                .When(x => !string.IsNullOrEmpty(x.DocumentLink))
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: documentLink max length is 512.");
        }
    }
}