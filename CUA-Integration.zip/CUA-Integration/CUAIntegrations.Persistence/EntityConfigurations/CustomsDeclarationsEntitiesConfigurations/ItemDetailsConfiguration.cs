﻿using CUAIntegrations.Kernel.Domain.Entities.CustomsDeclarationsEntities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace CUAIntegrations.Persistence.EntityConfigurations.CustomsDeclarationsEntitiesConfigurations
{
    public class ItemDetailsConfiguration : IEntityTypeConfiguration<ItemDetails>
    {
        public void Configure(EntityTypeBuilder<ItemDetails> entity)
        {
            entity.ToTable("GCC_ItemDetails", "GCC");
            entity.HasKey(a => a.Id);

            entity.Property(a => a.Quantity).IsRequired();
            entity.Property(a => a.Unit).IsRequired().HasMaxLength(6);

            
        }
    }
}
