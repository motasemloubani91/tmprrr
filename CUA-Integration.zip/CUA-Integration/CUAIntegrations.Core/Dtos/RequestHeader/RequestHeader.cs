﻿namespace CUAIntegrations.Kernel.Domain.Dtos.RequestHeader
{
    public class RequestHeader
    {
        public string RequestId { get; set; } = Guid.NewGuid().ToString();
        public string SourceSystem { get; set; } = "GCC-Country-System";
        public DateTime RequestTimestamp { get; set; } = DateTime.UtcNow;
    }
}
