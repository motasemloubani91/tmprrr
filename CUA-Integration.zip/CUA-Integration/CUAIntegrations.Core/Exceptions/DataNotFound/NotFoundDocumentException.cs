using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;
using System.Net;

namespace CUA_GCC_Integration.Core.Exceptions.DataNotFound
{
    public class NotFoundDocumentException : SystemIntegrationException
    {
        const string message = "The requested document was not found in the issuing country�s system.";
        const string reason = "Data Not Found.";

        public NotFoundDocumentException() :
            base(errorCode: HttpStatusCode.NotFound,
                message: message,
                reason: reason)
        {
        }

        public NotFoundDocumentException(
            string message = message,
            string reason = reason,
            List<ErrorDetail>? details = null) :
            base(errorCode: HttpStatusCode.NotFound,
                message: message,
                reason: reason,
                details: details)
        {
        }
    }
}