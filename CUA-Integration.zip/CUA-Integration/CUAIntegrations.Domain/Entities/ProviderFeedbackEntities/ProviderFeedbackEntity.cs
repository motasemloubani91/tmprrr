﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CUAIntegrations.Kernel.Domain.Entities.ProviderFeedbackEntities
{
    public class ProviderFeedbackEntity
    {
        public int Id { get; set; }
        public string FeedbackId { get; set; }
        public string OriginalRequestId { get; set; }
        public string ApiEndpoint { get; set; }
        public string? ErrorResponseJson { get; set; }
        public string? OutboundRequestHeader { get; set; }
        public DateTime CreatedOn { get; set; }
    }
}
