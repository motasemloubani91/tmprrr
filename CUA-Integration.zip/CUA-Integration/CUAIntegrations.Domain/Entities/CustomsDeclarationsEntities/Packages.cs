﻿namespace CUAIntegrations.Kernel.Domain.Entities.CustomsDeclarationsEntities
{

    public class Packages
    {
        public long Id { get; set; }
        public long ItemId { get; set; }
        public decimal? Quantity { get; set; }
        public string? Type { get; set; }
    }
}
