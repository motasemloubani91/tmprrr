﻿using Microsoft.AspNetCore.Http;
using System.Collections;
using System.Reflection;
using System.Text.Json;

namespace CUAIntegrations.Kernel.Core.Utilities
{
    public static class EntityCompare
    {
        /// <summary>
        /// Deep compares two entities of the same type (including nested properties and lists).
        /// Returns true if identical, false if any difference is found.
        /// </summary>
        public static bool AreEqual<T>(T obj1, T obj2)
        {
            if (obj1 == null && obj2 == null)
                return true;
            if (obj1 == null || obj2 == null)
                return false;

            var type = typeof(T);

            // For simple types or strings
            if (type.IsPrimitive || type.IsEnum || type == typeof(string) || type == typeof(decimal) || type == typeof(DateTime))
                return obj1!.Equals(obj2);

            // Handle collections
            if (typeof(IEnumerable).IsAssignableFrom(type) && type != typeof(string))
            {
                var list1 = ((IEnumerable)obj1).Cast<object>().ToList();
                var list2 = ((IEnumerable)obj2).Cast<object>().ToList();

                if (list1.Count != list2.Count)
                    return false;

                for (int i = 0; i < list1.Count; i++)
                {
                    if (!AreEqual(list1[i], list2[i]))
                        return false;
                }

                return true;
            }

            // Compare complex objects property by property
            foreach (var prop in type.GetProperties(BindingFlags.Public | BindingFlags.Instance))
            {
                var val1 = prop.GetValue(obj1);
                var val2 = prop.GetValue(obj2);

                if (prop.PropertyType.IsPrimitive || prop.PropertyType == typeof(string) ||
                    prop.PropertyType == typeof(decimal) || prop.PropertyType == typeof(DateTime))
                {
                    if (!Equals(val1, val2))
                        return false;
                }
                else
                {
                    // Recursive check for sub-objects
                    if (!AreEqual(val1, val2))
                        return false;
                }
            }

            return true;
        }

        public static bool AreJsonEqual(object obj1, object obj2)
        {
            object Normalize(object input)
            {
                if (input == null) return null;

                // If it's a string, try to deserialize JSON
                if (input is string s)
                {
                    try
                    {
                        return JsonSerializer.Deserialize<object>(s);
                    }
                    catch
                    {
                        // Not JSON string, return as is
                        return s;
                    }
                }

                // If it's an ASP.NET Request Headers object
                if (input is IHeaderDictionary headers)
                {
                    return headers.ToDictionary(h => h.Key, h => h.Value.ToString());
                }

                // Already an object
                return input;
            }

            var normalized1 = Normalize(obj1);
            var normalized2 = Normalize(obj2);

            // Serialize both normalized objects to JSON for comparison
            var options = new JsonSerializerOptions
            {
                WriteIndented = false,
                DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull
            };

            var json1 = JsonSerializer.Serialize(normalized1, options);
            var json2 = JsonSerializer.Serialize(normalized2, options);

            return json1 == json2;
        }

    }
}
