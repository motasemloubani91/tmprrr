﻿using CUAIntegrations.Application.Features.V1.Queries.CUA.CustomsDeclarations;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace CUAIntegrations.Controllers.V1.Queries.CUA.CustomsDeclarations
{
    public class CustomsDeclarationsController : BaseCUAController
    {
        private readonly IMediator _mediator;

        public CustomsDeclarationsController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet("{declarationNumber}")]
        [ApiVersion("1")]
        public async Task<OutBoundedCustomsDeclarationResponse> GetOutboundCustomsDeclaration(
            [FromRoute] string declarationNumber,
            [FromQuery] string declarationType,
            [FromQuery] string year,
            [FromQuery] string port)
        {
            var query = new GetOutBoundedCustomsDeclarationQuery(declarationNumber, declarationType,year, port);
            return await _mediator.Send(query);
        }
    }
}
