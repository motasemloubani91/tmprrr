﻿namespace CUAIntegrations.Persistence.DataAccess.ADO.NET
{
    public interface IFileTokenDataAccess
    {
        string[] GetTokenForDownload(int iDocumentId, int iReferenceId, string sSaltKey, int iOwnerOrgId, int iOwnerLocId);
    }
}