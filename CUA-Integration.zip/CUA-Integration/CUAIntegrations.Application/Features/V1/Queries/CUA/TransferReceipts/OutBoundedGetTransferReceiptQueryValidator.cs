﻿using CUA_GCC_Integration.Core.Helpers;
using CUA_GCC_Integration.Core.Exceptions.RequestValidation;
using FluentValidation;
using System.Text.RegularExpressions;

namespace CUAIntegrations.Application.Features.V1.Queries.CUA.TransferReceipts
{
    public class OutBoundedGetTransferReceiptQueryValidator
        : AbstractValidator<OutBoundedGetTransferReceiptQuery>
    {
        private readonly ISharedValidationHelper _validationHelper;

        public OutBoundedGetTransferReceiptQueryValidator(ISharedValidationHelper validationHelper)
        {
            _validationHelper = validationHelper;

            RuleFor(x => x.DueNumber)
                .NotEmpty()
                .WithErrorCode("ERR-02")
                .WithMessage("DueNumber is mandatory.");

            RuleFor(x => x.DueNumber)
                .Matches("^[0-9]+$")
                .WithErrorCode("ERR-03")
                .WithMessage("DueNumber must be numeric only.");

            RuleFor(x => x.DueNumber)
                .Length(65)
                .WithErrorCode("ERR-03")
                .WithMessage("DueNumber must be exactly 65 digits.");
            


        }
       
    }
}
