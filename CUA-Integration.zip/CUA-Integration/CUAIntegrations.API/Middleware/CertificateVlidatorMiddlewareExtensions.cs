﻿using CUAIntegrations.Kernel.Core.Exceptions;
using CUAIntegrations.Kernel.Core.Logging;
using CUAIntegrations.Repository.Base;

namespace CUAIntegrations.Kernel.Host.API.Middleware
{
    public static class CertificateValidatorMiddlewareExtension
    {
        public static IApplicationBuilder UsCertificateValidatorMiddleware(
            this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<CertificateValidatorMiddleware>();
        }
    }

    public class CertificateValidatorMiddleware
    {
        private readonly RequestDelegate next;
        private readonly IConfiguration _configurations;

        /// <summary>
        /// ExceptionMiddleware
        /// </summary>
        /// <param name="next"></param>
        public CertificateValidatorMiddleware(RequestDelegate next, IConfiguration configurations)
        {
            this.next = next;
            _configurations = configurations;
        }

        /// <summary>
        /// Invoke
        /// </summary>
        /// <param name="context"></param>
        /// <param name="logger"></param>
        /// <returns></returns>
        public async Task Invoke(HttpContext context, IRequestLogger requestLogger, ICUAIntegrationUnitOfWork unitOfWork) /* other dependencies */
        {
            var validateCertificate = Convert.ToBoolean(_configurations["Authentication:CUA:ValidateCertificate"]);
            var validateCertificateForCallBack = Convert.ToBoolean(_configurations["Authentication:CUA:ValidateCertificateForCallBack"]);

            if (context.Request.Path.Value.ToLower().Contains("mc") ||
                !validateCertificate ||
                (context.Request.Path.Value.ToLower().Contains("callback") && !validateCertificateForCallBack))
            {
                await next(context);
                return;
            }

            var cert = context.Connection.ClientCertificate;
            if (cert == null)
            {
                throw new InvalidCertificateException();
            }

            var certificateName = _configurations["Authentication:CUA:CertificateName"];
            var allowedThumbprints = _configurations["Authentication:CUA:AllowedCertificateThumbprints"].Split(",");
            var certificateIssuer = _configurations["Authentication:CUA:CertificateIssuer"];
            var certificateExpiration = _configurations["Authentication:CUA:CertificateExpiration"];

            if (!string.IsNullOrWhiteSpace(certificateName))
            {
                if (!cert.Subject.Contains(certificateName))
                {
                    throw new InvalidCertificateException();
                }
            }
            if (allowedThumbprints.Any())
            {
                if (!allowedThumbprints.Contains(cert.Thumbprint, StringComparer.OrdinalIgnoreCase))
                {
                    context.Response.StatusCode = 403;
                    await context.Response.WriteAsync("Certificate not allowed");
                    return;
                }
            }
            if (!string.IsNullOrWhiteSpace(certificateIssuer))
            {
                if (!cert.Issuer.Contains(certificateIssuer))
                {
                    throw new InvalidCertificateException();
                }
            }
            if (!string.IsNullOrWhiteSpace(certificateExpiration))
            {
                var expirationDateTimeSucceeded = DateTime.TryParse(certificateExpiration, out DateTime expirationDateTime);
                if (expirationDateTimeSucceeded)
                {
                    if (DateTime.Now >= expirationDateTime)
                    {
                        throw new InvalidCertificateException();
                    }
                }
            }

            await next(context);
        }
    }
}