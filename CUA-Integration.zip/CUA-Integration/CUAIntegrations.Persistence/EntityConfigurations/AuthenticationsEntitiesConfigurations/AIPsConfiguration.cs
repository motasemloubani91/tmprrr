﻿using CUAIntegrations.Kernel.Domain.Entities.AuthenticationsEntities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace CUAIntegrations.Persistence.EntityConfigurations.CustomsDeclarationsEntitiesConfigurations
{
    public class IntegrationAuthenticationConfiguration : IEntityTypeConfiguration<IntegrationsAuthentication>
    {
        public void Configure(EntityTypeBuilder<IntegrationsAuthentication> entity)
        {
            entity.ToTable("IntegrationsAuthentications", "GCC");
            entity.HasKey(a => a.Id);
            entity.Property(a => a.Id).ValueGeneratedOnAdd();
        }
    }
}
