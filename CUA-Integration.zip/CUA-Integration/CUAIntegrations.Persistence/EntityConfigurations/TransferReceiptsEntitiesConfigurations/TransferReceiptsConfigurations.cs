﻿using CUAIntegrations.Kernel.Domain.Entities.TransferReceipts;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace CUA_GCC_Integration.Persistence.EntityConfigurations.TransferReceiptsEntitiesConfigurations
{
    public class TransferReceiptsConfiguration : IEntityTypeConfiguration<TransferReceipt>
    {
        public void Configure(EntityTypeBuilder<TransferReceipt> entity)
        {
            entity.ToTable("GCC_TransferReceipts", schema: "GCC");

            entity.HasKey(e => e.Id);
            entity.Property(e => e.Id)
                 .ValueGeneratedOnAdd();

            entity.Property(a => a.Version)
                  .IsRequired()
                  .HasDefaultValue(1);
            entity.Property(e => e.FileName)
                  .IsRequired()
                  .HasMaxLength(70);

            entity.Property(e => e.ImageUrl)
                  .IsRequired()
                  .HasMaxLength(512);

            entity.Property(e => e.FileDate)
                  .IsRequired()
                  .HasMaxLength(14);

            entity.Property(e => e.Amount)
                  .IsRequired()
                  .HasColumnType("decimal(16,6)");
        }
    }
}
