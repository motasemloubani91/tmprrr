﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;

namespace CUA_GCC_Integration.Core.Exceptions.ServerError
{
    public class GatewayTimeoutException : Exception
    {
        public int ErrorCode { get; private set; } //mapped to Status property in ErrorResponse
        public string Message { get; private set; } = "Gateway timeout. Processing exceeded time limit.";
        public string Reason { get; private set; } = "TimeoutError";
        public List<ErrorDetail>? Details { get; set; }

        public GatewayTimeoutException()
        {
            ErrorCode = 504;
        }
        public GatewayTimeoutException(List<ErrorDetail>? errorDetails)
        {
            ErrorCode = 504;
            Details = errorDetails;
        }

        protected GatewayTimeoutException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }
    }
}
