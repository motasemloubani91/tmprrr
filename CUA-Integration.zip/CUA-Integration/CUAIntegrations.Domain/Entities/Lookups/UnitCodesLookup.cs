﻿using Microsoft.Extensions.Options;
using static System.Net.Mime.MediaTypeNames;

namespace CUAIntegrations.Kernel.Domain.Entities.Lookups
{
    public class UnitCodesLookup
    {
        public long Id { get; set; }
        public string? Code { get; set; }
        public string? ArabicDescription { get; set; }
        public string? EnglishDescription { get; set; }
        //public string? Notes { get; set; }
        public string? Quantity { get; set; }
        public string? ConversionFactor { get; set; }
        public string? Symbol { get; set; }
        public string? Description { get; set; }


    }
}
