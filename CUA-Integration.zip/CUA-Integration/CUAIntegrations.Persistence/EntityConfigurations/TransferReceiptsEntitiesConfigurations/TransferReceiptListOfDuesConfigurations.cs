﻿using CUAIntegrations.Kernel.Domain.Entities.TransferReceipts;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace CUAIntegrations.Persistence.EntityConfigurations.TransferReceiptsEntitiesConfigurations
{
    public class TransferReceiptListOfDuesConfiguration : IEntityTypeConfiguration<TransferReceiptListOfDues>
    {
        public void Configure(EntityTypeBuilder<TransferReceiptListOfDues> entity)
        {
            entity.ToTable("GCC_TransferReceiptListOfDues", schema: "GCC");

            entity.HasKey(e => e.Id);
            entity.Property(e => e.Id)
                 .ValueGeneratedOnAdd();
            entity.Property(e => e.DueReference)
                  .IsRequired()
                  .HasMaxLength(65);

        }
    }
}
