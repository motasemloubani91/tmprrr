﻿namespace CUAIntegrations.Kernel.Domain.Entities.Lookups
{
    public class ValuationMethodsLookup
    {
        public long Id { get; set; }
        public string? Code { get; set; }
        public string? ArabicDescription { get; set; }
        public string? EnglishDescription { get; set; }
        public string? Notes { get; set; }
        
    }
}
