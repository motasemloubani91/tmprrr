﻿//using CUA_GCC_Integration.Core.Exceptions.RequestValidation;
//using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;
//using FluentValidation;
//using MediatR;

//public class ResponseValidationBehavior<TRequest, TResponse> : IPipelineBehavior<TRequest, TResponse>
//    where TRequest : notnull
//{
//    private readonly IEnumerable<IValidator<TResponse>> _validators;

//    public ResponseValidationBehavior(IEnumerable<IValidator<TResponse>> validators)
//    {
//        _validators = validators;
//    }

//    public async Task<TResponse> Handle(
//        TRequest request,
//        RequestHandlerDelegate<TResponse> next,
//        CancellationToken cancellationToken)
//    {
//        var response = await next();

//        var typedValidators = _validators
//            .Where(v => v is IValidator<TResponse>)
//            .Cast<IValidator<TResponse>>()
//            .ToList();

//        if (!typedValidators.Any())
//            return await next();

//        var context = new ValidationContext<TResponse>(response);

//        var validationResults = await Task.WhenAll(
//            typedValidators.Select(v => v.ValidateAsync(context, cancellationToken))
//        );

//        var failures = validationResults
//            .SelectMany(r => r.Errors)
//            .Where(f => f != null)
//            .ToList();

//        if (failures.Any())
//        {
//            var errorsDetails = failures.Select(error => new ErrorDetail
//            {
//                InnerCode = error.ErrorCode,
//                Message = error.ErrorMessage,
//                Reason = error.ErrorMessage,
//                Location = error.PropertyName,
//                Severity = error.Severity.ToString()
//            })
//            .ToList();

//            throw new InvalidFieldValueException(details: errorsDetails);
//        }

//        return response;
//    }
//}
