﻿using Microsoft.EntityFrameworkCore;
using CUAIntegrations.Kernel.Domain.Entities.LoggingEntities;
using Microsoft.EntityFrameworkCore.Metadata.Builders;


namespace CUAIntegrations.Persistence.EntityConfigurations.LoggingEntitiesConfigurations
{
    internal class ProxyLogConfigurations : IEntityTypeConfiguration<ProxyLogs>
    {
        public void Configure(EntityTypeBuilder<ProxyLogs> entity)
        {
            entity.ToTable("GCC_ProxyLogs", "GCC");
            entity.HasKey(e => e.LogId);

            entity.Property(e => e.LogId)
                  .ValueGeneratedOnAdd();

            entity.Property(e => e.Timestamp).IsRequired();

            entity.Property(e => e.RequestId).HasMaxLength(36).IsRequired();
            entity.Property(e => e.CorrelationId).HasMaxLength(36).IsRequired();

            entity.Property(e => e.DataEntityId).IsRequired();
            entity.Property(e => e.DataEntityTypeId).IsRequired();

            entity.Property(e => e.SourceSystem).HasMaxLength(50).IsRequired();
            entity.Property(e => e.TargetSystem).HasMaxLength(50).IsRequired();
            entity.Property(e => e.Direction).HasMaxLength(20).IsRequired();
            entity.Property(e => e.HttpMethod).HasMaxLength(10).IsRequired();
            entity.Property(e => e.HttpPath).HasMaxLength(500).IsRequired();

            entity.Property(e => e.HttpStatusCode);
            entity.Property(e => e.LatencyMs);

            entity.Property(e => e.RequestHeaders);
            entity.Property(e => e.RequestBody);
            entity.Property(e => e.RequestSizeBytes);

            entity.Property(e => e.ResponseHeaders);
            entity.Property(e => e.ResponseBody);
            entity.Property(e => e.ResponseSizeBytes);

            entity.Property(e => e.ErrorMessage);
            entity.Property(e => e.ErrorStackTrace);

            entity.Property(e => e.ClientIp).HasMaxLength(50);
            entity.Property(e => e.ApiVersion).HasMaxLength(20);
            entity.Property(e => e.ProxyNodeId).HasMaxLength(50);
            entity.Property(e => e.SessionId).HasMaxLength(100);
            entity.Property(e => e.UserId).HasMaxLength(100);
            entity.Property(e => e.Tags).HasMaxLength(500);

            entity.Property(e => e.CreatedAt).IsRequired();
        }
    }
}
