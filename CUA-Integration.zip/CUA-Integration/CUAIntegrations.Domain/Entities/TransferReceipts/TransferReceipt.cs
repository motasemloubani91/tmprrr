﻿namespace CUAIntegrations.Kernel.Domain.Entities.TransferReceipts
{

    public class TransferReceipt
    {

        public long Id { get; set; }
        public int Version { get; set; }
        public string FileName { get; set; } 
        public string ImageUrl { get; set; } 
        public DateTime FileDate { get; set; } 
        public decimal Amount { get; set; }

        public string DueNumber { get; set; }

        public List<TransferReceiptListOfDues> ListOfDues { get; set; }
    }
}

