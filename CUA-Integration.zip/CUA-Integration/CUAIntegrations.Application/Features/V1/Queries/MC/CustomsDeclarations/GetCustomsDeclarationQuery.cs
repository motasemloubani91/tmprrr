﻿using CUAIntegrations.Application.Features.V1.Queries.Mc.CustomsDeclarations;
using MediatR;

namespace CUAIntegrations.Application.Features.V1.Queries.OutBoundedForMC.CustomsDeclarations
{
    public class GetCustomsDeclarationQuery : IRequest<GetCustomsDeclarationResponse>
    {
        public string DeclarationNumber { get; set; }
        public string IssuingCountryCode { get; set; }
        
        public string? DeclarationType { get; set; }
        public string? Year { get; set; }
        public string? Port { get; set; }
    }
}
