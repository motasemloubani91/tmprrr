﻿using FluentValidation;

namespace CUAIntegrations.Application.Features.V1.Queries.CUA.DueNumbers
{
    public class OutBoundedGetDueNumberQueryValidator
        : AbstractValidator<OutBoundedGetDueNumberQuery>
    {
        private readonly ISharedValidationHelper _validationHelper;

        public OutBoundedGetDueNumberQueryValidator(ISharedValidationHelper validationHelper)
        {
            _validationHelper = validationHelper;

            RuleFor(x => x.DueNumber)
                .NotEmpty()
                .WithErrorCode("ERR-02")
                .WithMessage("DueNumber is mandatory.");

            RuleFor(x => x.DueNumber)
                .Length(65)
                .WithErrorCode("ERR-03")
                .WithMessage("DueNumber must be exactly 65 characters.");

            RuleFor(x => x.DueNumber)
                .Matches("^[A-Za-z0-9]+$")
                .WithErrorCode("ERR-03")
                .WithMessage("DueNumber must be alphanumeric.");
            
        }
    }
}
