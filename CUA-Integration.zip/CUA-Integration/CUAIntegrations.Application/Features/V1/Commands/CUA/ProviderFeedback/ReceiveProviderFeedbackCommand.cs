﻿using MediatR;
using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;
using CUAIntegrations.Kernel.Domain.Dtos.ProviderFeedbackRequest;

namespace CUAIntegrations.Application.Features.V1.Commands.CUA.ProviderFeedback
{
    public record ReceiveProviderFeedbackCommand(
        ProviderFeedbackRequest Feedback
    ) : IRequest<ReceiveProviderFeedbackResponse>;

    public class ReceiveProviderFeedbackResponse
    {
        public bool Acknowledged { get; set; }
        public string? FeedbackId { get; set; }
        public string? Message { get; set; }
        public ErrorResponse? ErrorResponse { get; set; }
    }
}
