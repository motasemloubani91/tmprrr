﻿using CUAIntegrations.Application.Features.V1.Queries.OutBoundedForMC.CustomsDeclarations;
using CUAIntegrations.Kernel.Domain.Entities.CustomsDeclarationsEntities;
using CUAIntegrations.Persistence.DataAccess.ADO.NET.Models;
namespace CUAIntegrations.Application.Features.V1.Queries.CUA.CustomsDeclarations
{
    public static class CustomsDeclarationMapper
    {
       
        public static CUACustomsDeclarationsDTO ModelToDTO(CUACustomsDeclarationsModel model)
        {
            if (model == null) return null;

            var entity = new CUACustomsDeclarationsDTO();

            entity.DeclarationNumber = model.DeclarationNumber;
            entity.DeclarationDate = model.DeclarationDate;
            entity.DeclarationType = model.DeclarationType;
            entity.PortType = model.PortType;
            entity.DeliveryOrderNumber = model.DeliveryOrderNumber;
            entity.ImporterExporterName = model.ImporterExporterName;
            entity.ImporterExporterCustomsId = model.ImporterExporterCustomsId;
            entity.NetWeight = model.NetWeight;
            entity.GrossWeight = model.GrossWeight;
            entity.Measurement = model.Measurement;
            entity.CarrierCaptainDriver = model.CarrierCaptainDriver;
            entity.CarrierName = model.CarrierName;
            entity.CommercialRegistrationNumber = model.CommercialRegistrationNumber;
            entity.TinNumber = model.TinNumber;
            entity.VoyageFlightNumber = model.VoyageFlightNumber;
            entity.ExportedTo = model.ExportedTo;
            entity.NumberOfPackages = model.NumberOfPackages;
            entity.BlAwbManifestNo = model.BlAwbManifestNo;
            entity.PortOfLoading = model.PortOfLoading;
            entity.MarksAndNumbers = model.MarksAndNumbers;
            entity.PortOfDischarge = model.PortOfDischarge;
            entity.DestinationCountryCode = model.DestinationCountryCode;
            entity.IntercessorCompany = model.IntercessorCompany;
            entity.ClearingAgentName = model.ClearingAgentName;
            entity.ClearingAgentCode = model.ClearingAgentCode;
            entity.LicenseNumber = model.LicenseNumber;
            entity.RiskOutcome = model.RiskOutcome;
            entity.ValuationMethod = model.ValuationMethod;
            entity.OtherRemarks = model.OtherRemarks;
            entity.ReleaseDate = model.ReleaseDate;
            entity.Route = model.Route;
            entity.ExitPort = model.ExitPort;
            entity.TotalDuty = model.TotalDuty;
            entity.DefiniteFee = model.DefiniteFee;
            entity.Vat = model.Vat;
            entity.ExciseTax = model.ExciseTax;
            entity.OtherCharges = model.OtherCharges;
            entity.Insured = model.Insured;
            entity.DueNumber = model.DueNumber;
            entity.UnifiedCustomsCode = model.UnifiedCustomsCode;

            entity.Items = model.Items?.Select(ItemsModelToDto).ToList() ?? new List<CuaItemsDto>();
            entity.Payments = model.Payments?.Select(ToPaymentDto).ToList() ?? new List<CuaPaymentsDto>();

            return entity;
        }

        // ------------------- ITEMS -------------------
       private static CuaItemsDto ItemsModelToDto(CuaItemsModel dto)
        {
            if (dto == null) return null;

            var entity = new CuaItemsDto();

            entity.HsCode = dto.HsCode;
            entity.GoodsDescription = dto.GoodsDescription;
            entity.OriginCountryCode = dto.OriginCountryCode;
            entity.CifForeignValue = dto.CifForeignValue;
            entity.CifLocalValue = dto.CifLocalValue;
            entity.DutyRate = dto.DutyRate;
            entity.TotalDuty = dto.TotalDuty;
            entity.NetWeight = dto.NetWeight;
            entity.GrossWeight = dto.GrossWeight;
            entity.ExemptionApprovalRef = dto.ExemptionApprovalRef;
            entity.IncomeType = dto.IncomeType;

            entity.Currency = ToCurrencyDTO(dto.Currency);
            entity.Packages = ToPackageDto(dto.Packages);
            entity.Item = ToItemDetailsDto(dto.Item);
            entity.AIP = ToAipDto(dto.AIP);

            entity.Restrictions = dto.Restrictions?.Select(ToRestrictionDto).ToList() ?? new List<CuaRestrictionsDto>();

            return entity;
        }

        // ------------------- CURRENCY -------------------
        private static CuaCurrenciesDto ToCurrencyDTO(CuaCurrenciesModel model)
        {
            if (model == null) return null;

            var entity = new CuaCurrenciesDto();

            entity.Type = model.Type;
            entity.Value = model.Value;

            return entity;
        }

        // ------------------- PACKAGES -------------------
        private static CuaPackagesDto ToPackageDto(CuaPackagesModel model)
        {
            if (model == null) return null;

            var dto = new CuaPackagesDto();

            dto.Quantity = model.Quantity;
            dto.Type = model.Type;

            return dto;
        }

        // ------------------- ITEM DETAILS -------------------
        private static CuaItemDetailsDto ToItemDetailsDto(CuaItemDetailsModel model)
        {
            if (model == null) return null;

            var dto = new CuaItemDetailsDto();

            dto.Quantity = model.Quantity;
            dto.Unit = model.Unit;

            return dto;
        }

       

        // ------------------- AIP -------------------
        private static CuaAIPsDto ToAipDto(CuaAIPsModel entity)
        {
            if (entity == null) return null;

            var dto = new CuaAIPsDto();

            dto.GazetteNumber = entity.GazetteNumber;
            dto.Duty = entity.Duty;

            return dto;
        }

        // ------------------- RESTRICTIONS -------------------
        private static CuaRestrictionsDto ToRestrictionDto(CuaRestrictionsModel entity)
        {
            if (entity == null) return null;

            var dto = new CuaRestrictionsDto();

            dto.Agency = entity.Agency;
            dto.ReleaseRef = entity.ReleaseRef;

            return dto;
        }

    

        // ------------------- PAYMENTS -------------------
        private static CuaPaymentsDto ToPaymentDto(CuaPaymentsModel entity)
        {
            if (entity == null) return null;

            var dto = new CuaPaymentsDto();

            dto.Method = entity.Method;
            dto.No = entity.No;
            dto.Date = entity.Date;
            dto.Bank = entity.Bank;

            return dto;
        }

      
    }
}
