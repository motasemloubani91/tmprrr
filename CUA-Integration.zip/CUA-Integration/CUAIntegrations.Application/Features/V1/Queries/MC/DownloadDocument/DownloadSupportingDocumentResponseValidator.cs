﻿using FluentValidation;

namespace CUAIntegrations.Application.Features.V1.Queries.Mc.DownloadDocument
{
    public class DownloadSupportingDocumentResponseValidator : AbstractValidator<DownloadSupportingDocumentResponse>
    {
        public DownloadSupportingDocumentResponseValidator()
        {

            RuleFor(x => x.SupportingDocumentDetailsEntity)
               .SetValidator(new McSupportingDocumentDetailsDtoValidator());

        }


    }

    public class McSupportingDocumentDetailsDtoValidator : AbstractValidator<McSupportingDocumentDetailsDto>
    {
        public McSupportingDocumentDetailsDtoValidator()
        {
            // relatedDeclarationNumber
            RuleFor(x => x.RelatedDeclarationNumber)
                .NotEmpty()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: relatedDeclarationNumber.");

            RuleFor(x => x.RelatedDeclarationNumber)
                .MaximumLength(70)
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: relatedDeclarationNumber max length is 70.");

            RuleFor(x => x.RelatedDeclarationNumber)
                .Matches("^[A-Za-z0-9]+$")
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid format: relatedDeclarationNumber must be alphanumeric.");

            // documentCategory
            RuleFor(x => x.DocumentCategory)
                .NotEmpty()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: documentCategory.");

            RuleFor(x => x.DocumentCategory)
                .Length(3)
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: documentCategory must be 3 characters.");

            RuleFor(x => x.DocumentCategory)
                .Matches("^[A-Za-z0-9]+$")
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid format: documentCategory must be alphanumeric.");

            // documentName 
            RuleFor(x => x.DocumentName)
                .NotEmpty()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: documentName.");

            RuleFor(x => x.DocumentName)
                .MaximumLength(70)
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: documentName max length is 70.");

            RuleFor(x => x.DocumentName)
                .Matches("^[A-Za-z0-9 _\\-\\.]+$")
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid format: documentName must be alphanumeric or include _ - .");

            // documentIdNumber
            RuleFor(x => x.DocumentIdNumber)
                .NotEmpty()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: documentIdNumber.");

            RuleFor(x => x.DocumentIdNumber)
                .MaximumLength(70)
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: documentIdNumber max length is 70.");

            RuleFor(x => x.DocumentIdNumber)
                .Matches("^[A-Za-z0-9]+$")
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid format: documentIdNumber must be alphanumeric.");

            // documentLanguage 
            RuleFor(x => x.DocumentLanguage)
                .MaximumLength(2)
                .When(x => !string.IsNullOrEmpty(x.DocumentLanguage))
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: documentLanguage must be 2 characters.");

            RuleFor(x => x.DocumentLanguage)
                .Matches("^[A-Za-z]+$")
                .When(x => !string.IsNullOrEmpty(x.DocumentLanguage))
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid format: documentLanguage must be alphabetic.");

            // documentContent 
            RuleFor(x => x.DocumentContent)
                .NotEmpty()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: documentContent.");


        }


    }

}
