﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CUAIntegrations.Kernel.Domain.Entities.TransferReceipts
{
    public class TransferReceiptListOfDues
    {
        public long Id { get; set; }
        public long TransferReceiptId { get; set; }
        public string DueReference { get; set; } 

    }
}
