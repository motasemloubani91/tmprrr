﻿namespace CUAIntegrations.Kernel.Core.Exceptions
{
    public class BusinessRuleException : Exception
    {
        public int ErrorCode { get; private set; }
        public int HttpErrorCode { get; private set; } = 500;
        public BusinessRuleException()
        {
            ErrorCode = 600;
        }
        public BusinessRuleException(string message) : base(message) { }
        public BusinessRuleException(string message, int errorCode)
            : base(message)
        {
            this.ErrorCode = errorCode;
        }
        public BusinessRuleException(string message, Exception inner) : base(message, inner) { }
        public BusinessRuleException(string message, Exception inner, int errorCode)
            : base(message, inner)
        {
            this.ErrorCode = errorCode;
        }
        protected BusinessRuleException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }
    }
}
