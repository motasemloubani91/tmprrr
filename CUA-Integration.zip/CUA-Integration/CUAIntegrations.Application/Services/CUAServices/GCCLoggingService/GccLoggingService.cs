﻿using CUAIntegrations.Kernal.Domain.Entities.LoggingEntities;
using CUAIntegrations.Repository.Base;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using System.Text;

namespace CUAIntegrations.Application.Services.CUAServices.GCCLoggingService
{
    public class GccLoggingService : IGccLoggingService
    {
        private readonly ICUAIntegrationUnitOfWork _unitOfWork;

        public GccLoggingService(ICUAIntegrationUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<int> CreateGccLoggingObjectAsync(HttpContext context, Exception exception ,string level= "Error")
        {
            string queryString = context.Request.QueryString.ToString();
            string api = GetApiName(context);
            string requestBody = string.Empty;

            try
            {
                context.Request.EnableBuffering();

                using (var reader = new StreamReader(context.Request.Body, Encoding.UTF8, leaveOpen: true))
                {
                    requestBody = await reader.ReadToEndAsync();
                    context.Request.Body.Position = 0;
                }
            }
            catch
            {
                requestBody = null;
            }

            string xRequestId = context.Request.Headers["X-REQUEST-ID"].ToString();

            int? requestLoggingId = _unitOfWork.RequestLoggingRepository
                .Get(r => r.XRequestId == xRequestId)
                .OrderByDescending(r => r.Id)
                .Select(r => (int?)r.Id)
                .FirstOrDefault();

            GCCLogging gccException = new GCCLogging();

            gccException.Exception = Newtonsoft.Json.JsonConvert.SerializeObject(exception);
            gccException.Message = exception.Message;
            gccException.Level = level;
            gccException.RequestLoggingId = requestLoggingId;
            gccException.DateCreated = DateTime.Now;

            var logged = await _unitOfWork.GCCExceptionLoggingRepository.AddAsync(gccException);

            await _unitOfWork.CommitAsync();

            return logged.Id;
        }

        private string GetApiName(HttpContext context)
        {
            var routeData = context.GetRouteData();
            string controller = routeData?.Values["controller"]?.ToString();
            string action = routeData?.Values["action"]?.ToString();

            return !string.IsNullOrEmpty(controller) && !string.IsNullOrEmpty(action)
                ? $"{controller}/{action}"
                : context.Request.Path.ToString();
        }
    }
}
