﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;

namespace CUA_GCC_Integration.Core.Exceptions.RequestValidation
{
    public class MandatoryFieldMissingException : Exception
    {
        public int ErrorCode { get; private set; } //mapped to Status property in ErrorResponse
        public string Message { get; private set; } = "The request was rejected because a mandatory field is missing or empty";
        public string Reason { get; private set; } = "ValidationError";
        public List<ErrorDetail>? Details { get; set; }

        public MandatoryFieldMissingException()
        {
            ErrorCode = 400;
        }
        public MandatoryFieldMissingException(string message)
        {
            ErrorCode = 400;
            Message = message;
            Details = new List<ErrorDetail>();
        }
        public MandatoryFieldMissingException(List<ErrorDetail>? errorDetails)
        {
            ErrorCode = 400;
            Details = errorDetails;
        }

        protected MandatoryFieldMissingException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }
    }

}
