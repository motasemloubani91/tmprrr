﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;

namespace CUA_GCC_Integration.Core.Exceptions.ServerError
{

    public class InternalServerErrorException : Exception
    {
        public int ErrorCode { get; private set; } //mapped to Status property in ErrorResponse
        public string Message { get; private set; } = "Internal platform error. Validation processing failed. ";
        public string Reason { get; private set; } = "ServerError";
        public List<ErrorDetail>? Details { get; set; }

        public InternalServerErrorException()
        {
            ErrorCode = 500;
        }
        public InternalServerErrorException(List<ErrorDetail>? errorDetails)
        {
            ErrorCode = 500;
            Details = errorDetails;
        }

        protected InternalServerErrorException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }
    }
}
