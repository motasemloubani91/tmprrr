﻿namespace CUAIntegrations.Persistence.DataAccess.ADO.NET.Models
{
    public class CUASupportingDocumentListModel
    {
        public string RelatedDeclarationNumber { get; set; }
        public List<CUASupportingDocumentModel> Documents { get; set; } = new();
    }

    public class CUASupportingDocumentModel
    {
        public string DocumentCategory { get; set; }
        public string DocumentName { get; set; }
        public string DocumentIdNumber { get; set; }
        public string DocumentLanguage { get; set; }
        public string DocumentLink { get; set; }
    }
}

