﻿using CUA_GCC_Integration.Core.Constants;
using CUA_GCC_Integration.Core.Exceptions;
using CUAIntegrations.Application.Services.CUAServices.GCCLoggingService;
using CUAIntegrations.Kernel.Core.Exceptions;
using CUAIntegrations.Kernel.Core.Logging;
using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;
using CUAIntegrations.Kernel.Domain.Enums;
using CUAIntegrations.Repository.Base;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System.Data.Entity.Validation;
using System.Net;
using System.Text;

namespace CUAIntegrations.Kernel.Host.API.Middleware
{
    public static class ExceptionMiddlewareExtension
    {
        public static IApplicationBuilder UseExceptionMiddleware(
            this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<ExceptionMiddleware>();
        }
    }

    public class ExceptionMiddleware
    {
        private readonly RequestDelegate next;
        private readonly IConfiguration _configurations;
        private static string language;

        /// <summary>
        /// ExceptionMiddleware
        /// </summary>
        /// <param name="next"></param>
        /// 

        public ExceptionMiddleware(RequestDelegate next, IConfiguration configurations)
        {
            this.next = next;
            _configurations = configurations;
        }

        /// <summary>
        /// Invoke
        /// </summary>
        /// <param name="context"></param>
        /// <param name="logger"></param>
        /// <returns></returns>
        public async Task Invoke(
            HttpContext context,
            IRequestLogger requestLogger,
            ICUAIntegrationUnitOfWork unitOfWork,
            IGccLoggingService gccLoggingservice) /* other dependencies */
        {
            try
            {
                language = SupportedCultures.Arabic;
                if (context.Request.Headers.Any(a => a.Key.Contains("language")))
                {
                    language = context.Request.Headers.First(a => a.Key.Contains("language")).Value;
                }

                await next(context);
            }
            catch (DbUpdateException ex)
            {
                requestLogger.LogException(ex);
                await HandleExceptionAsync(context, ex, unitOfWork, gccLoggingservice);
            }
            catch (DbEntityValidationException ex)
            {
                requestLogger.LogException(ex);
                await HandleExceptionAsync(context, ex, unitOfWork, gccLoggingservice);

            }
            catch (NullReferenceException ex)
            {
                requestLogger.LogException(ex);
                await HandleExceptionAsync(context, ex, unitOfWork, gccLoggingservice);

            }
            catch (ArgumentNullException ex)
            {
                requestLogger.LogException(ex);
                await HandleExceptionAsync(context, ex, unitOfWork, gccLoggingservice);

            }
            catch (Exception ex)
            {
                requestLogger.LogException(ex);
                await HandleExceptionAsync(context, ex, unitOfWork, gccLoggingservice);

            }
        }

        private async Task HandleExceptionAsync(HttpContext context, Exception exception, ICUAIntegrationUnitOfWork unitOfWork, IGccLoggingService gccLoggingservice)
        {
            unitOfWork.DeAttach();
            HttpStatusCode code; // 500 if unexpected
            string error = exception.Message;
            var errorResponse = new ErrorResponse();

            if (exception is BusinessRuleException)
            {
                code = HttpStatusCode.BadRequest;
            }
            else if (exception is ForbiddenException)
            {
                code = HttpStatusCode.MethodNotAllowed;
                if (language == SupportedCultures.Arabic)
                {
                    error = "لا تمتلك الصلاحية لإتمام هذه العملية";
                }
                else
                {
                    error = "You don't have provillage to access this resource or do this action";
                }

            }
            else if (exception is NotFoundException)
            {
                code = HttpStatusCode.NotFound;

                if (language == SupportedCultures.Arabic)
                {
                    error = "العنصر الذي تحاول الوصول اليه غير موجود او تم نقله";
                }
                else
                {
                    error = "this resource does not found";
                }


            }
            else if (exception is BadRequestException)
            {
                code = HttpStatusCode.BadRequest;
                if (language == SupportedCultures.Arabic)
                {
                    error = "عملية غير صحيحة";
                }
                else
                {
                    error = "Bad Request";
                }

            }
            else if (exception is SystemIntegrationException)
            {
                var systemException = (SystemIntegrationException)exception;
                var exceptionDetails = systemException.Details;
                code = systemException.Code;

                errorResponse.Status = (int)code;
                errorResponse.Reason = systemException.Reason;
                errorResponse.Message = systemException.Message;
                errorResponse.Details = systemException.Details;
            }
            else
            {
                var errorBody = Newtonsoft.Json.JsonConvert.SerializeObject(exception);

                var enviroment = _configurations.GetValue<string>("Enviroment");
                var supportEmail = _configurations.GetValue<string>("SupportEmail");

                code = HttpStatusCode.InternalServerError;

                var body = errorBody;
                try
                {
                    //var exceptionId = serviceRequestService.InsertSystemException(context, exception);

                    //if (exceptionId != null)
                    //{
                    //    PrepareMailRequest prepareMailRequest = new PrepareMailRequest()
                    //    {
                    //        ToMail = supportEmail,
                    //        Action = "Exception",
                    //        ExceptionDetails = exceptionId.ToString()
                    //    };
                    //    var isMailSent = await communicationService.PrepareMailRequestAsync(prepareMailRequest);
                    //}


                }
                catch (Exception ex)
                {
                    error = Newtonsoft.Json.JsonConvert.SerializeObject(ex);
                }
                if (enviroment != nameof(EnviromentsEnum.Development))
                {
                    if (language == SupportedCultures.Arabic)
                    {
                        error = "حصل خطأ اثناء معالجة طلبك، فريق الدعم الفني على علم بهذا الخطأ، يرجى المحاولة لاحقا";
                    }
                    else
                    {
                        error = "Error occurred while processing your request, our technical support are aware of it, please try again later";
                    }

                }


            }
            //loghere 

            //string queryString = context.Request.QueryString.ToString();
            //string api = GetApiName(context);
            //byte[] buffer = new byte[Convert.ToInt32(context.Request.ContentLength)];

            //var requestBody = Encoding.UTF8.GetString(buffer);
            //string request = requestBody;
            //var exceptionMessage = new GCCException()
            //{
            //    ExceptionMessage = Newtonsoft.Json.JsonConvert.SerializeObject(exception),
            //    QueryString = queryString,
            //    Request = request,
            //    Api = api
            //};
            //var exceptionId = CreateGccLoggingObject(context, exception,unitOfWork);
            var exceptionId = await gccLoggingservice.CreateGccLoggingObjectAsync(context, exception, "Error");


            context.Response.ContentType = "application/json";
            //context.Response.StatusCode = (int)HttpStatusCode.OK;
            //Array tmp = null;
            //var result = JsonConvert.SerializeObject(new
            //{
            //    message = error,
            //    succeeded = false,
            //    statusCode = (int)code,
            //    brokenRules = tmp
            //});
            //context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
            context.Response.StatusCode = errorResponse.Status != 0 ? errorResponse.Status : (int)HttpStatusCode.InternalServerError;
            var result = JsonConvert.SerializeObject(errorResponse);
            var bytes = Encoding.UTF8.GetBytes(result);
            await context.Response.Body.WriteAsync(bytes, 0, bytes.Length);
        }

    }
}