﻿namespace CUAIntegrations.Persistence.DataAccess.ADO.NET.Models
{
    public class CUACustomsDeclarationsModel
    {
        public int Version { get; set; }

        public string DeclarationNumber { get; set; }
        public string DeclarationDate { get; set; }
        public string DeclarationType { get; set; }
        public string PortType { get; set; }
        public string? DeliveryOrderNumber { get; set; }
        public string ImporterExporterName { get; set; }
        public string ImporterExporterCustomsId { get; set; }

        public decimal NetWeight { get; set; }
        public decimal GrossWeight { get; set; }
        public string Measurement { get; set; }

        public string? CarrierCaptainDriver { get; set; }
        public string? CarrierName { get; set; }
        public string? CommercialRegistrationNumber { get; set; }
        public string? TinNumber { get; set; }

        public string? VoyageFlightNumber { get; set; }
        public string? ExportedTo { get; set; }

        public int? NumberOfPackages { get; set; }
        public string? BlAwbManifestNo { get; set; }
        public string? PortOfLoading { get; set; }
        public string? MarksAndNumbers { get; set; }
        public string? PortOfDischarge { get; set; }

        public string? DestinationCountryCode { get; set; }
        public string? IntercessorCompany { get; set; }

        public string? ClearingAgentName { get; set; }
        public string? ClearingAgentCode { get; set; }
        public string? LicenseNumber { get; set; }
        public string? RiskOutcome { get; set; }

        public string? ValuationMethod { get; set; }
        public string? OtherRemarks { get; set; }
        public string ReleaseDate { get; set; }

        public string? Route { get; set; }
        public string? ExitPort { get; set; }

        public decimal TotalDuty { get; set; }
        public decimal DefiniteFee { get; set; }
        public decimal? Vat { get; set; }
        public decimal? ExciseTax { get; set; }
        public decimal? OtherCharges { get; set; }
        public decimal? Insured { get; set; }

        public string? DueNumber { get; set; }
        public string? UnifiedCustomsCode { get; set; }

        public List<CuaItemsModel> Items { get; set; } = new();
        public List<CuaPaymentsModel>? Payments { get; set; }
    }

    public class CuaPaymentsModel
    {
        public string? Method { get; set; }
        public string? No { get; set; }
        public string? Date { get; set; }
        public string? Bank { get; set; }
    }


    public class CuaItemsModel
    {

        public string HsCode { get; set; }
        public string GoodsDescription { get; set; }
        public string OriginCountryCode { get; set; }
        public decimal CifForeignValue { get; set; }
        public decimal CifLocalValue { get; set; }
        public string DutyRate { get; set; }
        public string? IncomeType { get; set; }
        public decimal TotalDuty { get; set; }
        public decimal NetWeight { get; set; }
        public decimal GrossWeight { get; set; }
        public string? ExemptionApprovalRef { get; set; }

        public CuaCurrenciesModel Currency { get; set; }
        public CuaPackagesModel? Packages { get; set; }
        public CuaItemDetailsModel Item { get; set; }
        public CuaAIPsModel? AIP { get; set; }
        public List<CuaRestrictionsModel>? Restrictions { get; set; }
    }

    public class CuaCurrenciesModel
    {
        public string Type { get; set; }
        public decimal Value { get; set; }
    }

    public class CuaPackagesModel
    {
        public decimal? Quantity { get; set; }
        public string? Type { get; set; }
    }

    public class CuaItemDetailsModel
    {
        public decimal Quantity { get; set; }
        public string Unit { get; set; }
    }
    public class CuaAIPsModel
    {
        public string? GazetteNumber { get; set; }
        public decimal? Duty { get; set; }
    }
    public class CuaRestrictionsModel
    {
        public string Agency { get; set; }
        public string? ReleaseRef { get; set; }
    }
}
