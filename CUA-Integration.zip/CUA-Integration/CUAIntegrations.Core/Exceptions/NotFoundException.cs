﻿using System.Net;

namespace CUAIntegrations.Kernel.Core.Exceptions
{
    public class NotFoundException : Exception
    {
        public int ErrorCode { get; private set; }
        public NotFoundException()
        {
            ErrorCode = (int)HttpStatusCode.NotFound;
        }
        public NotFoundException(string message) : base(message) { }
        public NotFoundException(string message, int errorCode)
            : base(message)
        {
            this.ErrorCode = errorCode;
        }
        public NotFoundException(string message, Exception inner) : base(message, inner) { }
        public NotFoundException(string message, Exception inner, int errorCode)
            : base(message, inner)
        {
            this.ErrorCode = errorCode;
        }
        protected NotFoundException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }
    }
}
