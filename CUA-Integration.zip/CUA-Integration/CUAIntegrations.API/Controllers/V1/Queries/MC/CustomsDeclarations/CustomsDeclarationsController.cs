﻿using CUAIntegrations.Application.Features.V1.Queries.Mc.CustomsDeclarations;
using CUAIntegrations.Application.Features.V1.Queries.OutBoundedForMC.CustomsDeclarations;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CUAIntegrations.Controllers.V1.Queries.MC.CustomsDeclarations
{
    [ApiController]
    public class CustomsDeclarationsController : BaseMCController
    {
        private readonly IMediator _mediator;

        public CustomsDeclarationsController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet("{declarationNumber}/{issuingCountryCode}")]
        [ApiVersion("1")]
        [AllowAnonymous]
        public async Task<GetCustomsDeclarationResponse> GetInBoundedCustomsDeclaration(
            [FromRoute] string declarationNumber,
            [FromRoute] string issuingCountryCode,
            [FromQuery] string? declarationType,
            [FromQuery] string? year,
            [FromQuery] string? port)
        {

            var query = new GetCustomsDeclarationQuery
            {
                DeclarationNumber = declarationNumber,
                DeclarationType = declarationType,
                IssuingCountryCode = issuingCountryCode,
                Year = year,
                Port = port
            };

            return await _mediator.Send(query);
        }
    }
}

