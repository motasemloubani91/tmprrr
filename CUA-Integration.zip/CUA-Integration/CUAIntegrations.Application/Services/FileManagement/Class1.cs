﻿//using System;
//using System.Collections.Specialized;
//using System.Web;
//using System.Web.Caching;
//using System.Net.Http;
//using System.Net;
//using System.Threading.Tasks;
//using System.Threading;
//using System.IO;
//using System.Security.Cryptography;
//using System.Text;
//using System.Data;
//using System.Collections.Generic;
//using System.Configuration;

//namespace CUAIntegrations.Application.Services.FileManagement
//{
//    public class FileManagementService1
//    {
//        static string PasswordHash = "PasswordHash";
//        static string SaltKey = "SaltKey";
//        static string VIKey = "VIKeyVIKey";

//        /// <summary>
//        /// Downloads a document file based on the provided parameters.
//        /// </summary>
//        /// <param name="iDocumentId">DocumentId for document to be downloaded.</param>
//        /// <param name="iReferenceId">Reference Id against the document, e.g. HousebillId, DeclarationId, etc.</param>
//        /// <param name="sDownloadedFilePath">Complete file path with name and file extension, used to download a file.</param>
//        /// <param name="sDownloadWebApiURI"> URI from any configuration e.g. http:/.../CSUploadProdPP/Home/DownloadFileEx</param>
//        /// <param name="iOwnerOrgId">OwnerOrgId</param>
//        /// <param name="iOwnerLocId">OwnerLocId</param>
//        /// <param name="bReturnByteArray">true returns the file as a byte array if downloaded successfully at the provided path in sDownloadedFilePath param.
//        ///false; file is still available at the provided path (sDownloadedFilePath) if downloaded successfully</param>
//        /// <returns></returns>
//        public static byte[] DownloadDocumentFile(int iDocumentId, int iReferenceId
//                                , string sDownloadedFilePath, string sDownloadWebApiURI
//                                , int iOwnerOrgId, int iOwnerLocId, bool bReturnByteArray)
//        {
//            byte[] RespData = null;

//            //////// Generate a token for download.

//            string[] arrTokenInfo = GetTokenForDownload(iDocumentId, iReferenceId
//                                    , SaltKey, iOwnerOrgId, iOwnerLocId);

//            if (arrTokenInfo != null && arrTokenInfo.Length > 0)
//            {
//                string sTokenInfo = arrTokenInfo[0] + "|" + arrTokenInfo[1] + "|" + SaltKey;
//                sTokenInfo = CsUploadEncrypt(sTokenInfo);
//                string sDocumentId = CsUploadEncrypt(iDocumentId.ToString());

//                WebAPIFileDownloadResponse oWAFDR = DownloadFileUsingMVCWebApi(sTokenInfo, sDocumentId
//                                                    , sDownloadedFilePath, sDownloadWebApiURI);

//                //////// If download call is successfull then we shall   
//                //////// have file at the provided file path.
//                if (oWAFDR.IsResponseAvailable)
//                {
//                    //////// bReturnByteArray: If we need to return the file content then prepare 
//                    //////// the byte array. This flag is added to avoid returning file content 
//                    //////// where required. The file shall be created in the provided location in 
//                    //////// the method argument sDownloadWebApiURI.
//                    if (bReturnByteArray)
//                        RespData = File.ReadAllBytes(sDownloadedFilePath);
//                }
//                else
//                {
//                    //////// Share the error.
//                    throw new Exception(oWAFDR.ErrorDetails);
//                }
//            }

//            return RespData;
//        }


//        public static string[] GetTokenForDownload(int iDocumentId, int iReferenceId
//                                                    , string sSaltKey, int iOwnerOrgId
//                                                    , int iOwnerLocId)
//        {
//            string sConnectionString = ConfigurationManager.AppSettings["DBConn"];
//            string[] arrTokenAndSession = new string[2];
//            string sDocumentid = iDocumentId.ToString();

//            string sReferenceProfile = "Declaration";
//            ////string sCreatedby = "CDAPI.User";
//            string sCreatedby = "AValidUserId";
//            string sTokensalt = sSaltKey;
//            string sTokenval_Out = "";
//            string sSessionId_Out = "";

//            using (SqlConnection objConn = new SqlConnection(sConnectionString))
//            {
//                using (SqlCommand cmd = new SqlCommand())
//                {
//                    try
//                    {
//                        cmd.CommandText = @"[dbo].[USP_InsertintoMcDocDownloadTokenAPI]";
//                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
//                        cmd.Connection = objConn;

//                        SqlParameter[] cmdParamOut = new SqlParameter[2];
//                        cmdParamOut[0] = new SqlParameter();
//                        cmdParamOut[0].SqlDbType = System.Data.SqlDbType.VarChar;
//                        cmdParamOut[0].Size = 200;
//                        cmdParamOut[0].ParameterName = "@tokenval";
//                        cmdParamOut[1] = new SqlParameter();
//                        cmdParamOut[1].ParameterName = "@SessionId";
//                        cmdParamOut[1].SqlDbType = System.Data.SqlDbType.VarChar;
//                        cmdParamOut[1].Size = 200;
//                        cmdParamOut[0].Direction = System.Data.ParameterDirection.Output;
//                        cmdParamOut[1].Direction = System.Data.ParameterDirection.Output;

//                        SqlParameter[] cmdParamIn = new SqlParameter[7];
//                        cmdParamIn[0] = new SqlParameter();
//                        cmdParamIn[0].ParameterName = "@referenceid";
//                        cmdParamIn[0].Value = iReferenceId;
//                        cmdParamIn[1] = new SqlParameter();
//                        cmdParamIn[1].ParameterName = "@referenceProfile";
//                        cmdParamIn[1].Value = sReferenceProfile;
//                        cmdParamIn[2] = new SqlParameter();
//                        cmdParamIn[2].ParameterName = "@createdby";
//                        cmdParamIn[2].Value = sCreatedby;
//                        cmdParamIn[3] = new SqlParameter();
//                        cmdParamIn[3].ParameterName = "@Tokensalt";
//                        cmdParamIn[3].Value = sTokensalt;
//                        cmdParamIn[4] = new SqlParameter();
//                        cmdParamIn[4].ParameterName = "@documentid";
//                        cmdParamIn[4].Value = sDocumentid;

//                        cmdParamIn[5] = new SqlParameter();
//                        cmdParamIn[5].DbType = System.Data.DbType.Int32;
//                        cmdParamIn[5].ParameterName = "@ownerlocid";
//                        cmdParamIn[5].Value = iOwnerLocId;
//                        cmdParamIn[6] = new SqlParameter();
//                        cmdParamIn[6].DbType = System.Data.DbType.Int32;
//                        cmdParamIn[6].ParameterName = "@ownerorgid";
//                        cmdParamIn[6].Value = iOwnerOrgId;

//                        cmd.Parameters.AddRange(cmdParamIn);
//                        cmd.Parameters.AddRange(cmdParamOut);

//                        objConn.Open();
//                        cmd.ExecuteNonQuery();
//                        sTokenval_Out = cmd.Parameters["@tokenval"].Value.ToString();
//                        sSessionId_Out = cmd.Parameters["@SessionId"].Value.ToString();

//                        arrTokenAndSession[0] = sTokenval_Out;
//                        arrTokenAndSession[1] = sSessionId_Out;
//                    }
//                    catch (Exception ex)
//                    {
//                        Console.WriteLine(ex.ToString());
//                    }
//                    finally
//                    {
//                        if (objConn.State == System.Data.ConnectionState.Open)
//                            objConn.Close();
//                    }
//                }
//            }

//            return arrTokenAndSession;
//        }


//        public static string CsUploadEncrypt(string plainText)
//        {
//            byte[] plainTextBytes = Encoding.UTF8.GetBytes(plainText);
//            byte[] keyBytes = new Rfc2898DeriveBytes(PasswordHash, Encoding.ASCII.GetBytes(SaltKey)).GetBytes(256 / 8);
//            var symmetricKey = new RijndaelManaged() { Mode = CipherMode.CBC, Padding = PaddingMode.Zeros };
//            var encryptor = symmetricKey.CreateEncryptor(keyBytes, Encoding.ASCII.GetBytes(VIKey));

//            byte[] cipherTextBytes;

//            using (var memoryStream = new MemoryStream())
//            {
//                using (var cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write))
//                {
//                    cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length);
//                    cryptoStream.FlushFinalBlock();
//                    cipherTextBytes = memoryStream.ToArray();

//                    cryptoStream.Close();
//                }

//                memoryStream.Close();
//            }

//            return Convert.ToBase64String(cipherTextBytes);
//        }


//        public static WebAPIFileDownloadResponse DownloadFileUsingMVCWebApi(string sTokenInfo, string sDocumentId
//                                                    , string sDownloadFilePath, string sUri)
//        {
//            WebAPIFileDownloadResponse oWAFDR = new WebAPIFileDownloadResponse();
//            string sResponse = string.Empty;

//            try
//            {

//                NameValueCollection nvcFormParam = new NameValueCollection();
//                nvcFormParam.Add("tokenInfo", sTokenInfo);
//                nvcFormParam.Add("DocumentId", sDocumentId);

//                string sDownloadResult = FileUploadHelperUsingHTTPWebClient.HttpDownloadFile(sUri, sDownloadFilePath, nvcFormParam);


//                //////// See if we have response data or not
//                if (!string.IsNullOrWhiteSpace(sDownloadResult)) //////// StatusCode = 404
//                {
//                    //////// statusText:"The requested resource is not found, had its name changed, or is temporarily unavailable."
//                    oWAFDR.IsResponseAvailable = false;
//                    ////oWAFDR.ErrorDetails = "The requested resource is not found, had its name changed, or is temporarily unavailable.";
//                    oWAFDR.ErrorDetails = "File download attempt unsuccessful:\r\n" + sDownloadResult;
//                }
//                else
//                {
//                    oWAFDR.IsResponseAvailable = true;
//                    oWAFDR.ErrorDetails = string.Empty;
//                }
//            }
//            catch (Exception ex)
//            {
//                string sErrorMsg = "Error occurred while making internal WebApi document download call: \r\n"
//                                    + ex.ToString().Replace("System.Exception: ", string.Empty);

//                oWAFDR.IsResponseAvailable = false;
//                oWAFDR.ErrorDetails = sErrorMsg;
//            }

//            return oWAFDR;
//        }

//        public class WebAPIFileDownloadResponse
//        {
//            //// This class is created to contain the WebApi response
//            public bool IsResponseAvailable;
//            public string ErrorDetails;
//        }

//        public class FileUploadHelperUsingHTTPWebClient
//        {
//            public static string HttpDownloadFile(string sUrl, string sFileNameToDownloadAs, NameValueCollection nvc)
//            {
//                string sDownloadResult = string.Empty;
//                System.Net.ServicePointManager.ServerCertificateValidationCallback += (se, cert, chain, sslerror) => { return true; };
//                System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;

//                HttpWebResponse wResp = null;
//                HttpWebRequest wReq = (HttpWebRequest)WebRequest.Create(sUrl);
//                wReq.ContentType = "application/x-www-form-urlencoded";
//                wReq.Method = "POST";
//                wReq.KeepAlive = true;

//                //////// We don't need to cache any downloaded data.
//                //s//wReq.Headers.Add(HttpRequestHeader.CacheControl, "no-cache");
//                wReq.Headers.Add(HttpRequestHeader.CacheControl, "no-store");
//                HttpRequestCachePolicy noCachePolicy = new HttpRequestCachePolicy(HttpRequestCacheLevel.NoCacheNoStore);
//                wReq.CachePolicy = noCachePolicy;

//                string formdataTemplate = "{0}={1}&";
//                string formitem = string.Empty;
//                if (nvc != null)
//                {
//                    foreach (string key in nvc.Keys)
//                    {
//                        formitem += string.Format(formdataTemplate, HttpUtility.UrlEncode(key), HttpUtility.UrlEncode(nvc[key]));
//                    }
//                }

//                if (formitem.Length > 0) formitem.Remove(formitem.Length - 1, 1);

//                byte[] formitembytes = System.Text.Encoding.UTF8.GetBytes(formitem);
//                wReq.ContentLength = formitembytes.Length;

//                Stream reqStrm = wReq.GetRequestStream();
//                reqStrm.Write(formitembytes, 0, formitembytes.Length);
//                reqStrm.Close();

//                try
//                {
//                    try
//                    {
//                        wResp = (HttpWebResponse)wReq.GetResponse();
//                    }
//                    catch (WebException exWeb)
//                    {
//                        wResp = (HttpWebResponse)exWeb.Response;
//                    }

//                    //////// If not OK status then report the error from WebAPI
//                    if (wResp.StatusCode != HttpStatusCode.OK)
//                    {
//                        int iStatusCode = (int)wResp.StatusCode;
//                        string sStatusCodeTemp = "StatusCode: " + iStatusCode.ToString()
//                            + " (" + System.Web.HttpWorkerRequest.GetStatusDescription(iStatusCode) + ")";
//                        sDownloadResult += "WebApi returned following response:\r\n";
//                        sDownloadResult += sStatusCodeTemp + "\r\n" + wResp.StatusDescription;
//                    }
//                    else
//                    {
//                        try
//                        {
//                            Stream respStrm = wResp.GetResponseStream();
//                            using (FileStream fsFileNameToDownloadAs = File.Create(sFileNameToDownloadAs))
//                            {
//                                respStrm.CopyTo(fsFileNameToDownloadAs);
//                                fsFileNameToDownloadAs.Flush();
//                            }
//                        }
//                        catch (Exception exFileWriteIssue)
//                        {
//                            string sErrFileWriteIssue = "Error occurred while creating download file from MVC WebApi response stream at "
//                                                        + sFileNameToDownloadAs + "\r\n" + exFileWriteIssue.ToString();
//                            sDownloadResult = sErrFileWriteIssue;
//                        }

//                        //////// StreamReader reader2 = new StreamReader(stream2);
//                        //////// var response = reader2.ReadToEnd();
//                        ////////BinaryReader brFile = new BinaryReader(strmResp);
//                        ////////var response = brFile.Read();

//                        ////using (BinaryReader brFile = new BinaryReader(strmResp))
//                        ////{
//                        ////    FileStream fsFileDownload = File.OpenWrite(sFileNameToDownladAs);
//                        ////    byte[] buff = new byte[2000];
//                        ////    while (brFile.Read(buff, 0, 2000) > 0)
//                        ////    {
//                        ////        fsFileDownload.Write(buff, 0, 2000);
//                        ////        fsFileDownload.Flush();

//                        ////        File.WriteAllBytes(sFileNameToDownladAs, buff);
//                        ////    }
//                        ////}

//                    }
//                }
//                catch (Exception ex)
//                {
//                    string sErrMsg = "Error occurred during file download WebApi call:\r\n" + ex.ToString();
//                    sDownloadResult += sErrMsg;

//                    if (wResp != null)
//                    {
//                        wResp.Close();
//                        wResp = null;
//                    }

//                    ////////return null;
//                }
//                finally
//                {
//                    wReq = null;
//                }

//                return sDownloadResult;
//            }
//        }
//    }
//}
