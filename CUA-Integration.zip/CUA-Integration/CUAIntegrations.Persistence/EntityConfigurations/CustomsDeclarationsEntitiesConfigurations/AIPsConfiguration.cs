﻿using CUAIntegrations.Kernel.Domain.Entities.CustomsDeclarationsEntities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace CUAIntegrations.Persistence.EntityConfigurations.CustomsDeclarationsEntitiesConfigurations
{
    public class AIPsConfiguration : IEntityTypeConfiguration<AIPs>
    {
        public void Configure(EntityTypeBuilder<AIPs> entity)
        {
            entity.ToTable("GCC_AIPs", "GCC");
            entity.HasKey(a => a.Id);

            entity.Property(a => a.ItemId).IsRequired();
            entity.Property(a => a.GazetteNumber).HasMaxLength(70);
            entity.Property(a => a.Duty).HasColumnType("decimal(16,6)");

            
        }
    }
}
