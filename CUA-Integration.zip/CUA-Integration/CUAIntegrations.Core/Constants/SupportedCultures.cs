﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CUA_GCC_Integration.Core.Constants
{
    public class SupportedCultures
    {
        public static readonly string EnglishUs = "en";
        public static readonly string Arabic = "ar";
    }
}
