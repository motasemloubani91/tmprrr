﻿using CUAIntegrations.Kernal.Domain.Entities.LoggingEntities;
using CUAIntegrations.Kernel.Domain.Entities.LoggingEntities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace CUAIntegrations.Persistence.EntityConfigurations.LoggingEntitiesConfigurations
{
    public class GCCLoggingConfiguration : IEntityTypeConfiguration<GCCLogging>
    {
        public void Configure(EntityTypeBuilder<GCCLogging> entity)
        {
            entity.ToTable("GCC_logging", "GCC");

            entity.HasKey(e => e.Id);

            entity.Property(e => e.Id)
                  .ValueGeneratedOnAdd();

            entity.Property(e => e.DateCreated)
                  .IsRequired()
                  .HasDefaultValueSql("GETDATE()");

            entity.Property(e => e.Exception)
                  .HasColumnName("Exception")
                  .HasColumnType("nvarchar(max)");

            entity.Property(e => e.Message)
                  .HasColumnName("Message")
                  .HasColumnType("nvarchar(max)");

            entity.Property(e => e.Level)
                  .HasColumnName("level")
                  .HasColumnType("nvarchar(max)");

            entity.Property(e => e.RequestLoggingId)
                  .HasColumnName("RequestLoggingId")
                  .IsRequired(false);
        }
    }
}
