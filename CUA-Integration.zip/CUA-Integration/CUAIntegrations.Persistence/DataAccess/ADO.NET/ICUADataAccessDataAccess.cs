﻿using CUAIntegrations.Persistence.DataAccess.ADO.NET.Models;

namespace CUAIntegrations.Persistence.DataAccess.ADO.NET
{
    public interface ICUADataAccessDataAccess
    {
        Task<CUACustomsDeclarationsModel?> GetDeclarationBayanPrintPreviewAsync(string DeclarationId);
        Task<CUADueNumberModel?> GetDueNumberAsync(string DueNumber);
        Task<CUATransferReceiptModel?> GetTransferReceiptAsync(string DueNumber);
        Task<CUASupportingDocumentListModel> GetSupportedDocumentListAsync(string DeclarationId);
        Task<string> GetDeclarationIdAsync(string declarationNumber, string declarationType, string year, string port, string issuingCountryCode, string requestingCountryCode);

    }
}
