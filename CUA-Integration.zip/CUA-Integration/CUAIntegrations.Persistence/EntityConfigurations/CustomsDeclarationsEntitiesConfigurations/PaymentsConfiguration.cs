﻿using CUAIntegrations.Kernel.Domain.Entities.CustomsDeclarationsEntities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace CUAIntegrations.Persistence.EntityConfigurations.CustomsDeclarationsEntitiesConfigurations
{
    public class PaymentsConfiguration : IEntityTypeConfiguration<Payments>
    {
        public void Configure(EntityTypeBuilder<Payments> entity)
        {
            entity.ToTable("GCC_Payments", schema: "GCC");

            entity.HasKey(e => e.Id);

            entity.Property(e => e.Method).HasMaxLength(10);
            entity.Property(e => e.No).HasMaxLength(70);
            entity.Property(e => e.Bank).HasMaxLength(200);
            entity.Property(e => e.Date).HasColumnType("datetime");

           
        }
    }
}
