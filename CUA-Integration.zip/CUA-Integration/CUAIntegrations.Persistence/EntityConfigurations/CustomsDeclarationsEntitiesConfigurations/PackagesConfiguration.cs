﻿
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using CUAIntegrations.Kernel.Domain.Entities.CustomsDeclarationsEntities;

namespace CUAIntegrations.Persistence.EntityConfigurations.CustomsDeclarationsEntitiesConfigurations
{
    public class PackagesConfiguration : IEntityTypeConfiguration<Packages>
    {
        public void Configure(EntityTypeBuilder<Packages> entity)
        {
            entity.ToTable("GCC_Packages", "GCC");
            entity.HasKey(a => a.Id);

            entity.Property(a => a.Quantity).HasColumnType("decimal(16,0)");
            entity.Property(a => a.Type).HasMaxLength(6);

           
        }
    }
}
