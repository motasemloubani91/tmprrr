﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using CUAIntegrations.Kernel.Domain.Entities.Lookups;

namespace CUAIntegrations.Persistence.EntityLookupConfigurations
{
    public class PortCodesLookupConfiguration : IEntityTypeConfiguration<PortCodesLookup>
    {
        public void Configure(EntityTypeBuilder<PortCodesLookup> entity)
        {
            entity.ToTable("GCC_GCCPortCodesLookup", "GCC");
            entity.HasKey(e => e.Id);

            entity.Property(e => e.Code).HasMaxLength(255);
            entity.Property(e => e.Country).HasMaxLength(255);
            entity.Property(e => e.EnglishPortType).HasMaxLength(255);
            entity.Property(e => e.ArabicPortType).HasMaxLength(255);
            entity.Property(e => e.ArabicDescription).HasMaxLength(255);
            entity.Property(e => e.EnglishDescription).HasMaxLength(255);
        }
    }
}
