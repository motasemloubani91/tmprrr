﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;

namespace CUA_GCC_Integration.Core.Exceptions.ServerError
{
    internal class ExternalValidationServiceException
    {
    }
    public class FailedAuthenticationExeption : Exception
    {
        public int ErrorCode { get; private set; } //mapped to Status property in ErrorResponse
        public string Message { get; private set; } = "External validation service error. Service not responding. ";
        public string Reason { get; private set; } = "ServiceUnavailableError";
        public List<ErrorDetail>? Details { get; set; }

        public FailedAuthenticationExeption()
        {
            ErrorCode = 502;
        }
        public FailedAuthenticationExeption(List<ErrorDetail>? errorDetails)
        {
            ErrorCode = 502;
            Details = errorDetails;
        }

        protected FailedAuthenticationExeption(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }
    }

}
