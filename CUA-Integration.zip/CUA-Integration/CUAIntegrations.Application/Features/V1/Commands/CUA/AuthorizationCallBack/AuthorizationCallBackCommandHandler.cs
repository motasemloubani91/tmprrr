﻿using CUA_GCC_Integration.Core.Helpers;
using CUAIntegrations.Application.Services.CUAServices;
using CUAIntegrations.Kernel.Domain.Entities.AuthenticationsEntities;
using CUAIntegrations.Repository.Base;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace CUAIntegrations.Application.Features.V1.Commands.CUA.AuthorizationCallBack
{
    public class AuthorizationCallBackCommandHandler : IRequestHandler<AuthorizationCallBackCommand, bool>
    {
        private readonly ICUAIntegrationUnitOfWork _unitOfWork;
        private readonly ICUAAuthenticationService _iCUAAuthenticationService;
        private readonly ITimeHelper _timeHelper;

        public AuthorizationCallBackCommandHandler(
            ICUAIntegrationUnitOfWork unitOfWork,
            ICUAAuthenticationService iCUAAuthenticationService,
            ITimeHelper timeHelper)
        {
            _unitOfWork = unitOfWork;
            _iCUAAuthenticationService = iCUAAuthenticationService;
            _timeHelper = timeHelper;
        }

        public async Task<bool> Handle(AuthorizationCallBackCommand request, CancellationToken cancellationToken)
        {
            var authenticationResult = await _iCUAAuthenticationService.Authenticate(new Services.CUAServices.DTOs.AuthenticationServiceDTOs.AuthenticateDTO
            {
                Code = request.code,
                GrantType = "authorization_code"
            });
            if (authenticationResult is null)
            {
                return false;
            }

            var integrationAuthentication = await _unitOfWork.IntegrationsAuthenticationRepository.Get()
                .FirstOrDefaultAsync();

            if (integrationAuthentication is null)
            {
                integrationAuthentication = IntegrationsAuthentication.Create(
                     code: request.code,
                     scope: authenticationResult.Scope,
                     accessToken: authenticationResult.Access_Token,
                     refreshToken: authenticationResult.Refresh_Token,
                     accessTokenExpiresAt: _timeHelper.GetUTCTime().AddSeconds(authenticationResult.Expires_In));

                await _unitOfWork.IntegrationsAuthenticationRepository.AddAsync(integrationAuthentication);
            }
            else
            {
                integrationAuthentication.UpdateAccessToken(
                    code: request.code,
                     scope: authenticationResult.Scope,
                     accessToken: authenticationResult.Access_Token,
                     refreshToken: authenticationResult.Refresh_Token,
                     accessTokenExpiresAt: _timeHelper.GetUTCTime().AddSeconds(authenticationResult.Expires_In));

                _unitOfWork.IntegrationsAuthenticationRepository.Update(integrationAuthentication);
            }

            await _unitOfWork.CommitAsync();

            return true;
        }
    }
}
