﻿using CUAIntegrations.Kernel.Domain.Entities.LoggingEntities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace CUAIntegrations.Persistence.EntityConfigurations.LoggingEntitiesConfigurations
{
    internal class RequestLoggingConfigurations : IEntityTypeConfiguration<RequestLogging>
    {
        public void Configure(EntityTypeBuilder<RequestLogging> entity)
        {
            entity.ToTable("GCC_RequestsLogging", "GCC");
            entity.HasKey(e => e.Id);

            entity.Property(e => e.Id)
                  .ValueGeneratedOnAdd();

            entity.Property(e => e.Direction).HasMaxLength(1).IsRequired();
            entity.Property(e => e.Endpoint).HasMaxLength(500);
            entity.Property(e => e.HttpMethod).HasMaxLength(10);
            entity.Property(e => e.ClientId).IsRequired(false).HasMaxLength(10);
            entity.Property(e => e.XRequestId).IsRequired(false).HasMaxLength(100);
            entity.Property(e => e.XCorrelationId).IsRequired(false).HasMaxLength(100);
            entity.Property(e => e.XClientId).IsRequired(false).HasMaxLength(100);
            entity.Property(e => e.DataEntityId)
                  .HasColumnType("bigint")
                  .IsRequired(false);
            entity.Property(e => e.Headers);
            entity.Property(e => e.RequestBody);

            entity.Property(e => e.RequestTime).IsRequired();
        }
    }
}
