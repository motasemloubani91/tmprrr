﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;

namespace CUA_GCC_Integration.Core.Exceptions.ServerError
{
    public class DatabaseConnectionErrorException : Exception
    {
        public int ErrorCode { get; private set; } //mapped to Status property in ErrorResponse
        public string Message { get; private set; } = "Database connection error. Cannot access data storage. ";
        public string Reason { get; private set; } = "DatabaseConnectionError";
        public List<ErrorDetail>? Details { get; set; }

        public DatabaseConnectionErrorException()
        {
            ErrorCode = 500;
        }
        public DatabaseConnectionErrorException(List<ErrorDetail>? errorDetails)
        {
            ErrorCode = 500;
            Details = errorDetails;
        }

        protected DatabaseConnectionErrorException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }
    }
}
