using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;
using System.Net;

namespace CUA_GCC_Integration.Core.Exceptions.DataNotFound
{
    public class NotFoundDueNumberException : SystemIntegrationException
    {
        const string message = "The Due Number was not found in the First Exit country�s system.";
        const string reason = "Data Not Found.";

        public NotFoundDueNumberException() :
            base(errorCode: HttpStatusCode.NotFound,
                message: message,
                reason: reason)
        {
        }

        public NotFoundDueNumberException(
            string message = message,
            string reason = reason,
            List<ErrorDetail>? details = null) :
            base(errorCode: HttpStatusCode.NotFound,
                message: message,
                reason: reason,
                details: details)
        {
        }
    }
}