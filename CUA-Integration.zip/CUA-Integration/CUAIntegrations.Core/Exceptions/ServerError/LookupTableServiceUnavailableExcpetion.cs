﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;

namespace CUA_GCC_Integration.Core.Exceptions.ServerError
{
    public class LookupTableServiceUnavailableExcpetion : Exception
    {
        public int ErrorCode { get; private set; } //mapped to Status property in ErrorResponse
        public string Message { get; private set; } = "Lookup table service unavailable. Cannot access reference data. ";
        public string Reason { get; private set; } = "ServerError";
        public List<ErrorDetail>? Details { get; set; }

        public LookupTableServiceUnavailableExcpetion()
        {
            ErrorCode = 500;
        }
        public LookupTableServiceUnavailableExcpetion(List<ErrorDetail>? errorDetails)
        {
            ErrorCode = 500;
            Details = errorDetails;
        }

        protected LookupTableServiceUnavailableExcpetion(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }
    }
}
