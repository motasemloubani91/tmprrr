﻿using CUA_GCC_Integration.Core.Exceptions.DataNotFound;
using CUAIntegrations.Persistence.DataAccess.ADO.NET;
using MediatR;

namespace CUAIntegrations.Application.Features.V1.Queries.CUA.TransferReceipts
{
    public class OutBoundedGetTransferReceiptHandler
        : IRequestHandler<OutBoundedGetTransferReceiptQuery, OutBoundedGetTransferReceiptResponse>
    {
        private readonly ICUADataAccessDataAccess _dataAccessService;

        public OutBoundedGetTransferReceiptHandler(ICUADataAccessDataAccess dataAccessService)
        {
            _dataAccessService = dataAccessService;
        }

        public async Task<OutBoundedGetTransferReceiptResponse> Handle(
            OutBoundedGetTransferReceiptQuery request,
            CancellationToken cancellationToken)
        {
            var response = new OutBoundedGetTransferReceiptResponse();

            var documentsResult = await _dataAccessService.GetTransferReceiptAsync(request.DueNumber);

            if (documentsResult is null)
            {

                throw new TransferReceiptNotFoundException();
            }

            //todo: mapping from the model to the DTO
            var cuaTransferReceipt = new CUATransferReceiptDTO();

            cuaTransferReceipt.FileName = cuaTransferReceipt.FileName;
            cuaTransferReceipt.Image = cuaTransferReceipt.Image;
            cuaTransferReceipt.FileDate = cuaTransferReceipt.FileDate;
            cuaTransferReceipt.Amount = cuaTransferReceipt.Amount;
            cuaTransferReceipt.ListOfDues = cuaTransferReceipt.ListOfDues != null
                ? cuaTransferReceipt.ListOfDues
                : new List<string>();

            response.TransferReceiptEntity = cuaTransferReceipt;

            return response;
        }
    }
}
