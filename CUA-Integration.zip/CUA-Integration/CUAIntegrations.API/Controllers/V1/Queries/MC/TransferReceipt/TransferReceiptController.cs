﻿using CUAIntegrations.Application.Features.V1.Queries.Mc.TransferReceipts;
using CUAIntegrations.Application.Features.V1.Queries.OutBoundedForMC.TransferReceipts;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace CUAIntegrations.Controllers.V1.Queries.MC.TransferReceipt
{
    [ApiController]
    public class TransferReceiptController : BaseMCController
    {
        private readonly IMediator _mediator;

        public TransferReceiptController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet("{dueNumber}/{firstExitCountryCode}")]
        [ApiVersion("1")]
        public async Task<MCGetTransferReceiptResponse> GetTransferReceipt(
            [FromRoute] string dueNumber,
            [FromRoute] string firstExitCountryCode)
        {
            var query = new GetTransferReceiptQuery(
                dueNumber,
                firstExitCountryCode);

            return await _mediator.Send(query);
        }
    }
}
