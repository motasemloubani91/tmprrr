﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;
using MediatR;

namespace CUAIntegrations.Application.Features.V1.Queries.CUA.DownloadDocument

{
    public record DownloadDocumentQuery(
        string DeclarationNumber,
        string DocumentId,
        string DeclarationType,
        string Year,
        string Port
    ) : IRequest<DownloadDocumentResponse>;

    public class DownloadDocumentResponse
    {
        public SupportingDocumentDetailsDTO? SupportingDocumentDetailsEntity { get; set; }
        public ErrorResponse? ErrorResponse { get; set; }
    }

    public class SupportingDocumentDetailsDTO
    {
        public string RelatedDeclarationNumber { get; set; }
        //TODO Lookups gcc.GCC_DocumentTypesLookup
        public string DocumentCategory { get; set; }
        public string DocumentName { get; set; }
        public string DocumentIdNumber { get; set; }
        //TODO Lookups gcc.GCC_LanguageCodesLookup
        public string? DocumentLanguage { get; set; }
        public string DocumentContent { get; set; }
    }
}
