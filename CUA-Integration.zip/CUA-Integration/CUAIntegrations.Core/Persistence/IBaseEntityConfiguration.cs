﻿namespace CUAIntegrations.Kernel.Core.Persistence
{
    /// <summary>
    /// Marker interface for entity configuration classes.
    /// </summary>
    /// <remarks>
    /// This interface currently doesn't declare any members.
    /// It serves as a marker or tagging interface for entity configuration classes.
    /// Entity configuration classes implementing this interface are typically used
    /// to configure the mapping of entities to database tables using an ORM (EF or Dapper etc..).
    /// </remarks>
    public interface IBaseEntityConfiguration
    {
    }
}
