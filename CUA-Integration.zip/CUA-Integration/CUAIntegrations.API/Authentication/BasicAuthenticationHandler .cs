﻿using CUA_GCC_Integration.Core.Helpers;
using CUAIntegrations.Repository.Base;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Options;
using System.Security.Claims;
using System.Text;
using System.Text.Encodings.Web;

namespace CUAIntegrations.Authentication
{
    public class BasicAuthenticationHandler : AuthenticationHandler<AuthenticationSchemeOptions>
    {
        private readonly ICUAIntegrationUnitOfWork _unitOfWork;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IConfiguration _configuration;

        public BasicAuthenticationHandler(
            IOptionsMonitor<AuthenticationSchemeOptions> options,
            ILoggerFactory logger,
            UrlEncoder encoder,
            ISystemClock clock,
            IHttpContextAccessor httpContextAccessor,
            ICUAIntegrationUnitOfWork unitOfWork,
            IConfiguration configuration)
            : base(options, logger, encoder, clock)
        {
            _unitOfWork = unitOfWork;
            _httpContextAccessor = httpContextAccessor;
            _configuration = configuration;
        }

        protected override Task<AuthenticateResult> HandleAuthenticateAsync()
        {
            var validateAuthentication = Convert.ToBoolean(_configuration["Authentication:CUA:ValidateAuthentication"]);
            if (!validateAuthentication)
            {
                return ConfirmAccess();
            }

            if (!Request.Headers.ContainsKey(RequestHeadersConstants.Authorization))
                return Task.FromResult(AuthenticateResult.Fail("Missing Authorization Header"));

            var authHeader = Request.Headers[RequestHeadersConstants.Authorization].ToString();
            if (!authHeader.StartsWith("Basic "))
                return Task.FromResult(AuthenticateResult.Fail("Invalid Authorization Header"));

            var encodedCredentials = authHeader.Substring("Basic ".Length).Trim();
            var credentialBytes = Convert.FromBase64String(encodedCredentials);
            var credentials = Encoding.UTF8.GetString(credentialBytes).Split(':');
            var username = credentials[0];
            var password = credentials[1];

            var cuaUerName = _configuration["Authentication:CUA:UserName"];
            var cuaPassword = _configuration["Authentication:CUA:Password"];
            if (username != cuaUerName || password != cuaPassword)
            {
                return Task.FromResult(AuthenticateResult.Fail("Invalid Username or Password"));
            }

            return ConfirmAccess();
        }

        private Task<AuthenticateResult> ConfirmAccess()
        {
            var claims = new[] { new Claim(ClaimTypes.Name, Constants.AuthenticationScheme.Basic) };
            var identity = new ClaimsIdentity(claims, Scheme.Name);
            var principal = new ClaimsPrincipal(identity);
            var ticket = new AuthenticationTicket(principal, Scheme.Name);

            return Task.FromResult(AuthenticateResult.Success(ticket));
        }
    }
}
