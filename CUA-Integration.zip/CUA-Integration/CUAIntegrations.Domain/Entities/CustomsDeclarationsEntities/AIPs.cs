﻿namespace CUAIntegrations.Kernel.Domain.Entities.CustomsDeclarationsEntities
{
    public class AIPs
    {
        public long Id { get; set; }
        public long ItemId { get; set; }
        public string? GazetteNumber { get; set; }
        public decimal? Duty { get; set; }
    }
}

