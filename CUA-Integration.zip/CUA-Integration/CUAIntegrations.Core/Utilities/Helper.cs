﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CUA_GCC_Integration.Core.Utilities
{
    public static  class Helper
    {
        private static readonly string[] AllowedCountries = { "QA", "SA", "AE", "KW", "OM", "BH" };

        public static  string? ExtractCountryCodeFromHeader(string? header)
        {
            if (string.IsNullOrWhiteSpace(header))
                return null;

            var upper = header.ToUpperInvariant();
            foreach (var code in AllowedCountries)
            {
                if (upper.Contains(code))
                    return code;
            }
            return null;
        }
    }
}


