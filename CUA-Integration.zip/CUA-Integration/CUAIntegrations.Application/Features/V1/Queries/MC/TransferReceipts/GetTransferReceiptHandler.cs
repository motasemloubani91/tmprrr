﻿using CUA_GCC_Integration.Core.Exceptions.DataNotFound;
using CUA_GCC_Integration.Core.Helpers;
using CUAIntegrations.Application.Features.V1.Queries.Mc.TransferReceipts;
using CUAIntegrations.Application.Services.Http;
using CUAIntegrations.Kernel.Core.Configurations;
using CUAIntegrations.Kernel.Core.Utilities;
using CUAIntegrations.Kernel.Domain.Entities.TransferReceipts;
using CUAIntegrations.Repository.Base;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace CUAIntegrations.Application.Features.V1.Queries.OutBoundedForMC.TransferReceipts
{
    public class GetTransferReceiptHandler
        : IRequestHandler<GetTransferReceiptQuery, MCGetTransferReceiptResponse>
    {
        private readonly ICUAClient _restClient;
        private readonly IBaseConfiguration _baseConfig;
        private readonly ICUAIntegrationUnitOfWork _unitOfWork;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly string _dataEntityTypeId = "5";   // TransferReceipt

        public GetTransferReceiptHandler(
            ICUAClient restClient,
            IBaseConfiguration baseConfig,
            ICUAIntegrationUnitOfWork unitOfWork,
            IHttpContextAccessor httpContextAccessor)
        {
            _restClient = restClient;
            _baseConfig = baseConfig;
            _unitOfWork = unitOfWork;
            _httpContextAccessor = httpContextAccessor;
        }

        public async Task<MCGetTransferReceiptResponse> Handle(
            GetTransferReceiptQuery request,
            CancellationToken cancellationToken)
        {
            var firstExitCountry = request.FirstExitCountryCode?.ToUpperInvariant();

            long? mcLogId = _httpContextAccessor.HttpContext.Request.Headers.TryGetValue(RequestHeadersConstants.X_LOGGING_ID, out var mainHeaderValue)
                && long.TryParse(mainHeaderValue, out var parsedMain)
                ? parsedMain
                : (long?)null;


            var url = $"{_baseConfig.TransferReceiptsUrl.TrimEnd('/')}/{request.DueNumber}";

            var apiResponse = await _restClient.GetAsync<CUAGetTransferReceiptResponse>(url); ;

            var cuaLogId = apiResponse.RequestLogId;


            if (apiResponse == null ||
                !apiResponse.Succeeded ||
                apiResponse.Data?.TransferReceiptEntity == null)
            {
                throw new TransferReceiptNotFoundException();
            }

            var remoteDto = apiResponse.Data.TransferReceiptEntity;

            var existing = await _unitOfWork.TransferReceiptRepository
                .Get()
                .Where(r => r.DueNumber == request.DueNumber)
                .OrderByDescending(r => r.Id)
                .Select(r => new { r.Id, r.Version })
                .FirstOrDefaultAsync(cancellationToken);

            if (existing != null)
            {
                // Get Logging Request ID
                var loggingRequestID = await _unitOfWork.RequestLoggingRepository.Get()
                    .Where(d => d.DataEntityTypeId == _dataEntityTypeId && d.DataEntityId == existing.Id)
                    .OrderByDescending(a => a.Id)
                    .Select(a => a.Id)
                    .FirstOrDefaultAsync(cancellationToken);

                // Find last response body for this request
                var loggingResponseBody = await _unitOfWork.ResponseLoggingRepository.Get()
                    .Where(d => d.RequestId == loggingRequestID)
                    .OrderByDescending(a => a.Id)
                    .Select(a => a.ResponseBody)
                    .FirstOrDefaultAsync(cancellationToken);

                if (loggingResponseBody != null)
                {
                    bool isSame = EntityCompare.AreJsonEqual(loggingResponseBody, apiResponse.JSONData);

                    if (isSame)
                    {
                        await UpdateRequestLoggingAsync(existing.Id, cuaLogId);

                        await UpdateRequestLoggingAsync(existing.Id, mcLogId.Value);

                        return new MCGetTransferReceiptResponse
                        {
                            Id = existing.Id.ToString()
                        };
                    }
                }
            }

            var newEntity = new TransferReceipt();

            newEntity.Id = 0;
            newEntity.Version = 1;
            newEntity.FileName = remoteDto.FileName;
            newEntity.ImageUrl = remoteDto.Image;
            newEntity.FileDate = remoteDto.FileDate;
            newEntity.Amount = remoteDto.Amount;
            newEntity.DueNumber = remoteDto.DueNumber ?? request.DueNumber;

            newEntity.ListOfDues = remoteDto.ListOfDues?
              .Select(d => new TransferReceiptListOfDues
              {
                  DueReference = d,
              })
              .ToList();

            newEntity.Id = 0;
            newEntity.Version = (existing?.Version ?? 0) + 1;

            await _unitOfWork.TransferReceiptRepository.AddAsync(newEntity);
            await _unitOfWork.CommitAsync();


            await UpdateRequestLoggingAsync(newEntity.Id, cuaLogId);

            await UpdateRequestLoggingAsync(newEntity.Id, mcLogId.Value);

            return new MCGetTransferReceiptResponse
            {
                Id = newEntity.Id.ToString(),
            };
        }

        private async Task UpdateRequestLoggingAsync(long dataEntityId, long logId)
        {
            await _unitOfWork.RequestLoggingRepository
                .Get()
                .Where(l => l.Id == logId)
                .ExecuteUpdateAsync(updates => updates
                    .SetProperty(l => l.DataEntityId, dataEntityId)
                    .SetProperty(l => l.DataEntityTypeId, _dataEntityTypeId)
                );

            await _unitOfWork.CommitAsync();
        }
    }
}
