﻿using CUA_GCC_Integration.Core.Exceptions.DataNotFound;
using CUA_GCC_Integration.Core.Helpers;
using CUAIntegrations.Application.Features.V1.Queries.Mc.DueNumbers;
using CUAIntegrations.Application.Services.Http;
using CUAIntegrations.Kernel.Core.Configurations;
using CUAIntegrations.Kernel.Core.Utilities;
using CUAIntegrations.Kernel.Domain.Entities.DueNumbers;
using CUAIntegrations.Repository.Base;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;

namespace CUAIntegrations.Application.Features.V1.Queries.OutBoundedForMC.DueNumbers
{
    public class GetDueNumberHandler : IRequestHandler<GetDueNumberQuery, GetDueNumberResponse>
    {
        private readonly ICUAClient _restClient;
        private readonly IBaseConfiguration _baseConfig;
        private readonly ICUAIntegrationUnitOfWork _unitOfWork;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly string _dataEntityTypeId = 1.ToString(); // DueNumber type
        public GetDueNumberHandler(
            ICUAClient restClient,
            IBaseConfiguration baseConfiguration,
            ICUAIntegrationUnitOfWork unitOfWork,
            IHttpContextAccessor httpContextAccessor)
        {
            _restClient = restClient;
            _baseConfig = baseConfiguration;
            _unitOfWork = unitOfWork;
            _httpContextAccessor = httpContextAccessor;
        }

        public async Task<GetDueNumberResponse> Handle(
            GetDueNumberQuery request,
            CancellationToken cancellationToken)
        {
            long? mcLogId = _httpContextAccessor.HttpContext.Request.Headers.TryGetValue(RequestHeadersConstants.X_LOGGING_ID, out var mainHeaderValue)
                && long.TryParse(mainHeaderValue, out var parsedMain)
                ? parsedMain
                : (long?)null;

            var url = $"{_baseConfig.DueNumberUrl.TrimEnd('/')}/{request.DueNumber}";

            var apiResponse = await _restClient.GetAsync<GetCUADueNumberResponse>(url);
            var cuaLogId = apiResponse.RequestLogId;
            if (apiResponse == null || !apiResponse.Succeeded || apiResponse.Data?.DueNumberEntity == null)
            {
                throw new DueNumberNotFoundException();
            }

            var responseDto = apiResponse.Data.DueNumberEntity;

            var localSavedData = await _unitOfWork.DueNumberRepository
               .Get()
               .Where(d => d.TransferDeclarationNumber == request.DueNumber)
               .OrderByDescending(d => d.Id)
               .Select(d => new { d.Id, d.Version })
               .FirstOrDefaultAsync(cancellationToken);

            if (localSavedData != null)
            {
                var loggingRequestID = await _unitOfWork.RequestLoggingRepository.Get()
                    .Where(d => d.DataEntityTypeId == _dataEntityTypeId && d.DataEntityId == localSavedData.Id)
                    .OrderByDescending(a => a.Id)
                    .Select(a => a.Id)
                    .FirstOrDefaultAsync(cancellationToken);

                var loggingResponseBody = await _unitOfWork.ResponseLoggingRepository.Get()
                    .Where(d => d.RequestId == loggingRequestID)
                    .OrderByDescending(a => a.Id)
                    .Select(a => a.ResponseBody)
                    .FirstOrDefaultAsync(cancellationToken);

                if (loggingResponseBody != null)
                {
                    bool isSame = EntityCompare.AreJsonEqual(loggingResponseBody, apiResponse.JSONData);

                    if (isSame)
                    {
                        await UpdateRequestLoggingAsync(localSavedData.Id, cuaLogId);
                        await UpdateRequestLoggingAsync(localSavedData.Id, mcLogId.Value);

                        return new GetDueNumberResponse { Id = localSavedData.Id.ToString() };
                    }
                }
            }
            var responseEntity = new DueNumber();
            if (responseDto == null) return null;
            responseEntity.TransferDeclarationNumber = responseDto.TransferDeclarationNumber;
            responseEntity.TransferPort = responseDto.TransferPort;
            //TODo DateTime  atif 
            responseEntity.TransferDeclarationDate = 
            DateTime.TryParse(responseDto.TransferDeclarationDate, out var transferDt)
                ? transferDt
                : default;

            responseEntity.FirstEntryDeclarationDate =
            DateTime.TryParse(responseDto.FirstEntryDeclarationDate, out var firstDt)
                ? firstDt
                : default;
            responseEntity.DueAmount = responseDto.DueAmount;
            responseEntity.DestinationCountry = responseDto.DestinationCountry;
            responseEntity.FirstEntryCountry = responseDto.FirstEntryCountry;
            responseEntity.FirstEntryPort = responseDto.FirstEntryPort;
            responseEntity.FirstEntryDeclarationNumber = responseDto.FirstEntryDeclarationNumber;


            responseEntity.Status = responseDto.Status;
            responseEntity.ReceiptFileRef = responseDto.ReceiptFileRef;

            ///////////////////////////////
            var transferPort = await _unitOfWork.PortCodesLookupRepository.Get()
                .Where(d => d.Code == responseDto.TransferPort)
                .Select(a => (long?)a.Id)
                .FirstOrDefaultAsync(cancellationToken);

            if (transferPort == null)
                throw new DueNumberNotFoundException(
                    "The response was rejected because TransferPort lookup does not match the reference list.",
                    "ERR09");

            responseEntity.TransferPort = transferPort.Value.ToString();
            ///////////////////////
            var destinationCountry = await _unitOfWork.CountryCodesLookupRepository.Get()
                .Where(d => d.Code == responseDto.DestinationCountry)
                .OrderByDescending(a => a.Id)
                .Select(a => (long?)a.Id)
                .FirstOrDefaultAsync(cancellationToken);

            if (destinationCountry == null)
                throw new DueNumberNotFoundException(
                    "The response was rejected because DestinationCountry lookup does not match the reference list.",
                    "ERR09");

            responseEntity.DestinationCountry = destinationCountry.Value.ToString();
            ///////////////////////////////
            var firstEntryCountry = await _unitOfWork.CountryCodesLookupRepository.Get()
                .Where(d => d.Code == responseDto.FirstEntryCountry)
                .OrderByDescending(a => a.Id)
                .Select(a => (long?)a.Id)
                .FirstOrDefaultAsync(cancellationToken);

            if (firstEntryCountry == null)
                throw new DueNumberNotFoundException(
                    "The response was rejected because FirstEntryCountry lookup does not match the reference list.",
                    "ERR09");

            responseEntity.FirstEntryCountry = firstEntryCountry.Value.ToString();
            ///////////////////////////////
            var firstEntryPort = await _unitOfWork.PortCodesLookupRepository.Get()
                .Where(d => d.Code == responseDto.FirstEntryPort)
                .OrderByDescending(a => a.Id)
                .Select(a => (long?)a.Id)
                .FirstOrDefaultAsync(cancellationToken);
            if (firstEntryPort == null)
                throw new DueNumberNotFoundException(
                    "The response was rejected because FirstEntryPort lookup does not match the reference list.",
                    "ERR09");

            responseEntity.FirstEntryPort = firstEntryPort.Value.ToString();
            ///////////////////////////////
            var status = await _unitOfWork.DueNumberStatusesLookupRepository.Get()
                .Where(d => d.Code == responseDto.Status)
                .OrderByDescending(a => a.Id)
                .Select(a => (long?)a.Id)
                .FirstOrDefaultAsync(cancellationToken);

            if (status == null)
                throw new DueNumberNotFoundException(
                    "The response was rejected because Status lookup does not match the reference list.",
                    "ERR09");
            responseEntity.Status = status.Value.ToString();
            ///////////////////////////////

            responseEntity.Id = 0;
            responseEntity.Version = (localSavedData?.Version ?? 0) + 1;
            if (responseEntity.DeclarationId == 0)
            {
                var declarationId = await _unitOfWork.CustomsDeclarationsEntitiesRepository
                    .Get()
                    .Where(d => d.DeclarationNumber == responseEntity.TransferDeclarationNumber)
                    .OrderByDescending(a => a.Id)
                    .Select(a => a.Id)
                    .FirstOrDefaultAsync(cancellationToken);

                if (declarationId == null || declarationId == 0)
                {
                    throw new DueNumberNotFoundException("The Declaration Number was not found in the First Exit country’s system. ", "ERR-30");
                }
                responseEntity.DeclarationId = declarationId;
            }
            //var x=JsonSerializer.Serialize(responseEntity);
            await _unitOfWork.DueNumberRepository.AddAsync(responseEntity);
            await _unitOfWork.CommitAsync();
            await UpdateRequestLoggingAsync(responseEntity.Id, cuaLogId);
            await UpdateRequestLoggingAsync(responseEntity.Id, mcLogId.Value);

            return new GetDueNumberResponse { Id = responseEntity.Id.ToString() };
        }

        private async Task UpdateRequestLoggingAsync(long dataEntityId, long logId)
        {
            await _unitOfWork.RequestLoggingRepository
                .Get()
                .Where(l => l.Id == logId)
                .ExecuteUpdateAsync(updates => updates
                    .SetProperty(l => l.DataEntityId, dataEntityId)
                    .SetProperty(l => l.DataEntityTypeId, _dataEntityTypeId)
                );
            await _unitOfWork.CommitAsync();
        }
    }
}
