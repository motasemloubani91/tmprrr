﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;
using MediatR;

namespace CUAIntegrations.Application.Features.V1.Queries.CUA.DueNumbers
{
    public record OutBoundedGetDueNumberQuery(
        string DueNumber
    ) : IRequest<GetDueNumberResponse>;


}
