﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;

namespace CUA_GCC_Integration.Core.Exceptions.Security
{
    public class FailedAuthenticationExeption : Exception
    {
        public int ErrorCode { get; private set; } //mapped to Status property in ErrorResponse
        public string Message { get; private set; } = "Authentication failed. Invalid or expired credentials. ";
        public string Reason { get; private set; } = "SecurityError";
        public List<ErrorDetail>? Details { get; set; }

        public FailedAuthenticationExeption()
        {
            ErrorCode = 401;
        }
        public FailedAuthenticationExeption(List<ErrorDetail>? errorDetails)
        {
            ErrorCode = 401;
            Details = errorDetails;
        }

        protected FailedAuthenticationExeption(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }
    }

}
