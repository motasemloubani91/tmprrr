﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CUAIntegrations.Application.Features.V1.Queries.Mc.DownloadDocument
{
   
    public class CUADownloadDocumentResponse
    {
        public CUASupportingDocumentDetailsDTO? SupportingDocumentDetailsEntity { get; set; }
        public ErrorResponse? ErrorResponse { get; set; }
    }

    public class CUASupportingDocumentDetailsDTO
    {
        public string RelatedDeclarationNumber { get; set; }
        //TODO Lookups gcc.GCC_DocumentTypesLookup
        public string DocumentCategory { get; set; }
        public string DocumentName { get; set; }
        public string DocumentIdNumber { get; set; }
        //TODO Lookups gcc.GCC_LanguageCodesLookup
        public string? DocumentLanguage { get; set; }
        public string DocumentContent { get; set; }
    }
}
