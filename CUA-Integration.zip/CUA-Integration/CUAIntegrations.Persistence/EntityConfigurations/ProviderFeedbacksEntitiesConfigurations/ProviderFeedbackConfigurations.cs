﻿using CUAIntegrations.Kernel.Domain.Entities.ProviderFeedbackEntities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace CUAIntegrations.Persistence.ProviderFeedbacksEntitiConfigurations
{
    public class ProviderFeedbackConfigurations : IEntityTypeConfiguration<ProviderFeedbackEntity>
    {
        public void Configure(EntityTypeBuilder<ProviderFeedbackEntity> entity)
        {
            entity.ToTable("GCC_ProviderFeedbacks", schema: "GCC");

            entity.HasKey(e => e.Id);
            entity.Property(e => e.Id)
                 .ValueGeneratedOnAdd();
            entity.Property(e => e.FeedbackId)
                .IsRequired();

            entity.Property(e => e.OriginalRequestId)
                .IsRequired();

            entity.Property(e => e.ApiEndpoint)
                .IsRequired();

           
        }
    }
}
