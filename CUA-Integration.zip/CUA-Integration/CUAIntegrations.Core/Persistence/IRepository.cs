﻿namespace CUAIntegrations.Kernel.Core.Persistence
{
    /// <summary>
    /// Represents a generic repository interface for data access operations.
    /// </summary>
    /// <typeparam name="T">The type of entity the repository works with.</typeparam>
    public interface IRepository<T> : IRepositoryBase<T> where T : class
    {
        /// <summary>
        /// Adds a new entity to the repository.
        /// </summary>
        /// <param name="entity">The entity to be added.</param>
        /// <returns>The added entity.</returns>
        T Add(T entity);

        /// <summary>
        /// Asynchronously adds a new entity to the repository.
        /// </summary>
        /// <param name="entity">The entity to be added.</param>
        /// <returns>The added entity as a task.</returns>
        Task<T> AddAsync(T entity);

        /// <summary>
        /// Asynchronously adds an array of entities to the repository.
        /// </summary>
        /// <param name="entities">The array of entities to be added.</param>
        Task AddRangeAsync(T[] entities);

        /// <summary>
        /// Removes an entity from the repository.
        /// </summary>
        /// <param name="entity">The entity to be removed.</param>
        void Remove(T entity);

        /// <summary>
        /// Removes an array of entities from the repository.
        /// </summary>
        /// <param name="entities">The array of entities to be removed.</param>
        void RemoveRange(T[] entities);

        /// <summary>
        /// Updates an existing entity in the repository.
        /// </summary>
        /// <param name="entity">The entity to be updated.</param>
        /// <returns>The updated entity.</returns>
        T Update(T entity);
    }
}
