﻿using CUA_GCC_Integration.Core.Exceptions.DataNotFound;
using CUAIntegrations.Persistence.DataAccess.ADO.NET.Models;
using CUAIntegrations.Persistence.DataAccess.ADO.NET;
using MediatR;

namespace CUAIntegrations.Application.Features.V1.Queries.CUA.DueNumbers
{
    public class OutBoundedGetDueNumberHandler
        : IRequestHandler<OutBoundedGetDueNumberQuery, GetDueNumberResponse>
    {
        private readonly ICUADataAccessDataAccess _dataAccessService;

        public OutBoundedGetDueNumberHandler(ICUADataAccessDataAccess dataAccessService)
        {
            _dataAccessService = dataAccessService;
        }

        public async Task<GetDueNumberResponse> Handle(
            OutBoundedGetDueNumberQuery request,
            CancellationToken cancellationToken)
        {
            var response = new GetDueNumberResponse();
            var dueNumber = await _dataAccessService.GetDueNumberAsync(request.DueNumber);
            if (dueNumber is null)
            {
                throw new DueNumberNotFoundException();
            }
            //todo: mapping from the model to the DTO
            var resultDTO = DueNumberMapper.ModelToDTO(dueNumber);
            response.DueNumberEntity = resultDTO; // dueNumber;
            return response;
        }

    }
}
