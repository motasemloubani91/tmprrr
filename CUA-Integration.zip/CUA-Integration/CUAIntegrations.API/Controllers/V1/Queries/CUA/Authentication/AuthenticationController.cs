﻿using CUAIntegrations.Application.Features.V1.Commands.CUA.AuthorizationCallBack;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace CUAIntegrations.Controllers.V1.Queries.CUA.Authentication
{
    public class AuthenticationController : BaseCUAController
    {
        private readonly IMediator _mediator;

        public AuthenticationController(IMediator mediator)
        {
            _mediator = mediator;
        }

        /// <summary>
        /// Receives provider feedback asynchronously from CUA.
        /// </summary>
        [HttpGet("CallBack")]
        [ApiVersion("1")]
        public async Task<IActionResult> CallBack(
            [FromQuery] string Code)
        {
            var command = new AuthorizationCallBackCommand(Code);
            var result = await _mediator.Send(command);
            return StatusCode(200, result);
        }
    }
}
