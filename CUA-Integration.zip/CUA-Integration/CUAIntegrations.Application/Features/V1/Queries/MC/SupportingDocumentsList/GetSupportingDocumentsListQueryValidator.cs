﻿using CUA_GCC_Integration.Core.Helpers;
using CUAIntegrations.Application.Features.V1.Queries.CUA;
using FluentValidation;
using System.Text.RegularExpressions;

namespace CUAIntegrations.Application.Features.V1.Queries.OutBoundedForMC.SupportingDocuments
{
    public class GetSupportingDocumentsListQueryValidator : AbstractValidator<GetSupportingDocumentsListQuery>
    {
        private readonly ISharedValidationHelper _validationHelper;

        public GetSupportingDocumentsListQueryValidator(ISharedValidationHelper validationHelper)
        {
            _validationHelper = validationHelper;

            // --------------------------------------------------------------------
            //  DeclarationNumber 
            // --------------------------------------------------------------------
            RuleFor(x => x.DeclarationNumber)
                .NotEmpty()
                .WithErrorCode("ERR-02")
                .WithMessage("DeclarationNumber is mandatory.");

            RuleFor(x => x.DeclarationNumber)
                .MaximumLength(70)
                .WithErrorCode("ERR-03")
                .WithMessage("DeclarationNumber must not exceed 70 characters.");

            RuleFor(x => x.DeclarationNumber)
                .Matches("^[A-Za-z0-9]+$")
                .WithErrorCode("ERR-03")
                .WithMessage("DeclarationNumber must be alphanumeric.");


            // --------------------------------------------------------------------
            // IssuingCountryCode 
            // --------------------------------------------------------------------
            RuleFor(x => x.IssuingCountryCode)
                .NotEmpty().WithErrorCode("ERR-02").WithMessage("IssuingCountryCode is mandatory.");

            RuleFor(x => x.IssuingCountryCode)
                .Length(2).WithErrorCode("ERR-03").WithMessage("IssuingCountryCode must be exactly 2 characters.");

            //RuleFor(x => x.IssuingCountryCode)
            //    .MustAsync(async (code, _) => await _validationHelper.IsValidCountryCode(code))
            //    .WithErrorCode("ERR-09")
            //    .WithMessage("IssuingCountryCode does not match the reference list.");


            // --------------------------------------------------------------------
            //  Country-Specific Rules: AE
            // --------------------------------------------------------------------
            When(x => x.IssuingCountryCode?.ToUpperInvariant() == ApplicationClientsConstants.UnitedArabEmirates, () =>
            {
                RuleFor(x => x.DeclarationType)
                    .NotEmpty()
                    .WithErrorCode("ERR-02")
                    .WithMessage($"DeclarationType is mandatory for {ApplicationClientsConstants.UnitedArabEmirates}.");

                RuleFor(x => x.DeclarationType)
                    .Length(3)
                    .WithErrorCode("ERR-03")
                    .WithMessage("DeclarationType must be exactly 3 characters.");

                RuleFor(x => x.DeclarationType)
                    .Matches("^[A-Za-z0-9]+$")
                    .WithErrorCode("ERR-03")
                    .WithMessage("DeclarationType must be alphanumeric.");
            });

            // --------------------------------------------------------------------
            //  Country-Specific Rules: SA
            // --------------------------------------------------------------------
            When(x => x.IssuingCountryCode?.ToUpperInvariant() == ApplicationClientsConstants.SaudiArabia, () =>
            {
                // DeclarationType
                RuleFor(x => x.DeclarationType)
                    .NotEmpty()
                    .WithErrorCode("ERR-02")
                    .WithMessage($"DeclarationType is mandatory for {ApplicationClientsConstants.SaudiArabia}.");

                RuleFor(x => x.DeclarationType)
                    .Length(3)
                    .WithErrorCode("ERR-03")
                    .WithMessage("DeclarationType must be exactly 3 characters.");

                // Year
                RuleFor(x => x.Year)
                    .NotEmpty()
                    .WithErrorCode("ERR-02")
                    .WithMessage("Year is mandatory for SA.");

                RuleFor(x => x.Year)
                    .Matches("^[0-9]{4}$")
                    .WithErrorCode("ERR-03")
                    .WithMessage("Year must be a 4-digit number.");

                RuleFor(x => x.Year)
                    .Must(y => _validationHelper.IsValidDeclarationYear(y))
                    .WithErrorCode("ERR-03")
                    .WithMessage("Future years are not allowed.");

                // Port
                RuleFor(x => x.Port)
                    .NotEmpty()
                    .WithErrorCode("ERR-02")
                    .WithMessage("Port is mandatory for SA.");

                RuleFor(x => x.Port)
                    .Length(3)
                    .WithErrorCode("ERR-03")
                    .WithMessage("Port must be exactly 3 characters.");

                RuleFor(x => x.Port)
                    .Matches("^[A-Za-z0-9]+$")
                    .WithErrorCode("ERR-03")
                    .WithMessage("Port must be alphanumeric.");

                //RuleFor(x => x.Port)
                //    .MustAsync(async (code, _) => await _validationHelper.IsValidPortCode(code))
                //    .WithErrorCode("ERR-09")
                //    .WithMessage("Requested port code is not included in the reference list.");
            });
            // --------------------------------------------------------------------
            // Other GCC countries (QA, KW, OM, BH) - optional fields
            // --------------------------------------------------------------------
            When(x => new[]
            {ApplicationClientsConstants.Qatar,ApplicationClientsConstants.Kuwait,ApplicationClientsConstants.Oman,ApplicationClientsConstants.Bahrain}
            .Contains(x.IssuingCountryCode?.ToUpperInvariant()), () =>
            {
                // DeclarationType (optional)
                RuleFor(x => x.DeclarationType)
                    .Length(3)
                    .When(x => !string.IsNullOrWhiteSpace(x.DeclarationType))
                    .WithErrorCode("ERR-03")
                    .WithMessage("DeclarationType must be max 3 characters.");

                RuleFor(x => x.DeclarationType)
                    .Matches("^[A-Za-z0-9]+$")
                    .When(x => !string.IsNullOrWhiteSpace(x.DeclarationType))
                    .WithErrorCode("ERR-03")
                    .WithMessage("DeclarationType must be alphanumeric.");

                // Year (optional)
                RuleFor(x => x.Year)
                    .Matches("^[0-9]{4}$")
                    .When(x => !string.IsNullOrWhiteSpace(x.Year))
                    .WithErrorCode("ERR-03")
                    .WithMessage("Year must be a 4-digit number.");

                //RuleFor(x => x.Year)
                //    .Must(y => string.IsNullOrWhiteSpace(y) || _validationHelper.IsValidDeclarationYear(y))
                //    .When(x => !string.IsNullOrWhiteSpace(x.Year))
                //    .WithErrorCode("ERR-03")
                //    .WithMessage("Future years are not allowed.");

                // Port (optional)
                RuleFor(x => x.Port)
                    .Length(3)
                    .When(x => !string.IsNullOrWhiteSpace(x.Port))
                    .WithErrorCode("ERR-03")
                    .WithMessage("Port must be max 3 characters.");

                RuleFor(x => x.Port)
                    .Matches("^[A-Za-z0-9]+$")
                    .When(x => !string.IsNullOrWhiteSpace(x.Port))
                    .WithErrorCode("ERR-03")
                    .WithMessage("Port must be alphanumeric.");

                //RuleFor(x => x.Port)
                //    .MustAsync(async (code, _) => string.IsNullOrWhiteSpace(code) || await _validationHelper.IsValidPortCode(code))
                //    .When(x => !string.IsNullOrWhiteSpace(x.Port))
                //    .WithErrorCode("ERR-09")
                //    .WithMessage("Requested port code is not included in the reference list.");
            });

        }
    }
}
