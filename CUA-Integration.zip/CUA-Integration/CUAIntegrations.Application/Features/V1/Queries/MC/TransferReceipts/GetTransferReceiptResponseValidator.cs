﻿using CUAIntegrations.Application.Features.V1.Queries.Mc.TransferReceipts;
using FluentValidation;

public class GetTransferReceiptResponseValidator : AbstractValidator<CUAGetTransferReceiptResponse>
{
    public GetTransferReceiptResponseValidator()
    {
       
        RuleFor(x => x.TransferReceiptEntity)
                      .SetValidator(new CUATransferReceiptFromCuaDtoValidator());
    }

}


public class CUATransferReceiptFromCuaDtoValidator : AbstractValidator<CUATransferReceiptFromCuaDto>
{
    public CUATransferReceiptFromCuaDtoValidator()
    {
        // fileName 
        RuleFor(x => x.FileName)
            .NotEmpty()
            .WithErrorCode("ERR-08")
            .WithMessage("Missing mandatory field: fileName.");

        RuleFor(x => x.FileName)
            .MaximumLength(70)
            .WithErrorCode("ERR-11")
            .WithMessage("Invalid field length: fileName max length is 70.");

        RuleFor(x => x.FileName)
            .Matches("^[A-Za-z0-9_\\-\\.]+$")
            .WithErrorCode("ERR-11")
            .WithMessage("Invalid field format: fileName must be alphanumeric or include _ - .");

        // image 
        RuleFor(x => x.Image)
            .NotEmpty()
            .WithErrorCode("ERR-08")
            .WithMessage("Missing mandatory field: image.");


        // fileDate 
        RuleFor(x => x.FileDate)
            .NotNull()
            .WithErrorCode("ERR-08")
            .WithMessage("Missing mandatory field: fileDate.");

        RuleFor(x => x.FileDate)
            .Must(BeValidDate)
            .WithErrorCode("ERR-22")
            .WithMessage("Invalid date format: fileDate must be in YYYYMMDDHHMMSS format.");

        // amount
        RuleFor(x => x.Amount)
            .NotNull()
            .WithErrorCode("ERR-08")
            .WithMessage("Missing mandatory field: amount.");

        RuleFor(x => x.Amount)
            .GreaterThanOrEqualTo(0m)
            .WithErrorCode("ERR-11")
            .WithMessage("Invalid field value: amount cannot be negative.");


        // listOfDues 
        RuleFor(x => x.ListOfDues)
            .NotNull()
            .WithErrorCode("ERR-08")
            .WithMessage("Missing mandatory field: listOfDues.");

        RuleForEach(x => x.ListOfDues)
            .NotEmpty()
            .WithErrorCode("ERR-08")
            .WithMessage("Each due reference in listOfDues is mandatory.");

        RuleForEach(x => x.ListOfDues)
            .MaximumLength(65)
            .WithErrorCode("ERR-11")
            .WithMessage("Each due reference in listOfDues cannot exceed 65 characters.");
    }



    private bool BeValidDate(DateTime date)
    {
        string str = date.ToString("yyyyMMddHHmmss");
        return str.Length == 14;
    }


}
