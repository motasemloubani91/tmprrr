﻿using CUAIntegrations.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CUAIntegrations.Controllers.V1
{
    //[AllowAnonymous]
    [Authorize(AuthenticationSchemes = Constants.AuthenticationScheme.ApiKey)]
    [ApiVersion("1")]
    [Route("mc/v{version:apiVersion}/[controller]")]
    [ApiController]
    public class BaseMCController : ControllerBase
    {
    }
}
