﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;
using System.Net;

namespace CUA_GCC_Integration.Core.Exceptions
{
    public class SystemIntegrationException : Exception
    {
        public HttpStatusCode Code { get; private set; }
        public string Message { get; private set; }
        public string Reason { get; private set; }
        public List<ErrorDetail>? Details { get; set; }

        public SystemIntegrationException()
        {
        }

        public SystemIntegrationException(
            HttpStatusCode errorCode,
            string message = "",
            string reason = "",
            List<ErrorDetail>? details = null)
        {
            Code = errorCode;
            Message = message;
            Reason = reason;
            Details = details ?? new();
        }
    }
}
