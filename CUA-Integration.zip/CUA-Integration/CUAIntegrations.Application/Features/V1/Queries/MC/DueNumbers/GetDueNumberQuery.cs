﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;
using MediatR;

namespace CUAIntegrations.Application.Features.V1.Queries.OutBoundedForMC.DueNumbers
{
    public record GetDueNumberQuery(string DueNumber, string FirstExitCountryCode) : IRequest<GetDueNumberResponse>;

    public class GetDueNumberResponse
    {
        public string? Id { get; set; }
        public ErrorResponse? ErrorResponse { get; set; }
    }
}
