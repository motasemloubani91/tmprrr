﻿

using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using CUAIntegrations.Kernel.Domain.Entities.CustomsDeclarationsEntities;


namespace CUAIntegrations.Persistence.EntityConfigurations.CustomsDeclarationsEntitiesConfigurations
{
    public class CurrenciesConfiguration : IEntityTypeConfiguration<Currencies>
    {
        public void Configure(EntityTypeBuilder<Currencies> entity)
        {
            entity.ToTable("GCC_Currencies", "GCC");
            entity.HasKey(a => a.Id);

            entity.Property(a => a.Type).IsRequired().HasMaxLength(6);
            entity.Property(a => a.Value).HasColumnType("decimal(12,6)").IsRequired();

        }
    }
}
