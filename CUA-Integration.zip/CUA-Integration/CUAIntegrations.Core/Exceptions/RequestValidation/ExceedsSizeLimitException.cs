﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CUA_GCC_Integration.Core.Exceptions.RequestValidation
{
    public class ExceedsSizeLimitException : Exception
    {
        public int ErrorCode { get; private set; } //mapped to Status property in ErrorResponse
        public string Message { get; private set; } = "The request was rejected because it exceeds the allowed file size. ";
        public string Reason { get; private set; } = "ValidationError";
        public List<ErrorDetail>? Details { get; set; }

        public ExceedsSizeLimitException()
        {
            ErrorCode = 413;
        }
        public ExceedsSizeLimitException(List<ErrorDetail>? errorDetails)
        {
            ErrorCode = 413;
            Details = errorDetails;
        }

        protected ExceedsSizeLimitException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }
    }

}
