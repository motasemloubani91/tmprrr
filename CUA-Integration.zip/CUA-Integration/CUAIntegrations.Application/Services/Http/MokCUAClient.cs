﻿using CUA_GCC_Integration.Core.Helpers;
using CUAIntegrations.Kernel.Core.InstanseScopeTypes;
using CUAIntegrations.Kernel.Core.Logging;
using CUAIntegrations.Kernel.Core.Wrappers;
using CUAIntegrations.Kernel.Domain.Entities.LoggingEntities;
using CUAIntegrations.Repository.Base;
using Microsoft.AspNetCore.Http;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

namespace CUAIntegrations.Application.Services.Http
{
    public class MokCUAClient : IScoped, ICUAClient
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IRequestLogger _logger;
        private readonly ICUAIntegrationUnitOfWork _unitOfWork;
        private readonly ITimeHelper _timeHelper;

        private HttpClient _client;
        HttpClientHandler _clientHandler;

        private readonly string _connectionString;
        public MokCUAClient(
            IHttpClientFactory httpClientFactory,
            IHttpContextAccessor httpContextAccessor,
            IRequestLogger logger,
            ICUAIntegrationUnitOfWork unitOfWork,
            ITimeHelper timeHelper, IConfiguration configuration)
        {
            HttpClientHandler clientHandler = new HttpClientHandler()
            {
                SslProtocols = System.Security.Authentication.SslProtocols.Tls12
            };

            clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
            _httpClientFactory = httpClientFactory;
            _httpContextAccessor = httpContextAccessor;
            _logger = logger;
            _unitOfWork = unitOfWork;
            _timeHelper = timeHelper;
            _connectionString = configuration.GetConnectionString("DefaultConnection")
                         ?? throw new InvalidOperationException("No Connection String");
            //AttachCertificate();
            _client = new HttpClient(clientHandler);
        }

        public async Task<Response<T>> GetAsync<T>(string url)
        {
            string entityId = "";
            int entityType = 0;

            // DueNumber
            if (url.Contains("DueNumber", StringComparison.OrdinalIgnoreCase))
            {
                entityType = 1;
                entityId = url.Substring(url.LastIndexOf('/') + 1);
            }
            // CustomsDeclarations
            else if (url.Contains("CustomsDeclarations", StringComparison.OrdinalIgnoreCase))
            {
                entityType = 2;
                entityId = url.Substring(url.LastIndexOf('/') + 1);
            }
            // TransferReceipt
            else if (url.Contains("TransferReceipt", StringComparison.OrdinalIgnoreCase))
            {
                entityType = 5;
                entityId = url.Substring(url.LastIndexOf('/') + 1);
            }
            // SupportingDocuments
            else if (url.Contains("SupportingDocuments", StringComparison.OrdinalIgnoreCase))
            {
                var parts = url.Split('/', StringSplitOptions.RemoveEmptyEntries);

                if (parts.Length >= 5)
                {
                    // /v1/SupportingDocuments/{DeclarationNumber}/{IssuingCountryCode}/{DocumentId}
                    entityType = 5;
                    entityId = parts[^1]; // last segment = DocumentId
                }
                else if (parts.Length >= 4)
                {
                    // /v1/SupportingDocuments/{DeclarationNumber}/{Country}
                    entityType = 4;
                    entityId = parts[^1]; // last segment = country
                }
            }

            var headers = new Dictionary<string, string>();
            var httpHeaders = _httpContextAccessor.HttpContext.Request.Headers;
            headers[RequestHeadersConstants.X_REQUEST_ID] = Guid.NewGuid().ToString();
            headers[RequestHeadersConstants.X_CORRELATION_ID] = httpHeaders[RequestHeadersConstants.X_CORRELATION_ID].ToString();
            headers["X-Request-Timestamp"] = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ssZ");
            headers["X-Client-ID"] = "";
            headers["Authorization"] = "TMP_Authorization";

            var requestLoggingId = await LogRequestAsync(url, headers, "GET");

            //Load mock JSON from DB
            string mockJson = await GetMockJsonAsync(entityId, entityType.ToString());

            if (string.IsNullOrEmpty(mockJson))
            {
                return new Response<T>
                {
                    Succeeded = false,
                    Data = default,
                    JSONData = null,
                    Message = $"No mock data found for {entityType} with ID {entityId}",
                    RequestLogId = requestLoggingId
                };
            }

            // 3️⃣ Deserialize JSON to T
            T mockResult = JsonConvert.DeserializeObject<T>(mockJson);

            // 4️⃣ Fake header for logging
            var fakeHeaders = new Dictionary<string, IEnumerable<string>>
    {
        { "Content-Type", new[] { "application/json" } }
    };

            // 5️⃣ Log mock response
            await LogResponseAsync(200, mockJson, fakeHeaders, requestLoggingId);

            // 6️⃣ Return consistent Response<T>
            return new Response<T>
            {
                Succeeded = true,
                Data = mockResult,
                JSONData = mockJson,
                Message = "",
                RequestLogId = requestLoggingId
            };
        }

        //log request method => return logrequestId
        //log response method( logRequestId + response......)

        private async Task<long> LogRequestAsync(
         string url,
         Dictionary<string, string> headers,
         string method,
         string? requestBody = "")
        {
            var request = new RequestLogging();
            request.Endpoint = url;
            request.Direction = 'O';
            request.HttpMethod = method;
            request.ClientId = "";

            request.XRequestId = headers[RequestHeadersConstants.X_REQUEST_ID].ToString();
            request.XCorrelationId = headers[RequestHeadersConstants.X_CORRELATION_ID].ToString();

            request.Headers = JsonConvert.SerializeObject(headers ?? new Dictionary<string, string>());
            request.RequestBody = requestBody ?? "";

            request.RequestTime = _timeHelper.GetCurrentTime();

            // Save in DB
            var addedLog = await _unitOfWork.RequestLoggingRepository.AddAsync(request);
            await _unitOfWork.CommitAsync();

            // return logging id
            return addedLog.Id;
        }

        private async Task LogResponseAsync(
            int statusCode,
            string? responseBody,
            Dictionary<string, IEnumerable<string>> headers,
            long requestId
        )
        {
            var responseLogging = new ResponseLogging();
            responseLogging.RequestId = requestId;
            responseLogging.ResponseTime = _timeHelper.GetCurrentTime();

            // Add response body
            responseLogging.ResponseBody = responseBody ?? "";

            // Add status code
            responseLogging.StatusCode = statusCode;

            // Correct serialization — do NOT serialize twice!
            responseLogging.ResponseHeaders = JsonConvert.SerializeObject(headers ?? new Dictionary<string, IEnumerable<string>>());

            await _unitOfWork.ResponseLoggingRepository.AddAsync(responseLogging);
            await _unitOfWork.CommitAsync();
        }



        public async Task<string> GetMockJsonAsync(string entityId, string entityType)
        {
            string json = null;

            using (var connection = new SqlConnection(_connectionString))
            using (var command = new SqlCommand(@"
        SELECT TOP 1 ResponseJson
        FROM Gcc.GCC_ResponseMockData
        WHERE EntityId = @EntityId AND EntityType = @EntityType
        ORDER BY Id DESC", connection))
            {
                command.Parameters.AddWithValue("@EntityId", entityId);
                command.Parameters.AddWithValue("@EntityType", entityType);

                await connection.OpenAsync();
                var result = await command.ExecuteScalarAsync();
                json = result?.ToString();
            }


            return json;
        }

    }
}
