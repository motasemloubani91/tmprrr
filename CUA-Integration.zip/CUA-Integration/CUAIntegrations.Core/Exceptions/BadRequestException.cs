﻿using System.Net;

namespace CUAIntegrations.Kernel.Core.Exceptions
{
    public class BadRequestException : Exception
    {
        public int ErrorCode { get; private set; }
        public BadRequestException()
        {
            ErrorCode = (int)HttpStatusCode.BadRequest;
        }
        public BadRequestException(string message) : base(message) { }
        public BadRequestException(string message, int errorCode)
            : base(message)
        {
            this.ErrorCode = errorCode;
        }
        public BadRequestException(string message, Exception inner) : base(message, inner) { }
        public BadRequestException(string message, Exception inner, int errorCode)
            : base(message, inner)
        {
            this.ErrorCode = errorCode;
        }
        protected BadRequestException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }
    }
}
