﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CUAIntegrations.Kernel.Domain.Entities.LoggingEntities
{
    public class ProxyLogs
    {
        public long LogId { get; set; }
        public DateTime Timestamp { get; set; }

        public string RequestId { get; set; } = default!;
        public string CorrelationId { get; set; } = default!;

        public int DataEntityId { get; set; }
        public int DataEntityTypeId { get; set; }

        public string SourceSystem { get; set; } = default!;
        public string TargetSystem { get; set; } = default!;
        public string Direction { get; set; } = default!;
        public string HttpMethod { get; set; } = default!;
        public string HttpPath { get; set; } = default!;

        public int? HttpStatusCode { get; set; }
        public int? LatencyMs { get; set; }

        public string? RequestHeaders { get; set; }
        public string? RequestBody { get; set; }
        public int? RequestSizeBytes { get; set; }

        public string? ResponseHeaders { get; set; }
        public string? ResponseBody { get; set; }
        public int? ResponseSizeBytes { get; set; }

        public string? ErrorMessage { get; set; }
        public string? ErrorStackTrace { get; set; }

        public string? ClientIp { get; set; }
        public string? ApiVersion { get; set; }
        public string? ProxyNodeId { get; set; }
        public string? SessionId { get; set; }
        public string? UserId { get; set; }
        public string? Tags { get; set; }

        public DateTime CreatedAt { get; set; }
    }
}
