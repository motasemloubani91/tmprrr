﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using CUAIntegrations.Kernel.Domain.Entities.Lookups;

namespace CUAIntegrations.Persistence.EntityLookupConfigurations
{
    public class ValuationMethodsLookupConfiguration : IEntityTypeConfiguration<ValuationMethodsLookup>
    {
        public void Configure(EntityTypeBuilder<ValuationMethodsLookup> entity)
        {
            entity.ToTable("GCC_ValuationMethodsLookup", "GCC");
            entity.HasKey(e => e.Id);

            entity.Property(e => e.Code).HasMaxLength(255);
            entity.Property(e => e.ArabicDescription).HasMaxLength(255);
            entity.Property(e => e.EnglishDescription).HasMaxLength(255);
            entity.Property(e => e.Notes).HasMaxLength(255);
        }
    }
}
