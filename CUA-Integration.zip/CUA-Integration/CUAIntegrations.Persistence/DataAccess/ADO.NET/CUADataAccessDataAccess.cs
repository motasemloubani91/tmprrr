﻿using Azure.Core;
using CUA_GCC_Integration.Core.Exceptions.RequestValidation;
using CUA_GCC_Integration.Core.Helpers;
using CUAIntegrations.Kernel.Core.InstanseScopeTypes;
using CUAIntegrations.Persistence.DataAccess.ADO.NET.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Data;

namespace CUAIntegrations.Persistence.DataAccess.ADO.NET
{
    public class CUADataAccessDataAccess : IScoped, ICUADataAccessDataAccess
    {
        private readonly string _connectionString;

        public CUADataAccessDataAccess(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection")
                             ?? throw new InvalidOperationException("NoConnection String");
        }

        public async Task<CUACustomsDeclarationsModel?> GetDeclarationBayanPrintPreviewAsync(string DeclarationId)
        {
            CUACustomsDeclarationsModel customDeclaration = new CUACustomsDeclarationsModel();
            customDeclaration.Items = new List<CuaItemsModel>();
            customDeclaration.Payments = new List<CuaPaymentsModel>();
            DataSet data = new DataSet();

            using (var sCon = new SqlConnection(_connectionString))
            {
                using (var sCmd = new SqlCommand("GCC.GCC_CustomsDeclarationInquiry", sCon))
                {
                    sCon.Open();
                    sCmd.CommandType = CommandType.StoredProcedure;
                    sCmd.Parameters.Add("@DeclarationId", SqlDbType.NVarChar).Value = DeclarationId;

                    SqlDataAdapter da = new SqlDataAdapter(sCmd);
                    da.Fill(data);
                }
            }

            if (data.Tables.Count == 4)
            {
                for (int i = 0; i < data.Tables[1].Rows.Count; i++)
                {
                    var row = data.Tables[1].Rows[i];

                    CuaItemsModel item = new CuaItemsModel();

                    item.HsCode = row.Table.Columns.Contains("HS_CODE") && row["HS_CODE"] != DBNull.Value ? row["HS_CODE"].ToString() : "";
                    item.GoodsDescription = row.Table.Columns.Contains("GoodsDescription") && row["GoodsDescription"] != DBNull.Value ? row["GoodsDescription"].ToString() : "";
                    //item.OriginCountryCode = row.Table.Columns.Contains("LOCATION") && row["LOCATION"] != DBNull.Value ? row["LOCATION"].ToString() : "";
                    item.OriginCountryCode = row.Table.Columns.Contains("OriginCountryCode") && row["OriginCountryCode"] != DBNull.Value ? row["OriginCountryCode"].ToString() : "";
                    item.CifForeignValue = row.Table.Columns.Contains("ForeignValue") && row["ForeignValue"] != DBNull.Value ? Convert.ToDecimal(row["ForeignValue"]) : 0m;
                    item.CifLocalValue = row.Table.Columns.Contains("TotalCIFAmount") && row["TotalCIFAmount"] != DBNull.Value ? Math.Round(Convert.ToDecimal(row["TotalCIFAmount"]), 3) : 0m;
                    item.DutyRate = row.Table.Columns.Contains("DutyRatePercentage") && row["DutyRatePercentage"] != DBNull.Value ? row["DutyRatePercentage"].ToString().Replace(".000", "") : "";
                    item.IncomeType = row.Table.Columns.Contains("IncomeType") && row["IncomeType"] != DBNull.Value ? row["IncomeType"].ToString() : ""; //ISLAM: in QR always read empty string
                    item.TotalDuty = row.Table.Columns.Contains("DutyValue") && row["DutyValue"] != DBNull.Value ? Convert.ToDecimal(row["DutyValue"]) : 0m;
                    item.NetWeight = row.Table.Columns.Contains("NetWeight") && row["NetWeight"] != DBNull.Value ? Convert.ToDecimal(row["NetWeight"]) : 0m;
                    item.GrossWeight = row.Table.Columns.Contains("GrossWeight") && row["GrossWeight"] != DBNull.Value ? Convert.ToDecimal(row["GrossWeight"]) : 0m;
                    item.ExemptionApprovalRef = row.Table.Columns.Contains("ExemptionApprovalRef") && row["ExemptionApprovalRef"] != DBNull.Value ? row["ExemptionApprovalRef"].ToString() : ""; //ISLAM: Previously it was RegulationNo


                    item.Currency = new CuaCurrenciesModel();
                    //item.Currency.Type = row.Table.Columns.Contains("CURRENCY") && row["CURRENCY"] != DBNull.Value ? row["CURRENCY"].ToString() : "";
                    item.Currency.Type = row.Table.Columns.Contains("CurrencyTypeCode") && row["CurrencyTypeCode"] != DBNull.Value ? row["CurrencyTypeCode"].ToString() : "";
                    item.Currency.Value = row.Table.Columns.Contains("RATE") && row["RATE"] != DBNull.Value ? Convert.ToDecimal(row["RATE"]) : 0m;

                    item.Packages = new CuaPackagesModel();
                    item.Packages.Quantity = row.Table.Columns.Contains("PackagesQuantity") && row["PackagesQuantity"] != DBNull.Value ? Convert.ToDecimal(row["PackagesQuantity"]) : null;

                    //item.Packages.Type = row.Table.Columns.Contains("PACKAGE_TYPE") && row["PACKAGE_TYPE"] != DBNull.Value ? row["PACKAGE_TYPE"].ToString() : "";
                    item.Packages.Type = row.Table.Columns.Contains("PackageTypeCode") && row["PackageTypeCode"] != DBNull.Value ? row["PackageTypeCode"].ToString() : "";

                    item.Item = new CuaItemDetailsModel();
                    item.Item.Quantity = row.Table.Columns.Contains("ItemsQuantity") && row["ItemsQuantity"] != DBNull.Value ? Convert.ToDecimal(row["ItemsQuantity"]) : 0m;
                    item.Item.Unit = row.Table.Columns.Contains("ItemUnitCode") && row["ItemUnitCode"] != DBNull.Value ? row["ItemUnitCode"].ToString() : "";

                    item.AIP = new CuaAIPsModel();
                    item.AIP.GazetteNumber = row.Table.Columns.Contains("RegulationNo") && row["RegulationNo"] != DBNull.Value ? row["RegulationNo"].ToString() : "";
                    item.AIP.Duty = (row.Table.Columns.Contains("AIPDuty") && row["AIPDuty"] != DBNull.Value &&
                                     decimal.TryParse(row["AIPDuty"].ToString(), out var dutyVal)) ? dutyVal : (decimal?)null;


                    item.Restrictions = new List<CuaRestrictionsModel>();
                    CuaRestrictionsModel restriction = new CuaRestrictionsModel();
                    restriction.Agency = row.Table.Columns.Contains("RestrictionAgency") && row["RestrictionAgency"] != DBNull.Value ? row["RestrictionAgency"].ToString() : "";
                    restriction.ReleaseRef = row.Table.Columns.Contains("ReleaseReference") && row["ReleaseReference"] != DBNull.Value ? row["ReleaseReference"].ToString() : "";
                    item.Restrictions.Add(restriction);



                    customDeclaration.Items.Add(item);
                }


                if (data.Tables[3].Rows.Count > 0)
                {

                    var DeclarationRow = data.Tables[3].Rows[0];



                    customDeclaration.Version = 0;

                    customDeclaration.DeclarationNumber = DeclarationRow.Table.Columns.Contains("DeclarationNumber") && DeclarationRow["DeclarationNumber"] != DBNull.Value
                        ? DeclarationRow["DeclarationNumber"].ToString()
                        : "";

                    customDeclaration.DeclarationDate = DeclarationRow.Table.Columns.Contains("DeclarationDate") && DeclarationRow["DeclarationDate"] != DBNull.Value
                        ? DeclarationRow["DeclarationDate"].ToString()
                        : "";   // old Date

                    customDeclaration.DeclarationType = DeclarationRow.Table.Columns.Contains("DeclarationType") && DeclarationRow["DeclarationType"] != DBNull.Value
                        ? DeclarationRow["DeclarationType"].ToString()
                        : "";

                    customDeclaration.PortType = DeclarationRow.Table.Columns.Contains("PortType") && DeclarationRow["PortType"] != DBNull.Value
                        ? DeclarationRow["PortType"].ToString()
                        : "";

                    customDeclaration.DeliveryOrderNumber = DeclarationRow.Table.Columns.Contains("DeliveryOrderNumber") && DeclarationRow["DeliveryOrderNumber"] != DBNull.Value
                        ? DeclarationRow["DeliveryOrderNumber"].ToString()
                        : "";

                    customDeclaration.ImporterExporterName = DeclarationRow.Table.Columns.Contains("ImporterExporterName") && DeclarationRow["ImporterExporterName"] != DBNull.Value
                        ? DeclarationRow["ImporterExporterName"].ToString()
                        : "";  // old Consignee

                    customDeclaration.ImporterExporterCustomsId = DeclarationRow.Table.Columns.Contains("ImporterExporterCustomsId") && DeclarationRow["ImporterExporterCustomsId"] != DBNull.Value
                        ? DeclarationRow["ImporterExporterCustomsId"].ToString()
                        : "";// old ConsigneeId

                    customDeclaration.NetWeight = DeclarationRow.Table.Columns.Contains("NetWeight") && DeclarationRow["NetWeight"] != DBNull.Value
                        ? Convert.ToDecimal(DeclarationRow["NetWeight"])
                        : 0;

                    customDeclaration.GrossWeight = DeclarationRow.Table.Columns.Contains("GrossWeight")
                        && DeclarationRow["GrossWeight"] != DBNull.Value
                        && decimal.TryParse(DeclarationRow["GrossWeight"].ToString(), out var gw)
                        ? gw
                        : 0;


                    customDeclaration.Measurement = DeclarationRow.Table.Columns.Contains("Measurement") && DeclarationRow["Measurement"] != DBNull.Value
                        ? DeclarationRow["Measurement"].ToString()
                        : "";

                    customDeclaration.CarrierCaptainDriver = DeclarationRow.Table.Columns.Contains("CarrierCaptainDriver") && DeclarationRow["CarrierCaptainDriver"] != DBNull.Value
                        ? DeclarationRow["CarrierCaptainDriver"].ToString()
                        : ""; // old Captain Name

                    customDeclaration.CarrierName = DeclarationRow.Table.Columns.Contains("CarrierName") && DeclarationRow["CarrierName"] != DBNull.Value
                        ? DeclarationRow["CarrierName"].ToString()
                        : ""; // old Carrier Name

                    customDeclaration.CommercialRegistrationNumber = DeclarationRow.Table.Columns.Contains("CommercialRegistrationNumber") && DeclarationRow["CommercialRegistrationNumber"] != DBNull.Value
                        ? DeclarationRow["CommercialRegistrationNumber"].ToString()
                        : "";  // old TradeLicenseNumber

                    customDeclaration.TinNumber = "";

                    customDeclaration.VoyageFlightNumber = DeclarationRow.Table.Columns.Contains("VoyageFlightNumber") && DeclarationRow["VoyageFlightNumber"] != DBNull.Value
                        ? DeclarationRow["VoyageFlightNumber"].ToString()
                        : ""; //old Voyage/Flight No

                    customDeclaration.ExportedTo = DeclarationRow.Table.Columns.Contains("ExportedTo") && DeclarationRow["ExportedTo"] != DBNull.Value
                        ? DeclarationRow["ExportedTo"].ToString()
                        : ""; //old Exported T

                    customDeclaration.NumberOfPackages =
                            DeclarationRow.Table.Columns.Contains("NoOfPackages") &&
                            DeclarationRow["NoOfPackages"] != DBNull.Value &&
                            int.TryParse(DeclarationRow["NoOfPackages"].ToString().Trim(), out int packages)
                                ? packages
                                : 0;


                    customDeclaration.BlAwbManifestNo = DeclarationRow.Table.Columns.Contains("BlAwbManifestNo") && DeclarationRow["BlAwbManifestNo"] != DBNull.Value
                        ? DeclarationRow["BlAwbManifestNo"].ToString()
                        : "";

                    customDeclaration.PortOfLoading = DeclarationRow.Table.Columns.Contains("PortOfLoading") && DeclarationRow["PortOfLoading"] != DBNull.Value
                        ? DeclarationRow["PortOfLoading"].ToString()
                        : ""; // old Port Of Loading

                    customDeclaration.MarksAndNumbers = DeclarationRow.Table.Columns.Contains("MarksAndNumbers") && DeclarationRow["MarksAndNumbers"] != DBNull.Value
                        ? DeclarationRow["MarksAndNumbers"].ToString()
                        : "";

                    customDeclaration.PortOfDischarge = DeclarationRow.Table.Columns.Contains("PortOfDischarge") && DeclarationRow["PortOfDischarge"] != DBNull.Value
                        ? DeclarationRow["PortOfDischarge"].ToString()
                        : "";  // old Port Of Discharge"

                    //customDeclaration.DestinationCountryCode = DeclarationRow.Table.Columns.Contains("Destination") && DeclarationRow["Destination"] != DBNull.Value
                    //    ? DeclarationRow["Destination"].ToString()
                    //    : "";
                    customDeclaration.DestinationCountryCode = DeclarationRow.Table.Columns.Contains("DestinationCountryCode") && DeclarationRow["DestinationCountryCode"] != DBNull.Value
                      ? DeclarationRow["DestinationCountryCode"].ToString()
                      : "";
                    customDeclaration.IntercessorCompany = DeclarationRow.Table.Columns.Contains("IntercessorCompany") && DeclarationRow["IntercessorCompany"] != DBNull.Value
                        ? DeclarationRow["IntercessorCompany"].ToString()
                        : "";  // old Intercessor

                    customDeclaration.ClearingAgentName = DeclarationRow.Table.Columns.Contains("ClearingAgent") && DeclarationRow["ClearingAgent"] != DBNull.Value
                        ? DeclarationRow["ClearingAgent"].ToString()
                        : "";

                    customDeclaration.ClearingAgentCode = DeclarationRow.Table.Columns.Contains("ClearingAgentCode") && DeclarationRow["ClearingAgentCode"] != DBNull.Value
                        ? DeclarationRow["ClearingAgentCode"].ToString()
                        : "";

                    customDeclaration.LicenseNumber = DeclarationRow.Table.Columns.Contains("LicenceNo") && DeclarationRow["LicenceNo"] != DBNull.Value
                        ? DeclarationRow["LicenceNo"].ToString()
                        : "";

                    customDeclaration.RiskOutcome = DeclarationRow.Table.Columns.Contains("RiskOutcome") && DeclarationRow["RiskOutcome"] != DBNull.Value
                        ? DeclarationRow["RiskOutcome"].ToString()
                        : "";  // old ''
                    customDeclaration.ValuationMethod = DeclarationRow.Table.Columns.Contains("ValuationMethod") && DeclarationRow["ValuationMethod"] != DBNull.Value
                        ? DeclarationRow["ValuationMethod"].ToString()
                        : ""; // old ''
                    customDeclaration.OtherRemarks = DeclarationRow.Table.Columns.Contains("OtherRemarks") && DeclarationRow["OtherRemarks"] != DBNull.Value
                        ? DeclarationRow["OtherRemarks"].ToString()
                        : "";

                    customDeclaration.ReleaseDate = DeclarationRow.Table.Columns.Contains("InspectionReleaseDate") && DeclarationRow["InspectionReleaseDate"] != DBNull.Value
                        ? DeclarationRow["InspectionReleaseDate"].ToString()
                        : "";

                    customDeclaration.Route = DeclarationRow.Table.Columns.Contains("Route") && DeclarationRow["Route"] != DBNull.Value
                        ? DeclarationRow["Route"].ToString()
                        : "";

                    customDeclaration.ExitPort = DeclarationRow.Table.Columns.Contains("ExitPort") && DeclarationRow["ExitPort"] != DBNull.Value
                        ? DeclarationRow["ExitPort"].ToString()
                        : "";
                    customDeclaration.DueNumber = DeclarationRow.Table.Columns.Contains("DueNumber") && DeclarationRow["DueNumber"] != DBNull.Value
                        ? DeclarationRow["DueNumber"].ToString()
                        : "";  // old ''

                    customDeclaration.UnifiedCustomsCode = DeclarationRow.Table.Columns.Contains("UnifiedCustomsCode") && DeclarationRow["UnifiedCustomsCode"] != DBNull.Value
                        ? DeclarationRow["UnifiedCustomsCode"].ToString()
                        : "";

                }

                if (data.Tables[2].Rows.Count > 0)
                {
                    var DeclarationRow2 = data.Tables[2].Rows[0];

                    customDeclaration.TotalDuty = DeclarationRow2.Table.Columns.Contains("Total Duties") && DeclarationRow2["Total Duties"] != DBNull.Value
                        ? Convert.ToDecimal(DeclarationRow2["Total Duties"])
                        : 0;

                    customDeclaration.OtherCharges = DeclarationRow2.Table.Columns.Contains("Other Charges") && DeclarationRow2["Other Charges"] != DBNull.Value
                        ? Convert.ToDecimal(DeclarationRow2["Other Charges"])
                        : null;

                    customDeclaration.Insured = DeclarationRow2.Table.Columns.Contains("Insured") && DeclarationRow2["Insured"] != DBNull.Value
                        ? Convert.ToDecimal(DeclarationRow2["Insured"])
                        : null;

                    customDeclaration.DefiniteFee = DeclarationRow2.Table.Columns.Contains("Definite") && DeclarationRow2["Definite"] != DBNull.Value
                        ? Convert.ToDecimal(DeclarationRow2["Definite"])
                        : 0;

                    customDeclaration.Vat = DeclarationRow2.Table.Columns.Contains("VAT") && DeclarationRow2["VAT"] != DBNull.Value
                        ? Convert.ToDecimal(DeclarationRow2["VAT"])
                        : null;

                    customDeclaration.ExciseTax = DeclarationRow2.Table.Columns.Contains("ExciseTax") && DeclarationRow2["ExciseTax"] != DBNull.Value
                        ? Convert.ToDecimal(DeclarationRow2["ExciseTax"])
                        : null;
                }
                else
                {
                    return null;
                }

                if (data.Tables[0].Rows.Count > 0)
                {
                    customDeclaration.Payments = new List<CuaPaymentsModel>();

                    foreach (DataRow row in data.Tables[0].Rows)
                    {
                        var paymentRow = new CuaPaymentsModel();



                        paymentRow.Method = "";

                        paymentRow.No = row.Table.Columns.Contains("ReceiptNumber") && row["ReceiptNumber"] != DBNull.Value
                            ? row["ReceiptNumber"].ToString()
                            : "";

                        paymentRow.Date = row.Table.Columns.Contains("Date") && row["Date"] != DBNull.Value
                            ? row["Date"].ToString()
                            : null;
                        //      paymentRow.Date = row.Table.Columns.Contains("Cheque Issued Date")
                        //? SafeToNullableDate(row["Cheque Issued Date"])
                        //: null;


                        paymentRow.Bank = row.Table.Columns.Contains("BankName") && row["BankName"] != DBNull.Value
                            ? row["BankName"].ToString()
                            : "";

                        customDeclaration.Payments.Add(paymentRow);
                    }
                }



            }

            else
            {
                throw new InvalidFieldValueException("Data from the database is incorrect");
            }

            return customDeclaration;

        }

        public async Task<CUADueNumberModel?> GetDueNumberAsync(string dueNumber)
        {
            DataSet ds = new DataSet();

            using (var con = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand("GCC.DueNumberPreviewSP_QRGCC", con))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@dueNumber", SqlDbType.NVarChar).Value = dueNumber;

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
            }

            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                CUADueNumberModel result = new CUADueNumberModel();
                var row = ds.Tables[0].Rows[0];

                result.TransferDeclarationNumber = row["transferDeclarationNumber"]?.ToString();
                result.TransferPort = row["transferPort"]?.ToString();

                result.TransferDeclarationDate = row["transferDeclarationDate"] == DBNull.Value
                    ? default
                    : Convert.ToDateTime(row["transferDeclarationDate"]);

                result.DueAmount = row["dueAmount"] == DBNull.Value
                    ? 0
                    : Convert.ToDecimal(row["dueAmount"]);

                result.DestinationCountry = row["destinationCountry"]?.ToString();
                result.FirstEntryCountry = row["firstEntryCountry"]?.ToString();
                result.FirstEntryPort = row["firstEntryPort"]?.ToString();
                result.FirstEntryDeclarationDate = row["firstEntryDeclarationDate"] != DBNull.Value && row["firstEntryDeclarationDate"] != null
         ? Convert.ToDateTime((row["firstEntryDeclarationDate"]))
         : default;



                result.Status = row["status"]?.ToString();
                result.ReceiptFileRef = row["receiptFileRef"]?.ToString();
                return result;
            }

            return null;

        }

        public async Task<CUATransferReceiptModel?> GetTransferReceiptAsync(string dueNumber)
        {
            DataSet ds = new DataSet();
            using (var con = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand("GCC.TransferReceiptPreviewSP_QRGCC", con))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@DueNumber", SqlDbType.NVarChar).Value = dueNumber;

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
            }

            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                CUATransferReceiptModel result = new CUATransferReceiptModel();
                var row = ds.Tables[0].Rows[0];

                result.FileName = row["fileName"]?.ToString();
                result.Image = row["image"]?.ToString();
                result.FileDate = row["fileDate"] == DBNull.Value
                    ? DateTime.MinValue
                    : Convert.ToDateTime(row["fileDate"]);

                result.Amount = row["amount"] == DBNull.Value
                    ? 0
                    : Convert.ToDecimal(row["amount"]);

                // Convert comma-separated dues to List<string>
                var duesString = row["listOfDues"]?.ToString() ?? "";
                result.ListOfDues = duesString
                    .Split(',', StringSplitOptions.RemoveEmptyEntries)
                    .Select(x => x.Trim())
                    .ToList();
                return result;

            }

            return null;

        }

        public async Task<CUASupportingDocumentListModel?> GetSupportedDocumentListAsync(string DeclarationId)
        {
            DataSet ds = new DataSet();

            try
            {
                using (var con = new SqlConnection(_connectionString))
                using (var cmd = new SqlCommand("gcc.GCC_GetSupportedDocumentListInquiry", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@DeclarationNumber", SqlDbType.Int).Value = DeclarationId;

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(ds);
                }

                if (ds.Tables.Count == 0 || ds.Tables[0].Rows.Count == 0)
                    return null;

                var table = ds.Tables[0];

                var supportedDocResult = new CUASupportingDocumentListModel();

                supportedDocResult.Documents = new List<CUASupportingDocumentModel>();

                var doc = new CUASupportingDocumentModel();
                foreach (DataRow row in table.Rows)
                {
                    doc = new CUASupportingDocumentModel();

                    doc.DocumentCategory =
                        row["documentCategory"] == DBNull.Value
                            ? null
                            : row["documentCategory"].ToString();

                    doc.DocumentName =
                        row["documentName"] == DBNull.Value
                            ? null
                            : row["documentName"].ToString();

                    doc.DocumentIdNumber =
                        row["documentIdNumber"] == DBNull.Value
                            ? null
                            : row["documentIdNumber"].ToString();

                    doc.DocumentLanguage =
                        row["documentLanguage"] == DBNull.Value
                            ? null
                            : row["documentLanguage"].ToString();

                    doc.DocumentLink =
                        row["FilePath"] == DBNull.Value
                            ? null
                            : row["FilePath"].ToString();

                    supportedDocResult.Documents.Add(doc);
                }

                return supportedDocResult;
            }
            catch
            {
                return null;
            }
        }

        public async Task<string> GetDeclarationIdAsync(
            string declarationNumber,
            string declarationType,
            string year,
            string port,
            string issuingCountryCode,
            string requestingCountryCode
        )
        {
            string declarationId = null;

            using (var sCon = new SqlConnection(_connectionString))
            using (var sCmd = new SqlCommand("GCC.USP_GetKWDeclaration", sCon))
            {
                sCmd.CommandType = CommandType.StoredProcedure;
                sCmd.Parameters.Add("@declarationNumber", SqlDbType.NVarChar, 35).Value = declarationNumber;
                sCmd.Parameters.Add("@issuingCountryCode", SqlDbType.VarChar, 5).Value = issuingCountryCode;
                sCmd.Parameters.Add("@declarationType", SqlDbType.VarChar, 3).Value = declarationType;
                sCmd.Parameters.Add("@year", SqlDbType.NVarChar, 4).Value = year;
                sCmd.Parameters.Add("@port", SqlDbType.NVarChar, 4).Value = port;
                sCmd.Parameters.Add("@RequestingCountryCode", SqlDbType.VarChar, 30).Value = requestingCountryCode;
                var errorCodeParam = new SqlParameter("@ErrorCode", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                sCmd.Parameters.Add(errorCodeParam);

                var declarationIdParam = new SqlParameter("@DeclarationId", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                sCmd.Parameters.Add(declarationIdParam);

                await sCon.OpenAsync();
                await sCmd.ExecuteNonQueryAsync();

                if (!string.IsNullOrWhiteSpace(errorCodeParam.Value.ToString()) && errorCodeParam.Value != "0")
                {
                    var errorCode = Convert.ToInt32(errorCodeParam.Value);
                    if (errorCode == 1)
                    {
                        throw new InvalidFieldValueException(
                            message: "The request was rejected because the Issuing Country Code is invalid.",
                            details: new List<Kernel.Domain.Dtos.ErrorResponse.ErrorDetail>()
                            {
                            new Kernel.Domain.Dtos.ErrorResponse.ErrorDetail
                            {
                                InnerCode = "ERR-04",
                                Location = "Headers",
                                Message = "The request was rejected because the Issuing Country Code is invalid.",
                                Severity = "High"
                            }
                            });
                    }
                    else if (errorCode == 2)
                    {
                        throw new InvalidFieldValueException(
                            message: $"The request was rejected because the Declaration Type  Not Found .",
                            details: new List<Kernel.Domain.Dtos.ErrorResponse.ErrorDetail>()
                            {
                            new Kernel.Domain.Dtos.ErrorResponse.ErrorDetail
                            {
                                InnerCode = "ERR-03",
                                Location = "Headers",
                                Message = $"The request was rejected because the Declaration Type  Not Found",
                                Severity = "High"
                            }
                            });
                    }
                    else if (errorCode == 3)
                    {
                        throw new InvalidFieldValueException(
                            message: "The request was rejected because the Port is invalid.",
                            details: new List<Kernel.Domain.Dtos.ErrorResponse.ErrorDetail>()
                            {
                            new Kernel.Domain.Dtos.ErrorResponse.ErrorDetail
                            {
                                InnerCode = "ERR-03",
                                Location = "Headers",
                                Message = "The request was rejected because the Port is invalid.",
                                Severity = "High"
                            }
                            });
                    }
                    else if (errorCode == 4)
                    {
                        throw new InvalidFieldValueException(
                            message: "The request was rejected because the declaration is invalid.",
                            details: new List<Kernel.Domain.Dtos.ErrorResponse.ErrorDetail>()
                            {
                            new Kernel.Domain.Dtos.ErrorResponse.ErrorDetail
                            {
                                InnerCode = "ERR-03",
                                Location = "Headers",
                                Message = "The request was rejected because the Declaration  is invalid.",
                                Severity = "High"
                            }
                            });
                    }
                    else if (errorCode == 5)
                    {
                        throw new InvalidFieldValueException(
                            message: "The request was rejected because the Not in a valid state.",
                            details: new List<Kernel.Domain.Dtos.ErrorResponse.ErrorDetail>()
                            {
                            new Kernel.Domain.Dtos.ErrorResponse.ErrorDetail
                            {
                                InnerCode = "ERR-04",
                                Location = "Headers",
                                Message = "The request was rejected because the Not in a valid state.",
                                Severity = "High"
                            }
                            });
                    }
                    else if (errorCode == 6)
                    {
                        throw new InvalidFieldValueException(
                            message: "The request was rejected because Not a valid declaration type.",
                            details: new List<Kernel.Domain.Dtos.ErrorResponse.ErrorDetail>()
                            {
                            new Kernel.Domain.Dtos.ErrorResponse.ErrorDetail
                            {
                                InnerCode = "ERR-04",
                                Location = "Headers",
                                Message = "The request was rejected because Not a valid declaration type.",
                                Severity = "High"
                            }
                            });
                    }
                    else if (errorCode == 7)
                    {
                        throw new InvalidFieldValueException(
                            message: "The request was rejected because Declaration not bound to requesting country",
                            details: new List<Kernel.Domain.Dtos.ErrorResponse.ErrorDetail>()
                            {
                            new Kernel.Domain.Dtos.ErrorResponse.ErrorDetail
                            {
                                InnerCode = "ERR-04",
                                Location = "Headers",
                                Message = "The request was rejected because the Issuing Country Code is invalid.",
                                Severity = "High"
                            }
                            });
                    }
                    else
                    {
                        throw new Exception("Internal Declaration Number Validation Issue.");
                    }
                }

                declarationId = declarationIdParam.Value?.ToString();
            }

            return declarationId;
        }

        private DateTime? SafeToNullableDate(object value)
        {
            if (value == null || value == DBNull.Value) return null;

            var s = value.ToString().Trim();
            if (string.IsNullOrEmpty(s)) return null;

            // 1) Try direct DateTime parse (handles many cultures/formats)
            if (DateTime.TryParse(s, out var dt)) return dt;

            // 2) Try common explicit formats (add more if you need)
            var formats = new[] {
        "dd/MM/yyyy", "d/M/yyyy",
        "MM/dd/yyyy", "M/d/yyyy",
        "yyyy-MM-dd", "yyyyMMdd",
        "dd-MM-yyyy", "d-M-yyyy",
        "dd/MM/yyyy HH:mm:ss", "yyyy-MM-dd HH:mm:ss"
    };
            if (DateTime.TryParseExact(s, formats, System.Globalization.CultureInfo.InvariantCulture,
                                       System.Globalization.DateTimeStyles.None, out dt))
                return dt;

            // 3) If value might be an Excel OLE Automation date (numeric)
            if (double.TryParse(s, out var oa))
            {
                try { return DateTime.FromOADate(oa); }
                catch { /* fallthrough */}
            }

            // 4) If nothing worked, return null (or choose a default)
            return null;
        }
    }
}
