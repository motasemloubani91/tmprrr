﻿using CUA_GCC_Integration.Core.Helpers;
using CUAIntegrations.Repository.Base;
using Microsoft.AspNetCore.Authentication;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using System.Security.Claims;
using System.Text.Encodings.Web;

namespace CUAIntegrations.Authentication
{
    public class ApiKeyAuthenticationHandler : AuthenticationHandler<AuthenticationSchemeOptions>
    {
        private readonly ICUAIntegrationUnitOfWork _unitOfWork;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IConfiguration _configuration;

        public ApiKeyAuthenticationHandler(
            IOptionsMonitor<AuthenticationSchemeOptions> options,
            ILoggerFactory logger,
            UrlEncoder encoder,
            ISystemClock clock,
            IHttpContextAccessor httpContextAccessor,
            ICUAIntegrationUnitOfWork unitOfWork,
            IConfiguration configuration)
            : base(options, logger, encoder, clock)
        {
            _unitOfWork = unitOfWork;
            _httpContextAccessor = httpContextAccessor;
            _configuration = configuration;
        }

        protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
        {
            var validateAuthentication = Convert.ToBoolean(_configuration["Authentication:MC:ValidateAuthentication"]);
            if (!validateAuthentication)
            {
                return await ConfirmAccess();
            }

            if (!Request.Headers.TryGetValue(RequestHeadersConstants.X_AppKey, out var appKeyValues))
            {
                return AuthenticateResult.Fail("Missing API Key");
            }
            if (!Request.Headers.TryGetValue(RequestHeadersConstants.X_SecretKey, out var secretKeyValues))
            {
                return AuthenticateResult.Fail("Missing API Secret");
            }

            var appKey = appKeyValues.FirstOrDefault();
            var secretKey = secretKeyValues.FirstOrDefault();

            var validAppKey = _configuration["Authentication:MC:AppKey"];
            var validSecretKey = _configuration["Authentication:MC:SecretKey"];

            var isValid = appKey == validAppKey && secretKey == validSecretKey;
            if (!isValid)
            {
                return AuthenticateResult.Fail("Invalid AppKey or SecretKey");
            }

            return await ConfirmAccess();
        }

        private async Task<AuthenticateResult> ConfirmAccess()
        {
            if (_httpContextAccessor.HttpContext.Request.Headers.TryGetValue(RequestHeadersConstants.X_LOGGING_ID, out var loggingId))
            {
                long longLoggingId = Convert.ToInt64(loggingId);

                await _unitOfWork.RequestLoggingRepository
                   .Get()
                   .Where(l => l.Id == longLoggingId)
                   .ExecuteUpdateAsync(setters => setters
                       .SetProperty(log => log.ClientId, ApplicationClientsConstants.MC)
                   );
            }

            var claims = new[]
            {
                new Claim(ClaimTypes.Name, Constants.AuthenticationScheme.ApiKey)
            };
            var identity = new ClaimsIdentity(claims, Scheme.Name);
            var principal = new ClaimsPrincipal(identity);
            var ticket = new AuthenticationTicket(principal, Scheme.Name);
            return AuthenticateResult.Success(ticket);
        }
    }
}
