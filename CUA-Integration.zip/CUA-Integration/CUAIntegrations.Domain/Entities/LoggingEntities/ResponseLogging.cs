﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CUAIntegrations.Kernel.Domain.Entities.LoggingEntities
{
    public class ResponseLogging
    {
        public long Id { get; set; }
        public long RequestId { get; set; }
        public int? StatusCode { get; set; }
        public string? ResponseHeaders { get; set; }
        public string? ResponseBody { get; set; }
        public DateTime ResponseTime { get; set; }
        public RequestLogging Request { get; set; }

    }
}
