﻿using CUAIntegrations.Application.Features.V1.Commands.CUA.ProviderFeedback;
using CUAIntegrations.Kernel.Domain.Dtos.ProviderFeedbackRequest;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace CUAIntegrations.Controllers.V1.Commands.CUA.Feedback
{
    public class ProviderFeedbackController : BaseCUAController
    {
        private readonly IMediator _mediator;

        public ProviderFeedbackController(IMediator mediator)
        {
            _mediator = mediator;
        }

        /// <summary>
        /// Receives provider feedback asynchronously from CUA.
        /// </summary>
        [HttpPost("issues")]
        [ApiVersion("1")]
        public async Task<IActionResult> ReceiveFeedback(
            [FromBody] ProviderFeedbackRequest feedback)
        {
            var command = new ReceiveProviderFeedbackCommand(feedback);
            var result = await _mediator.Send(command);
            return StatusCode(200, result);
        }
    }
}


