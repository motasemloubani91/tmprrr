﻿using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace CUAIntegrations.Application.Features.V1.Queries.CUA.CustomsDeclarations
{
    public record GetOutBoundedCustomsDeclarationQuery(
            string DeclarationNumber,
            string DeclarationType,
            string Year,
            string Port
        ) : IRequest<OutBoundedCustomsDeclarationResponse>;
}
