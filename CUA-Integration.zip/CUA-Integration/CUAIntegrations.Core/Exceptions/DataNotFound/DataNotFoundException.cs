﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;
using System.Net;

namespace CUA_GCC_Integration.Core.Exceptions.DataNotFound
{
    public class DataNotFoundException : SystemIntegrationException
    {
        const string message =  "The declaration was not found in the issuing country's system";
        const string reason = "Data Not Found.";

        public DataNotFoundException() :
            base(errorCode: HttpStatusCode.NotFound,
                message: message,
                reason: reason)
        {
        }

        public DataNotFoundException(
            string message = message,
            string reason = reason,
            List<ErrorDetail>? details = null) :
            base(errorCode: HttpStatusCode.NotFound,
                message: message,
                reason: reason,
                details: details)
        {
        }
    }
}
