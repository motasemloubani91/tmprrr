﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;

namespace CUA_GCC_Integration.Core.Exceptions.Security
{
    public class FailedAuthorizationException : Exception
    {
        public int ErrorCode { get; private set; } //mapped to Status property in ErrorResponse
        public string Message { get; private set; } = "Authorization failed. Insufficient permissions to access resource. ";
        public string Reason { get; private set; } = "SecurityError";
        public List<ErrorDetail>? Details { get; set; }

        public FailedAuthorizationException()
        {
            ErrorCode = 403;
        }
        public FailedAuthorizationException(List<ErrorDetail>? errorDetails)
        {
            ErrorCode = 403;
            Details = errorDetails;
        }

        protected FailedAuthorizationException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }
    }

}
