﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;

namespace CUAIntegrations.Application.Features.V1.Queries.Mc.DueNumbers
{
    public class GetCUADueNumberResponse
    {
        public CUADueNumberModel DueNumberEntity { get; set; }
        public ErrorResponse? ErrorResponse { get; set; }
    }

    public class CUADueNumberModel
    {
        public string TransferDeclarationNumber { get; set; }
        //TODO Lookups TableName => GCC_GCCPortCodesLookup
        public string TransferPort { get; set; }
        public string TransferDeclarationDate { get; set; }
        public decimal DueAmount { get; set; }
        //TODO Lookups TableName => GCC_CountryCodesLookup
        public string DestinationCountry { get; set; }
        //TODO Lookups TableName => GCC_CountryCodesLookup
        public string FirstEntryCountry { get; set; }
        //TODO Lookups TableName => GCCPortCodesLookup
        public string FirstEntryPort { get; set; }
        public string FirstEntryDeclarationNumber { get; set; }
        public string FirstEntryDeclarationDate { get; set; }
        //TODO Lookups  TableName =>    gcc.GCC_DueNumberStatusesLookup
        public string Status { get; set; }
        public string ReceiptFileRef { get; set; }
    }
}
