﻿using CUAIntegrations.Persistence.DataAccess.ADO.NET.Models;

namespace CUAIntegrations.Application.Features.V1.Queries.CUA.DueNumbers
{
    public static class DueNumberMapper
    {
        public static GetDueNumberDTO ModelToDTO(CUADueNumberModel model)
        {
            if (model == null) return null;

            var DTO = new GetDueNumberDTO();

            DTO.TransferDeclarationNumber = model.TransferDeclarationNumber;
            DTO.TransferPort = model.TransferPort;
            DTO.TransferDeclarationDate = model.TransferDeclarationDate;
            DTO.DueAmount = model.DueAmount;
            DTO.DestinationCountry = model.DestinationCountry;
            DTO.FirstEntryCountry = model.FirstEntryCountry;
            DTO.FirstEntryPort = model.FirstEntryPort;
            DTO.FirstEntryDeclarationNumber = model.FirstEntryDeclarationNumber;
            DTO.FirstEntryDeclarationDate = model.FirstEntryDeclarationDate;
            DTO.Status = model.Status;
            DTO.ReceiptFileRef = model.ReceiptFileRef;


            return DTO;
        }

    }
}
