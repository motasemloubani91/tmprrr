﻿using CUAIntegrations.Application.Features.V1.Queries.CUA.DueNumbers;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace CUAIntegrations.Controllers.V1.Queries.CUA.DueNumber
{
    public class DueNumberController : BaseCUAController
    {
        private readonly IMediator _mediator;

        public DueNumberController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet("{dueNumber}")]
        [ApiVersion("1")]
        public async Task<GetDueNumberResponse> OutBoundedGetDueNumber(
           [FromRoute] string dueNumber)
        {
            var query = new OutBoundedGetDueNumberQuery(dueNumber);
            return await _mediator.Send(query);
        }
    }
}
