﻿using CUAIntegrations.Kernel.Core.Domain.BaseEntities;
using CUAIntegrations.Kernel.Core.Persistence;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.Reflection;

namespace CUAIntegrations.Persistence.DataAccess.Context
{
    public class BaseDbContext<TDbContext> : DbContext where TDbContext : DbContext
    {
        protected IHttpContextAccessor _HttpContextAccessor { get; }

        public BaseDbContext(DbContextOptions<TDbContext> options, IHttpContextAccessor httpContextAccessor)
            : base(options)
        {
            _HttpContextAccessor = httpContextAccessor;
        }

        protected virtual void HandleSaveChanges()
        {
            int userId = 0; // placeholder for user tracking
            DateTime dateTime = DateTime.Now;

            var modifiedEntries = ChangeTracker.Entries()
                .Where(x => x.Entity is IAuditableEntity &&
                    (x.State == EntityState.Added ||
                     x.State == EntityState.Modified ||
                     x.State == EntityState.Deleted));

            foreach (var entry in modifiedEntries)
            {
                var entity = entry.Entity as IAuditableEntity;
                if (entity == null) continue;

                switch (entry.State)
                {
                    case EntityState.Added:
                        entity.EntityCreated(userId, dateTime);
                        break;

                    case EntityState.Modified:
                        base.Entry(entity).Property(x => x.CreatedById).IsModified = false;
                        base.Entry(entity).Property(x => x.CreatedAt).IsModified = false;

                        if (base.Entry(entity).Property(x => x.IsActive).CurrentValue)
                        {
                            entity.EntityUpdated(userId, dateTime, base.Entry(entity).Property(x => x.IsActive).IsModified);
                            base.Entry(entity).Property(x => x.LastModifiedById).IsModified = true;
                            base.Entry(entity).Property(x => x.LastModifiedAt).IsModified = true;
                            base.Entry(entity).Property(x => x.IsActive).IsModified = true;
                        }
                        else
                        {
                            entity.EntityDeactivated(userId, dateTime);
                            base.Entry(entity).Property(x => x.DeactivatedById).IsModified = true;
                            base.Entry(entity).Property(x => x.DeactivatedAt).IsModified = true;
                            base.Entry(entity).Property(x => x.IsActive).IsModified = true;
                        }
                        break;
                }

                var validationContext = new ValidationContext(entity);
                Validator.ValidateObject(entity, validationContext);
            }
        }

        /// <summary>
        /// Registers all IEntityTypeConfiguration mappings found in CUA Persistence assemblies.
        /// </summary>
        protected virtual void RegisterMappings(ModelBuilder modelBuilder)
        {
            // Load all relevant assemblies
            var mappingAssemblies = AppDomain.CurrentDomain
                .GetAssemblies()
                .Where(a =>
                    a.ManifestModule != null &&
                    (
                        a.FullName.Contains("Persistence", StringComparison.OrdinalIgnoreCase) ||
                        a.FullName.Contains("CUA", StringComparison.OrdinalIgnoreCase)
                    ))
                .ToList();

            // Find configuration types implementing IEntityTypeConfiguration<>
            var mappingTypes = mappingAssemblies
                .SelectMany(a => a.GetTypes())
                .Where(t =>
                    t.IsClass &&
                    !t.IsAbstract &&
                    t.GetInterfaces().Any(i =>
                        i.IsGenericType &&
                        i.GetGenericTypeDefinition() == typeof(IEntityTypeConfiguration<>)))
                .ToList();

            // Apply all mappings dynamically
            foreach (var type in mappingTypes)
            {
                modelBuilder.ApplyConfiguration((dynamic)Activator.CreateInstance(type));
            }
        }
    }
}
