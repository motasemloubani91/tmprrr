﻿using CUA_GCC_Integration.Core.Helpers;
using CUAIntegrations.Application.Features.V1.Queries.CUA;
using CUAIntegrations.Application.Features.V1.Queries.CUA.CustomsDeclarations;
using CUAIntegrations.Application.Features.V1.Queries.OutBoundedForMC.CustomsDeclarations;
using CUAIntegrations.Application.Features.V1.Queries.OutBoundedForMC.DueNumbers;
using CUAIntegrations.Application.Features.V1.Queries.OutBoundedForMC.TransferReceipts;
using CUAIntegrations.Application.Services.CUAServices;
using CUAIntegrations.Application.Services.CUAServices.GCCLoggingService;
using CUAIntegrations.Application.Services.FileManagement;
using CUAIntegrations.Application.Services.Http;
using CUAIntegrations.Authentication;
using CUAIntegrations.Kernel.Core.Configurations;
using CUAIntegrations.Kernel.Core.Logging;
using CUAIntegrations.Kernel.Host.API.Middleware;
using CUAIntegrations.Persistence.DataAccess.ADO.NET;
using CUAIntegrations.Persistence.DataAccess.Context;
using CUAIntegrations.Repository.Base;
using CUAIntegrations.Swagger;
using FluentValidation;
using FluentValidation.AspNetCore;
using MediatR;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;

var builder = WebApplication.CreateBuilder(args);

//  Configuration
var configuration = builder.Configuration;

//  Add Controllers
builder.Services.AddControllers();

//  Add Logging
builder.Logging.ClearProviders();
builder.Logging.AddConsole(); // optional, for debugging
builder.Logging.AddDebug();   // optional
builder.Services.AddApiVersioning(options =>
{
    options.DefaultApiVersion = new ApiVersion(1, 0);
    options.AssumeDefaultVersionWhenUnspecified = true;
    options.ReportApiVersions = true;
});

builder.Services.AddAuthentication(options =>
{
})
.AddScheme<AuthenticationSchemeOptions, ApiKeyAuthenticationHandler>(Constants.AuthenticationScheme.Basic, null)
.AddScheme<AuthenticationSchemeOptions, ApiKeyAuthenticationHandler>(Constants.AuthenticationScheme.ApiKey, null);

// TODO ERROR BY ATIF 
builder.Services.AddSingleton<IClientCertificateValidator, ClientCertificateValidator>();
builder.Services.AddScoped<ISharedValidationHelper, SharedValidationsHelper>();

builder.Services.AddFluentValidationAutoValidation(); // optional helper
//builder.Services.AddValidatorsFromAssemblies(AppDomain.CurrentDomain.GetAssemblies());
builder.Services.AddValidatorsFromAssembly(typeof(GetCustomsDeclarationQueryValidator).Assembly);
builder.Services.AddValidatorsFromAssembly(typeof(GetDueNumberQueryValidator).Assembly);
builder.Services.AddValidatorsFromAssembly(typeof(GetTransferReceiptQueryValidator).Assembly);

builder.Services.AddScoped<ITimeHelper, TimeHelper>();

// Register pipeline behavior
builder.Services.AddTransient(typeof(IPipelineBehavior<,>), typeof(RequestValidationBehavior<,>));

builder.Services.AddAuthorization();



builder.Services.AddScoped<ICUADataAccessDataAccess, CUADataAccessDataAccess>();
builder.Services.AddScoped<IFileManagementService, FileManagementService>();
builder.Services.AddScoped<IFileTokenDataAccess, FileTokenDataAccess>();
builder.Services.AddScoped<ICUAAuthenticationService, CUAAuthenticationService>();


//  Register MediatR Handlers (registers all automatically)
builder.Services.AddMediatR(cfg =>
{
    cfg.RegisterServicesFromAssemblyContaining<GetOutBoundedCustomsDeclarationHandler>();
});
//  UnitOfWork
builder.Services.AddScoped<ICUAIntegrationUnitOfWork, CUAIntegrationUnitOfWork>();
builder.Services.AddScoped<IGccLoggingService, GccLoggingService>();

//  HttpContext
builder.Services.AddHttpContextAccessor();

//  Register Database Context
builder.Services.AddDbContext<CUAIntegrationDbContext>(options =>
    options.UseSqlServer(configuration.GetConnectionString("DefaultConnection"))
           .EnableSensitiveDataLogging()
           .LogTo(Console.WriteLine, LogLevel.Information));

//  Register Base Configuration (binds from appsettings.json)
builder.Services.Configure<BaseConfiguration>(configuration.GetSection("CUAURLS"));
builder.Services.AddScoped<IBaseConfiguration>(sp =>
{
    var config = new CUAIntegrations.Kernel.Core.Configurations.BaseConfiguration();
    configuration.GetSection("CUAURLS").Bind(config);
    config.ConnectionStrings = new ConnectionString
    {
        DefaultConnection = configuration.GetConnectionString("DefaultConnection")
    };
    return config;
});


//  Register Logging + HTTP Client + RestClient
builder.Services.AddScoped<IRequestLogger, RequestLogger>();
builder.Services.AddHttpClient(); // Required for IHttpClientFactory

if (configuration["CUAIntegrationSource"] == "Live")
{
    builder.Services.AddScoped<ICUAClient, CUAClient>();
}
else
{
    builder.Services.AddScoped<ICUAClient, MokCUAClient>();
}

//  Swagger
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.CustomSchemaIds(type =>
        type.FullName.Replace("+", "."));



    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Description = "Please insert JWT with Bearer into field",
        Name = "Authorization",
        In = ParameterLocation.Header,
        Type = SecuritySchemeType.ApiKey
    });

    c.AddSecurityRequirement(new OpenApiSecurityRequirement {
                {
                  new OpenApiSecurityScheme
                  {
                    Reference = new OpenApiReference
                    {
                      Type = ReferenceType.SecurityScheme,
                      Id = "Bearer"
                    }
                   },
                   new string[] { }
                 }
                });


    c.OperationFilter<AddHeaderParameters>();
});

builder.Services.AddLogging();

//  Build app
var app = builder.Build();

//  Middleware
//if (app.Environment.IsDevelopment())
//{
app.UseSwagger();
app.UseSwaggerUI();
//}

app.UseAPIContextLoggingMiddleware();
app.UseExceptionMiddleware();
app.UsHeadersValidatorMiddleware();
app.UsCertificateValidatorMiddleware();
app.UseAuthorization();
app.UseMiddleware<ExceptionMiddleware>();

app.MapControllers();

app.Run();
