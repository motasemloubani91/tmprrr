﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;

namespace CUA_GCC_Integration.Core.Exceptions.ResponseValidation
{
    public class InvalidDateFormatException : Exception
    {
        public int ErrorCode { get; private set; } //mapped to Status property in ErrorResponse
        public string Message { get; private set; } = "Invalid date or time format. Date must be in YYYYMMDDHHMMSS format. ";
        public string Reason { get; private set; } = "ValidationError";
        public List<ErrorDetail>? Details { get; set; }

        public InvalidDateFormatException()
        {
            ErrorCode = 400;
        }
        public InvalidDateFormatException(List<ErrorDetail>? errorDetails)
        {
            ErrorCode = 400;
            Details = errorDetails;
        }

        protected InvalidDateFormatException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }
    }

}
