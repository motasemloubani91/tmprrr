﻿namespace CUAIntegrations.Kernel.Core.InstanseScopeTypes
{
    public interface ITransient
    {
    }
}
