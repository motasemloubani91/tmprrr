using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;

namespace CUA_GCC_Integration.Core.Exceptions.BusinessRules
{
    public class FinalDestCountryNotMatchingRequestingCountryException : Exception
    {
        public int ErrorCode { get; private set; } //mapped to Status property in ErrorResponse
        public string Message { get; private set; } = "The request was rejected because the final destination country of the goods does not match the requesting country.";
        public string Reason { get; private set; } = "BusinessRule";
        public List<ErrorDetail>? Details { get; set; }

        public FinalDestCountryNotMatchingRequestingCountryException()
        {
            ErrorCode = 422;
        }

        public FinalDestCountryNotMatchingRequestingCountryException(List<ErrorDetail>? errorDetails)
        {
            ErrorCode = 422;
            Details = errorDetails;
        }

        protected FinalDestCountryNotMatchingRequestingCountryException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }
    }
}