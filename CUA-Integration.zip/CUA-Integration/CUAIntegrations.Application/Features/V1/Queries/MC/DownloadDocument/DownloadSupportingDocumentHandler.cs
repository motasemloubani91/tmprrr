﻿using CUA_GCC_Integration.Core.Exceptions.DataNotFound;
using CUA_GCC_Integration.Core.Helpers;
using CUAIntegrations.Application.Features.V1.Queries.CUA.DownloadDocument;
using CUAIntegrations.Application.Features.V1.Queries.Mc.DownloadDocument;
using CUAIntegrations.Application.Services.Http;
using CUAIntegrations.Kernel.Core.Configurations;
using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;
using CUAIntegrations.Repository.Base;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using System.Net;

namespace CUAIntegrations.Application.Features.V1.Queries.OutBoundedForMC.DownloadDocument
{
    public class DownloadSupportingDocumentHandler
        : IRequestHandler<DownloadSupportingDocumentQuery, DownloadSupportingDocumentResponse>
    {
        private readonly ICUAClient _restClient;
        private readonly IBaseConfiguration _baseConfiguration;
        private readonly ICUAIntegrationUnitOfWork _unitOfWork;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly string _dataEntityTypeId = 3.ToString(); // SupportingDocument type

        public DownloadSupportingDocumentHandler(
            ICUAClient restClient,
            IBaseConfiguration baseConfiguration,
            ICUAIntegrationUnitOfWork unitOfWork,
            IHttpContextAccessor httpContextAccessor)
        {
            _restClient = restClient;
            _baseConfiguration = baseConfiguration;
            _unitOfWork = unitOfWork;
            _httpContextAccessor = httpContextAccessor;
        }

        public async Task<DownloadSupportingDocumentResponse> Handle(
            DownloadSupportingDocumentQuery request,
            CancellationToken cancellationToken)
        {
            long? mcLogId = _httpContextAccessor.HttpContext.Request.Headers.TryGetValue(RequestHeadersConstants.X_LOGGING_ID, out var mainHeaderValue)
                && long.TryParse(mainHeaderValue, out var parsedMain)
                ? parsedMain
                : null;

            var url =
                $"{_baseConfiguration.SupportingDocumentsUrl.TrimEnd('/')}/" +
                $"{request.DeclarationNumber}/{request.IssuingCountryCode}/{request.DocumentId}";

            var queryParams = new List<string>();
            if (!string.IsNullOrWhiteSpace(request.DeclarationType))
                queryParams.Add($"declarationType={request.DeclarationType}");
            if (!string.IsNullOrWhiteSpace(request.Year))
                queryParams.Add($"year={request.Year}");
            if (!string.IsNullOrWhiteSpace(request.Port))
                queryParams.Add($"port={request.Port}");
            if (queryParams.Any())
                url += "?" + string.Join("&", queryParams);

            var apiResponse = await _restClient.GetAsync<CUADownloadDocumentResponse>(url);

            var cuaLogId = apiResponse.RequestLogId;

            if (apiResponse == null || !apiResponse.Succeeded || apiResponse.Data?.SupportingDocumentDetailsEntity == null)
            {
                throw new NoDocumentFoundException();

            }

            var responseDto = apiResponse.Data.SupportingDocumentDetailsEntity;

            var NewEntity = new McSupportingDocumentDetailsDto();

            

               ///////////////////////////////
            var documentCategory = await _unitOfWork.DocumentTypesLookupRepository.Get()
                .Where(d => d.Code == responseDto.DocumentCategory)
                .OrderByDescending(a => a.Id)
                .Select(a => (long?)a.Id)
                .FirstOrDefaultAsync(cancellationToken);
            if (documentCategory == null)
                throw new DueNumberNotFoundException(
                    "The response was rejected because DocumentCategory lookup does not match the reference list.",
                    "ERR09");

            NewEntity.DocumentCategory = documentCategory.Value.ToString();
            ///////////////////////////////
            var DocumentLanguage = await _unitOfWork.LanguageCodesLookupRepository.Get()
                .Where(d => d.Code == responseDto.DocumentLanguage)
                .OrderByDescending(a => a.Id)
                .Select(a => (long?)a.Id)
                .FirstOrDefaultAsync(cancellationToken);
            if (DocumentLanguage == null)
                throw new DueNumberNotFoundException(
                    "The response was rejected because DocumentLanguage lookup does not match the reference list.",
                    "ERR09");

            NewEntity.DocumentCategory = documentCategory.Value.ToString();
            ///////////////////////////////
            NewEntity.RelatedDeclarationNumber = responseDto.RelatedDeclarationNumber;
            //NewEntity.DocumentCategory = responseDto.DocumentCategory;
            NewEntity.DocumentName = responseDto.DocumentName;
            NewEntity.DocumentIdNumber = responseDto.DocumentIdNumber;
            //NewEntity.DocumentLanguage = responseDto.DocumentLanguage;
            NewEntity.DocumentContent = responseDto.DocumentContent;


            return new DownloadSupportingDocumentResponse
            {
                SupportingDocumentDetailsEntity = NewEntity
            };
        }
    }
}
