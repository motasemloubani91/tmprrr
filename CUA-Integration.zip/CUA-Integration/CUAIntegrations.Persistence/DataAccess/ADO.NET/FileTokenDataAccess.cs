﻿using CUAIntegrations.Kernel.Core.InstanseScopeTypes;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace CUAIntegrations.Persistence.DataAccess.ADO.NET
{
    public class FileTokenDataAccess : IScoped, IFileTokenDataAccess
    {
        private readonly string _connectionString;

        public FileTokenDataAccess(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection")
                             ?? throw new InvalidOperationException("NoConnection String");
        }

        public string[] GetTokenForDownload(
            int iDocumentId,
            int iReferenceId,
            string sSaltKey,
            int iOwnerOrgId,
            int iOwnerLocId)
        {
            string[] arrTokenAndSession = new string[2];
            string sDocumentid = iDocumentId.ToString();

            string sReferenceProfile = "Declaration";
            ////string sCreatedby = "CDAPI.User";
            string sCreatedby = "AValidUserId";
            string sTokensalt = sSaltKey;
            string sTokenval_Out = "";
            string sSessionId_Out = "";

            using (SqlConnection objConn = new SqlConnection(_connectionString))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    try
                    {
                        cmd.CommandText = @"[dbo].[USP_InsertintoMcDocDownloadTokenAPI]";
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        cmd.Connection = objConn;

                        SqlParameter[] cmdParamOut = new SqlParameter[2];
                        cmdParamOut[0] = new SqlParameter();
                        cmdParamOut[0].SqlDbType = System.Data.SqlDbType.VarChar;
                        cmdParamOut[0].Size = 200;
                        cmdParamOut[0].ParameterName = "@tokenval";
                        cmdParamOut[1] = new SqlParameter();
                        cmdParamOut[1].ParameterName = "@SessionId";
                        cmdParamOut[1].SqlDbType = System.Data.SqlDbType.VarChar;
                        cmdParamOut[1].Size = 200;
                        cmdParamOut[0].Direction = System.Data.ParameterDirection.Output;
                        cmdParamOut[1].Direction = System.Data.ParameterDirection.Output;

                        SqlParameter[] cmdParamIn = new SqlParameter[7];
                        cmdParamIn[0] = new SqlParameter();
                        cmdParamIn[0].ParameterName = "@referenceid";
                        cmdParamIn[0].Value = iReferenceId;
                        cmdParamIn[1] = new SqlParameter();
                        cmdParamIn[1].ParameterName = "@referenceProfile";
                        cmdParamIn[1].Value = sReferenceProfile;
                        cmdParamIn[2] = new SqlParameter();
                        cmdParamIn[2].ParameterName = "@createdby";
                        cmdParamIn[2].Value = sCreatedby;
                        cmdParamIn[3] = new SqlParameter();
                        cmdParamIn[3].ParameterName = "@Tokensalt";
                        cmdParamIn[3].Value = sTokensalt;
                        cmdParamIn[4] = new SqlParameter();
                        cmdParamIn[4].ParameterName = "@documentid";
                        cmdParamIn[4].Value = sDocumentid;

                        cmdParamIn[5] = new SqlParameter();
                        cmdParamIn[5].DbType = System.Data.DbType.Int32;
                        cmdParamIn[5].ParameterName = "@ownerlocid";
                        cmdParamIn[5].Value = iOwnerLocId;
                        cmdParamIn[6] = new SqlParameter();
                        cmdParamIn[6].DbType = System.Data.DbType.Int32;
                        cmdParamIn[6].ParameterName = "@ownerorgid";
                        cmdParamIn[6].Value = iOwnerOrgId;

                        cmd.Parameters.AddRange(cmdParamIn);
                        cmd.Parameters.AddRange(cmdParamOut);

                        objConn.Open();
                        cmd.ExecuteNonQuery();
                        sTokenval_Out = cmd.Parameters["@tokenval"].Value.ToString();
                        sSessionId_Out = cmd.Parameters["@SessionId"].Value.ToString();

                        arrTokenAndSession[0] = sTokenval_Out;
                        arrTokenAndSession[1] = sSessionId_Out;
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.ToString());
                    }
                    finally
                    {
                        if (objConn.State == System.Data.ConnectionState.Open)
                            objConn.Close();
                    }
                }
            }

            return arrTokenAndSession;
        }
    }
}
