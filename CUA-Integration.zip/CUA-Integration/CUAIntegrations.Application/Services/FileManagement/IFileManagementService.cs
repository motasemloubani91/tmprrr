﻿namespace CUAIntegrations.Application.Services.FileManagement
{
    public interface IFileManagementService
    {
        Task<byte[]> DownloadDocumentFile(
            int documentId, 
            int declarationId);
    }
}