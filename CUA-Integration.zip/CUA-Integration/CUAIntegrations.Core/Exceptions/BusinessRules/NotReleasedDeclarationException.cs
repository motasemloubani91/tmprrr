using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;

namespace CUA_GCC_Integration.Core.Exceptions.BusinessRules
{
    public class NotReleasedDeclarationException : Exception
    {
        public int ErrorCode { get; private set; } //mapped to Status property in ErrorResponse
        public string Message { get; private set; } = "The request was rejected because the customs declaration has not yet been finalized and released.";
        public string Reason { get; private set; } = "BusinessRule";
        public List<ErrorDetail>? Details { get; set; }

        public NotReleasedDeclarationException()
        {
            ErrorCode = 422;
        }

        public NotReleasedDeclarationException(List<ErrorDetail>? errorDetails)
        {
            ErrorCode = 422;
            Details = errorDetails;
        }

        protected NotReleasedDeclarationException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }
    }
}