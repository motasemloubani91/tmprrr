﻿namespace CUAIntegrations.Kernel.Domain.Entities.CustomsDeclarationsEntities
{
    public class Restrictions
    {
        public long Id { get; set; }
        public long ItemId { get; set; }
        public string Agency { get; set; } 
        public string? ReleaseRef { get; set; }
    }
}
