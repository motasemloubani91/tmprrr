﻿using CUAIntegrations.Application.Features.V1.Queries.OutBoundedForMC.CustomsDeclarations;
using CUAIntegrations.Kernel.Core.Wrappers;

namespace CUAIntegrations.Application.Helpers
{
    public static class MockDataHelper
    {
        public static Response<GetCUACustomsDeclarationResponse> GetCustomsDeclarationMock()
        {
            var mockData = new GetCUACustomsDeclarationResponse
            {
                ErrorResponse = null,
                CustomsDeclarationEntity = new CUACustomsDeclarationsDto
                {
                    DeclarationNumber = "5SE60036066033",
                    DeclarationDate = DateTime.ParseExact("20250905104530", "yyyyMMddHHmmss", null),
                    DeclarationType = "01",
                    PortType = "01",
                    DeliveryOrderNumber = "DO-SEA-2025-000123",
                    ImporterExporterName = "Gulf Trading Co.",
                    ImporterExporterCustomsId = "QACUST-00123456789",
                    NetWeight = 12000m,
                    CarrierCaptainDriver = "'MV Al Wakrah ,Captain Ahmad Saleh'",
                    IntercessorCompany = "Qatar Shipping Agency (QSA-778899)",
                    GrossWeight = 13050m,
                    CarrierName = "Qatar National Shipping Lines, BlueSky Air Cargo",
                    CommercialRegistrationNumber = "CR-1234567890",
                    TinNumber = "TIN-QA-987654321",
                    Measurement = "KGM",
                    VoyageFlightNumber = "VOY-SEA-00987,QR-248",
                    ExportedTo = "GCC Distribution LLC",
                    NumberOfPackages = 250,
                    BlAwbManifestNo = "BOL-SEA-2025-556677",
                    PortOfLoading = "Hamad Port",
                    MarksAndNumbers = "GTCO/2025/PKG/0001-0250,REF: HSC-8471300000",
                    PortOfDischarge = "Jebel Ali Port",
                    DestinationCountryCode = "AE",
                    Items = new List<CUAItemsDto>
                    {
                        new CUAItemsDto
                        {
                            HsCode = "847130000000",
                            GoodsDescription = "Portable automatic data processing machines (laptops)",
                            OriginCountryCode = "CN",
                            CifForeignValue = 250000m,
                            Currency = new CUACurrenciesDto { Type = "USD", Value = 6m },
                            CifLocalValue = 910000m,
                            DutyRate = "5",
                            IncomeType = "Standard",
                            TotalDuty = 45500m,
                            Packages = new CUAPackagesDto { Quantity = 200, Type = "CT" },
                            Item = new CUAItemDetailsDto { Quantity = 1200m, Unit = "PCE" },
                            NetWeight = 8000m,
                            GrossWeight = 8600m,
                            AIP = new CUAAIPsDto { GazetteNumber = "AIP-GAZ-2024-Vol12", Duty = 0m },
                            Restrictions = new List<CUARestrictionsDto>
                            {
                                new CUARestrictionsDto { Agency = "Telecom Regulator", ReleaseRef = "TR-PERMIT-2025-445566" }
                            },
                            ExemptionApprovalRef = "EXEM-IT-2025-000111"
                        }
                    },
                    RiskOutcome = "GREEN",
                    ValuationMethod = "A",
                    OtherRemarks = "Documents verified; green channel.",
                    ReleaseDate = DateTime.ParseExact("20250905104530", "yyyyMMddHHmmss", null),
                    Route = "CN → QA → AE",
                    ExitPort = "Hamad Port – Export Gate",
                    TotalDuty = 54600m,
                    Vat = 0m,
                    ExciseTax = 0m,
                    OtherCharges = 1250m,
                    DueNumber = "48485453684646564848545368464656484854536846465648485453684646533",
                    UnifiedCustomsCode = "UCC-GCC-2025-01",
                    DefiniteFee = 55850m,
                    Insured = 3000m,
                    Payments = new List<CUAPaymentsDto>
                    {
                        new CUAPaymentsDto
                        {
                            Method = "B",
                            No = "QNB-2025-INV-000998",
                            Date = DateTime.ParseExact("20250905104530", "yyyyMMddHHmmss", null),
                            Bank = "Qatar National Bank"
                        },
                        new CUAPaymentsDto
                        {
                            Method = "H",
                            No = "TRF-2025-001122",
                            Date = DateTime.ParseExact("20250905104530", "yyyyMMddHHmmss", null),
                            Bank = "Doha Bank"
                        }
                    }
                }
            };

            return new Response<GetCUACustomsDeclarationResponse>
            {
                Data = mockData,
                Succeeded = true,
                Message = "Mock data returned successfully"
            };
        }
    }
}
