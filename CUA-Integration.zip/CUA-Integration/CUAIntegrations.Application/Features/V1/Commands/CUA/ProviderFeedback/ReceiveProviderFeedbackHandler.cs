﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;
using CUAIntegrations.Kernel.Domain.Entities.ProviderFeedbackEntities;
using CUAIntegrations.Repository.Base;
using MediatR;
using System.Net;
using System.Text.Json;

namespace CUAIntegrations.Application.Features.V1.Commands.CUA.ProviderFeedback
{
    public class ReceiveProviderFeedbackHandler : IRequestHandler<ReceiveProviderFeedbackCommand, ReceiveProviderFeedbackResponse>
    {
        private readonly ICUAIntegrationUnitOfWork _unitOfWork;

        public ReceiveProviderFeedbackHandler(
            ICUAIntegrationUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<ReceiveProviderFeedbackResponse> Handle(ReceiveProviderFeedbackCommand request, CancellationToken cancellationToken)
        {
            var response = new ReceiveProviderFeedbackResponse();

            // Validate payload
            if (request.Feedback == null ||
                string.IsNullOrWhiteSpace(request.Feedback.FeedbackId) ||
                string.IsNullOrWhiteSpace(request.Feedback.OriginalRequestId) ||
                string.IsNullOrWhiteSpace(request.Feedback.ApiEndpoint))
            {
                response.ErrorResponse = new ErrorResponse
                {
                    Status = (int)HttpStatusCode.BadRequest,
                    Reason = "ValidationError",
                    Message = "Missing required fields: feedbackId, originalRequestId, or apiEndpoint."
                };
                return response;
            }

            // Create feedback entity
            var entity = new ProviderFeedbackEntity
            {
                Id=0,
                FeedbackId = request.Feedback.FeedbackId,
                OriginalRequestId = request.Feedback.OriginalRequestId,
                ApiEndpoint = request.Feedback.ApiEndpoint,
                ErrorResponseJson = JsonSerializer.Serialize(request.Feedback.ErrorResponse, new JsonSerializerOptions { WriteIndented = false }),
                CreatedOn = DateTime.UtcNow
            };

            // Save to DB
            await _unitOfWork.ProviderFeedbackRepository.AddAsync(entity);
            await _unitOfWork.CommitAsync();

            // Return success response
            response.Acknowledged = true;
            response.FeedbackId = request.Feedback.FeedbackId;
            response.Message = $"Provider feedback logged successfully with ID: {entity.Id}";

            return response;
        }
    }
}
