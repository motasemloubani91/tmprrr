﻿namespace CUAIntegrations.Kernel.Domain.Entities.AuthenticationsEntities
{
    public class IntegrationsAuthentication
    {
        public int Id { get; set; }
        public string Client { get; set; }
        public string Code { get; set; }
        public string? Scope { get; set; }
        public string? AccessToken { get; set; }
        public string? RefreshToken { get; set; }
        public DateTime? AccessTokenExpiresAt { get; set; }
        public DateTime? CreatedAt { get; set; }
        public DateTime? LastUpdateAt { get; set; }


        public IntegrationsAuthentication()
        {

        }

        public IntegrationsAuthentication(
            string? code,
            string? scope,
            string? accessToken,
            string? refreshToken,
            DateTime? accessTokenExpiresAt)
        {
            Client = "CUA";
            Code = code;
            Scope = scope;
            AccessToken = accessToken;
            RefreshToken = refreshToken;
            AccessTokenExpiresAt = accessTokenExpiresAt;
        }

        public static IntegrationsAuthentication Create(
            string? code,
            string? scope,
            string? accessToken,
            string? refreshToken,
            DateTime? accessTokenExpiresAt)
        {
            return new IntegrationsAuthentication(
                code,
                scope,
                accessToken,
                refreshToken,
                accessTokenExpiresAt);
        }

        public void UpdateAccessToken(
            string? accessToken,
            DateTime? accessTokenExpiresAt,
            string? scope,
            string? refreshToken,
            string? code = null)
        {
            Code = code ?? Code;
            AccessToken = accessToken;
            AccessTokenExpiresAt = accessTokenExpiresAt;
            RefreshToken = refreshToken;
            Scope = scope;
        }
    }
}
