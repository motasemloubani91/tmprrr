﻿using CUA_GCC_Integration.Core.Exceptions.DataNotFound;
using CUA_GCC_Integration.Core.Helpers;
using CUAIntegrations.Persistence.DataAccess.ADO.NET;
using MediatR;
using Microsoft.AspNetCore.Http;

namespace CUAIntegrations.Application.Features.V1.Queries.CUA.SupportingDocumentsList
{
    public class SupportingDocumentsListQueryHandler
        : IRequestHandler<GetCUASupportingDocumentsListQuery, SupportingDocumentsListResponse>
    {

        private readonly ICUADataAccessDataAccess _dataAccessService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public SupportingDocumentsListQueryHandler(ICUADataAccessDataAccess dataAccessService, IHttpContextAccessor httpContextAccessor = null)
        {
            _dataAccessService = dataAccessService;
            _httpContextAccessor = httpContextAccessor;
        }

        public async Task<SupportingDocumentsListResponse> Handle(GetCUASupportingDocumentsListQuery request, CancellationToken cancellationToken)
        {
            var response = new SupportingDocumentsListResponse()
            {
                SupportingDocumentListEntity = new SupportingDocumentsListDTO
                {
                    RelatedDeclarationNumber = request.DeclarationNumber
                }
            };

            var requestingCountryCode = _httpContextAccessor.HttpContext.Request.Headers[RequestHeadersConstants.X_Client_ID].ToString();

            var issuingCountryCode = ApplicationClientsConstants.Kuwait;
            var declarationId = await _dataAccessService.GetDeclarationIdAsync(
                request.DeclarationNumber,
                request.DeclarationType,
                request.Year,
                request.Port,
                issuingCountryCode,
                requestingCountryCode
            );

            if (string.IsNullOrWhiteSpace(declarationId))
                throw new DeclarationNotFoundException();
            //var declarationId = "14190986"; //for test only 
            var documentsResult = await _dataAccessService.GetSupportedDocumentListAsync(request.DeclarationNumber);

            var mappedDocuments = new List<GetSupportingDocumentDTO>();

            if (documentsResult?.Documents != null)
            {
                foreach (var doc in documentsResult.Documents)
                {
                    mappedDocuments.Add(new GetSupportingDocumentDTO
                    {
                        DocumentCategory = doc.DocumentCategory,
                        DocumentName = doc.DocumentName,
                        DocumentIdNumber = doc.DocumentIdNumber,
                        DocumentLanguage = doc.DocumentLanguage,
                        DocumentLink = doc.DocumentLink 
                    });
                }
            }

            response.SupportingDocumentListEntity.Documents = mappedDocuments;
            return response;
        }
    }
}
