﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;
using MediatR;

namespace CUAIntegrations.Application.Features.V1.Queries.CUA.SupportingDocumentsList

{
    public record GetCUASupportingDocumentsListQuery(
         string DeclarationNumber,
         string DeclarationType,
         string Year,
         string Port
    ) : IRequest<SupportingDocumentsListResponse>;


}

