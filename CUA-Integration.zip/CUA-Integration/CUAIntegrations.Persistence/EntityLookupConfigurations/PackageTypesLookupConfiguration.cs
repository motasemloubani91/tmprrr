﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using CUAIntegrations.Kernel.Domain.Entities.Lookups;

namespace CUAIntegrations.Persistence.EntityLookupConfigurations
{
    public class PackageTypesLookupConfiguration : IEntityTypeConfiguration<PackageTypesLookup>
    {
        public void Configure(EntityTypeBuilder<PackageTypesLookup> entity)
        {
            entity.ToTable("GCC_PackageTypesLookup", "GCC");
            entity.HasKey(e => e.Id);

            entity.Property(e => e.Code).HasMaxLength(255);
            entity.Property(e => e.AdditionalArabicDescription).HasMaxLength(255);
            entity.Property(e => e.AdditionalEnglishDescription).HasMaxLength(255);
            entity.Property(e => e.EnglishCategory).HasMaxLength(255);
            entity.Property(e => e.ArabicCategory).HasMaxLength(255);
            entity.Property(e => e.ArabicName).HasMaxLength(255);
            entity.Property(e => e.EnglishName).HasMaxLength(255);
            
        }
    }
}
