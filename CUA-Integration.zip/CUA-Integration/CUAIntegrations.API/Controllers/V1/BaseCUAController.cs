﻿using CUAIntegrations.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CUAIntegrations.Controllers.V1
{
    //[AllowAnonymous]
    [Authorize(AuthenticationSchemes = Constants.AuthenticationScheme.Basic)]
    [ApiVersion("1")]
    [Route("/v{version:apiVersion}/[controller]")]
    [ApiController]
    public class BaseCUAController : ControllerBase
    {
    }
}
