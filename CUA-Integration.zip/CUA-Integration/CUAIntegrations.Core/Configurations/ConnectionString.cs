﻿namespace CUAIntegrations.Kernel.Core.Configurations
{
    public class ConnectionString
    {
        public string DefaultConnection { get; set; }
        public string HangfireConnection { get; set; }
        public string RedisServerConnection { get; set; }
    }
}
