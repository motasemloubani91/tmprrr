﻿namespace CUAIntegrations.Kernel.Core.Domain.BaseEntities
{
    public interface IAuditableEntity
    {
        int CreatedById { get; set; }
        DateTime CreatedAt { get; set; }
        int? LastModifiedById { get; set; }
        DateTime? LastModifiedAt { get; set; }
        int? DeactivatedById { get; set; }
        public DateTime? DeactivatedAt { get; set; }
        bool IsActive { get; set; }


        void EntityCreated(int userId, DateTime creationTime);
        void EntityUpdated(int userId, DateTime dateTime, bool isActivated);
        void EntityDeactivated(int userId, DateTime dateTime);
        void Activate();
        void DeActivate();
    }
}
