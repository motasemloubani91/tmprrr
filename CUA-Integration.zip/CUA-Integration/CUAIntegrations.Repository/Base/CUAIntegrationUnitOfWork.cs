﻿using CUAIntegrations.Kernal.Domain.Entities.LoggingEntities;
using CUAIntegrations.Kernel.Core.Persistence;
using CUAIntegrations.Kernel.Domain.Entities.AuthenticationsEntities;
using CUAIntegrations.Kernel.Domain.Entities.CustomsDeclarationsEntities;
using CUAIntegrations.Kernel.Domain.Entities.DueNumbers;
using CUAIntegrations.Kernel.Domain.Entities.LoggingEntities;
using CUAIntegrations.Kernel.Domain.Entities.Lookups;
using CUAIntegrations.Kernel.Domain.Entities.ProviderFeedbackEntities;
using CUAIntegrations.Kernel.Domain.Entities.TransferReceipts;
using CUAIntegrations.Persistence.DataAccess.Context;
using Microsoft.EntityFrameworkCore;

namespace CUAIntegrations.Repository.Base
{
    public class CUAIntegrationUnitOfWork : ICUAIntegrationUnitOfWork
    {
        public CUAIntegrationDbContext Context { get; }


        private CUAIntegrationsRepository<IntegrationsAuthentication> _IntegrationsAuthenticationRepository;
        private CUAIntegrationsRepository<AIPs> _AIPsRepository;
        private CUAIntegrationsRepository<Currencies> _CurrenciesRepository;
        private CUAIntegrationsRepository<CustomsDeclarationsEntities> _CustomsDeclarationsEntitiesRepository;
        private CUAIntegrationsRepository<ItemDetails> _ItemDetailsRepository;
        private CUAIntegrationsRepository<Items> _ItemsRepository;
        private CUAIntegrationsRepository<Packages> _PackagesRepository;
        private CUAIntegrationsRepository<Payments> _PaymentsRepository;
        private CUAIntegrationsRepository<Restrictions> _RestrictionsRepository;
        private CUAIntegrationsRepository<DueNumber> _DueNumberRepository;
        private CUAIntegrationsRepository<TransferReceipt> _TransferReceiptRepository;
        private CUAIntegrationsRepository<TransferReceiptListOfDues> _TransferReceiptListOfDuesRepository;
        private CUAIntegrationsRepository<ProviderFeedbackEntity> _ProviderFeedbackRepository;
        private CUAIntegrationsRepository<RequestLogging> _RequestLoggingRepository;
        private CUAIntegrationsRepository<ResponseLogging> _ResponseLoggingRepository;
        private CUAIntegrationsRepository<GCCLogging> _GCCExceptionLoggingRepository;

        private CUAIntegrationsRepository<CountryCodesLookup> _CountryCodesLookupRepository;
        private CUAIntegrationsRepository<CurrencyCodesLookup> _CurrencyCodesLookupRepository;
        private CUAIntegrationsRepository<CustomsDataTypesLookup> _CustomsDataTypesLookupRepository;
        private CUAIntegrationsRepository<CustomsPortTypesLookup> _CustomsPortTypesLookupRepository;
        private CUAIntegrationsRepository<DocumentTypesLookup> _DocumentTypesLookupRepository;
        private CUAIntegrationsRepository<DueNumberStatusesLookup> _DueNumberStatusesLookupRepository;
        private CUAIntegrationsRepository<LanguageCodesLookup> _LanguageCodesLookupRepository;
        private CUAIntegrationsRepository<PackageTypesLookup> _PackageTypesLookupRepository;
        private CUAIntegrationsRepository<PaymentMethodsLookup> _PaymentMethodsLookupRepository;
        private CUAIntegrationsRepository<PortCodesLookup> _PortCodesLookupRepository;
        private CUAIntegrationsRepository<RiskResultsLookup> _RiskResultsLookupRepository;
        private CUAIntegrationsRepository<UnitCodesLookup> _UnitCodesLookupRepository;
        private CUAIntegrationsRepository<ValuationMethodsLookup> _ValuationMethodsLookupRepository;

        private bool disposed = false;


        public IRepository<AIPs> AIPsRepository => _AIPsRepository ?? (_AIPsRepository = new CUAIntegrationsRepository<AIPs>(Context));
        public IRepository<IntegrationsAuthentication> IntegrationsAuthenticationRepository => _IntegrationsAuthenticationRepository ?? (_IntegrationsAuthenticationRepository = new CUAIntegrationsRepository<IntegrationsAuthentication>(Context));
        public IRepository<Currencies> CurrenciesRepository => _CurrenciesRepository ?? (_CurrenciesRepository = new CUAIntegrationsRepository<Currencies>(Context));
        public IRepository<CustomsDeclarationsEntities> CustomsDeclarationsEntitiesRepository => _CustomsDeclarationsEntitiesRepository ?? (_CustomsDeclarationsEntitiesRepository = new CUAIntegrationsRepository<CustomsDeclarationsEntities>(Context));
        public IRepository<ItemDetails> ItemDetailsRepository => _ItemDetailsRepository ?? (_ItemDetailsRepository = new CUAIntegrationsRepository<ItemDetails>(Context));
        public IRepository<Items> ItemsRepository => _ItemsRepository ?? (_ItemsRepository = new CUAIntegrationsRepository<Items>(Context));
        public IRepository<Packages> PackagesRepository => _PackagesRepository ?? (_PackagesRepository = new CUAIntegrationsRepository<Packages>(Context));
        public IRepository<Payments> PaymentsRepository => _PaymentsRepository ?? (_PaymentsRepository = new CUAIntegrationsRepository<Payments>(Context));
        public IRepository<Restrictions> RestrictionsRepository => _RestrictionsRepository ?? (_RestrictionsRepository = new CUAIntegrationsRepository<Restrictions>(Context));
        public IRepository<DueNumber> DueNumberRepository => _DueNumberRepository ?? (_DueNumberRepository = new CUAIntegrationsRepository<DueNumber>(Context));
        public IRepository<TransferReceipt> TransferReceiptRepository => _TransferReceiptRepository ?? (_TransferReceiptRepository = new CUAIntegrationsRepository<TransferReceipt>(Context));
        public IRepository<TransferReceiptListOfDues> TransferReceiptListOfDuesRepository => _TransferReceiptListOfDuesRepository ?? (_TransferReceiptListOfDuesRepository = new CUAIntegrationsRepository<TransferReceiptListOfDues>(Context));
        public IRepository<ProviderFeedbackEntity> ProviderFeedbackRepository => _ProviderFeedbackRepository ?? (_ProviderFeedbackRepository = new CUAIntegrationsRepository<ProviderFeedbackEntity>(Context));
        public IRepository<RequestLogging> RequestLoggingRepository => _RequestLoggingRepository ?? (_RequestLoggingRepository = new CUAIntegrationsRepository<RequestLogging>(Context));
        public IRepository<ResponseLogging> ResponseLoggingRepository => _ResponseLoggingRepository ?? (_ResponseLoggingRepository = new CUAIntegrationsRepository<ResponseLogging>(Context));
        public IRepository<GCCLogging> GCCExceptionLoggingRepository => _GCCExceptionLoggingRepository ?? (_GCCExceptionLoggingRepository = new CUAIntegrationsRepository<GCCLogging>(Context));
       
        public IRepository<CountryCodesLookup> CountryCodesLookupRepository => _CountryCodesLookupRepository ?? (_CountryCodesLookupRepository = new CUAIntegrationsRepository<CountryCodesLookup>(Context));
        public IRepository<CurrencyCodesLookup> CurrencyCodesLookupRepository => _CurrencyCodesLookupRepository ?? (_CurrencyCodesLookupRepository = new CUAIntegrationsRepository<CurrencyCodesLookup>(Context));
        public IRepository<CustomsDataTypesLookup> CustomsDataTypesLookupRepository => _CustomsDataTypesLookupRepository ?? (_CustomsDataTypesLookupRepository = new CUAIntegrationsRepository<CustomsDataTypesLookup>(Context));
        public IRepository<CustomsPortTypesLookup> CustomsPortTypesLookupRepository => _CustomsPortTypesLookupRepository ?? (_CustomsPortTypesLookupRepository = new CUAIntegrationsRepository<CustomsPortTypesLookup>(Context));
        public IRepository<DocumentTypesLookup> DocumentTypesLookupRepository => _DocumentTypesLookupRepository ?? (_DocumentTypesLookupRepository = new CUAIntegrationsRepository<DocumentTypesLookup>(Context));
        public IRepository<DueNumberStatusesLookup> DueNumberStatusesLookupRepository => _DueNumberStatusesLookupRepository ?? (_DueNumberStatusesLookupRepository = new CUAIntegrationsRepository<DueNumberStatusesLookup>(Context));
        public IRepository<LanguageCodesLookup> LanguageCodesLookupRepository => _LanguageCodesLookupRepository ?? (_LanguageCodesLookupRepository = new CUAIntegrationsRepository<LanguageCodesLookup>(Context));
        public IRepository<PackageTypesLookup> PackageTypesLookupRepository => _PackageTypesLookupRepository ?? (_PackageTypesLookupRepository = new CUAIntegrationsRepository<PackageTypesLookup>(Context));
        public IRepository<PaymentMethodsLookup> PaymentMethodsLookupRepository => _PaymentMethodsLookupRepository ?? (_PaymentMethodsLookupRepository = new CUAIntegrationsRepository<PaymentMethodsLookup>(Context));
        public IRepository<PortCodesLookup> PortCodesLookupRepository => _PortCodesLookupRepository ?? (_PortCodesLookupRepository = new CUAIntegrationsRepository<PortCodesLookup>(Context));
        public IRepository<RiskResultsLookup> RiskResultsLookupRepository => _RiskResultsLookupRepository ?? (_RiskResultsLookupRepository = new CUAIntegrationsRepository<RiskResultsLookup>(Context));
        public IRepository<UnitCodesLookup> UnitCodesLookupRepository => _UnitCodesLookupRepository ?? (_UnitCodesLookupRepository = new CUAIntegrationsRepository<UnitCodesLookup>(Context));
        public IRepository<ValuationMethodsLookup> ValuationMethodsLookupRepository => _ValuationMethodsLookupRepository ?? (_ValuationMethodsLookupRepository = new CUAIntegrationsRepository<ValuationMethodsLookup>(Context));


        public CUAIntegrationUnitOfWork(CUAIntegrationDbContext context)
        {
            Context = context;
            Context.ChangeTracker.LazyLoadingEnabled = false;
        }

        public bool Commit()
        {
            var result = Context.SaveChanges();
            if (result > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public async Task<bool> CommitAsync()
        {
            var result = await Context.SaveChangesAsync();
            if (result > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void RollBack()
        {
            foreach (var entry in Context.ChangeTracker.Entries()
                  .Where(e => e.State != EntityState.Unchanged))
            {
                switch (entry.State)
                {
                    case EntityState.Added:
                        entry.State = EntityState.Detached;
                        break;
                    case EntityState.Modified:
                    case EntityState.Deleted:
                        entry.Reload();
                        break;
                }
            }
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    Context.Dispose();
                }
            }
            disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        public void DeAttach()
        {
            foreach (var entry in Context.ChangeTracker.Entries()
                  .Where(e => e.State != EntityState.Unchanged))
            {
                entry.State = EntityState.Detached;

            }
        }
    }
}
