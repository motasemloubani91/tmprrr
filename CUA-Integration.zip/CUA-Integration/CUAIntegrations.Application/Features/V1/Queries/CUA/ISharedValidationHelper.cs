﻿namespace CUAIntegrations.Application.Features.V1.Queries.CUA
{
    public interface ISharedValidationHelper
    {
        bool IsValidDeclarationYear(string year);
        Task<bool> IsValidPortCode(string portCode);
        Task<bool> IsValidCountryCode(string CountryCode);

    }
}
