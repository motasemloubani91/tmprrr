﻿namespace CUAIntegrations.Persistence.DataAccess.ADO.NET.Models
{
    public class CUATransferReceiptModel
    {
        public string FileName { get; set; }
        public string Image { get; set; }
        public DateTime FileDate { get; set; }
        public decimal Amount { get; set; }
        public List<string> ListOfDues { get; set; }
    }
}
