﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;

namespace CUA_GCC_Integration.Core.Exceptions.ResponseValidation
{
    public class InvalidLookupException : Exception
    {
        public int ErrorCode { get; private set; } //mapped to Status property in ErrorResponse
        public string Message { get; private set; } = "The response was rejectedbecause it contains a lookup that does not match thereference list. ";
        public string Reason { get; private set; } = "ValidationError";
        public List<ErrorDetail>? Details { get; set; }

        public InvalidLookupException()
        {
            ErrorCode = 400;
        }
        public InvalidLookupException(List<ErrorDetail>? errorDetails)
        {
            ErrorCode = 400;
            Details = errorDetails;
        }

        protected InvalidLookupException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }
    }

}
