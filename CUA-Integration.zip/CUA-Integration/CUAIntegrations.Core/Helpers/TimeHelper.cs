﻿using CUAIntegrations.Kernel.Core.InstanseScopeTypes;

namespace CUA_GCC_Integration.Core.Helpers
{
    public interface ITimeHelper
    {
        DateTime GetUTCTime();
        DateTime GetCurrentTime();
    }

    public class TimeHelper : IScoped, ITimeHelper
    {
        public DateTime GetUTCTime()
        {
            return DateTime.UtcNow;
        }

        public DateTime GetCurrentTime()
        {
            return DateTime.Now;
        }
    }
}
