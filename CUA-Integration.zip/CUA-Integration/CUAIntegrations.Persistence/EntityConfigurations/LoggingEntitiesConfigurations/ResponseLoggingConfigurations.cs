﻿using CUAIntegrations.Kernel.Domain.Entities.LoggingEntities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace CUAIntegrations.Persistence.EntityConfigurations.LoggingEntitiesConfigurations
{
    internal class ResponseLoggingConfigurations : IEntityTypeConfiguration<ResponseLogging>
    {
        public void Configure(EntityTypeBuilder<ResponseLogging> entity)
        {
            entity.ToTable("GCC_ResponsesLogging", "GCC");
            entity.HasKey(e => e.Id);

            entity.Property(e => e.Id)
                  .ValueGeneratedOnAdd();

            entity.Property(e => e.RequestId).IsRequired();
            entity.Property(e => e.StatusCode);

            entity.Property(e => e.ResponseHeaders);
            entity.Property(e => e.ResponseBody);

            entity.Property(e => e.ResponseTime).IsRequired();
        }
    }
}
