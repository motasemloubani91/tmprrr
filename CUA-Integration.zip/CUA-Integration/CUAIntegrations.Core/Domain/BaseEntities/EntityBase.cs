﻿namespace CUAIntegrations.Kernel.Core.Domain.BaseEntities
{
    public class EntityBase<T>
    {
        public T Id { get; set; }
    }
}
