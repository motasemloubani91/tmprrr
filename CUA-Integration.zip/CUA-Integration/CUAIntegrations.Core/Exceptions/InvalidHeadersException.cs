﻿using CUA_GCC_Integration.Core.Exceptions;
using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;
using System.Net;

namespace CUAIntegrations.Kernel.Core.Exceptions
{
    public class InvalidHeadersException : SystemIntegrationException
    {
        const string message = "Invalid Headers.";
        const string reason = "Invalid Headers.";

        public InvalidHeadersException() :
            base(errorCode: HttpStatusCode.BadRequest,
                message: message,
                reason: reason)
        {
        }

        public InvalidHeadersException(
            string message = message,
            string reason = reason,
            List<ErrorDetail>? details = null) :
            base(errorCode: HttpStatusCode.BadRequest,
                message: message,
                reason: reason,
                details: details)
        {
        }
    }
}

