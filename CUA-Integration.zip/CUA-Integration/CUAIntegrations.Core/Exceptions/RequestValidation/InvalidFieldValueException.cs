﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;
using System.Net;

namespace CUA_GCC_Integration.Core.Exceptions.RequestValidation
{
    public class InvalidFieldValueException : SystemIntegrationException
    {
        const string message = "The request was rejected due to an invalid field value syntax.";
        const string reason = "Validation Error.";

        public InvalidFieldValueException() :
            base(errorCode: HttpStatusCode.BadRequest,
                message: message,
                reason: reason)
        {
        }

        public InvalidFieldValueException(
            string message = message,
            string reason = reason,
            List<ErrorDetail>? details = null) :
            base(errorCode: HttpStatusCode.BadRequest,
                message: message,
                reason: reason,
                details: details)
        {
        }
    }
}
