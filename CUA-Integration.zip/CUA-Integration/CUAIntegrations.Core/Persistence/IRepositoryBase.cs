﻿using System.Linq.Expressions;

namespace CUAIntegrations.Kernel.Core.Persistence
{
    /// <summary>
    /// Represents a base interface for generic repositories with basic read operations.
    /// </summary>
    /// <typeparam name="T">The type of entity the repository works with.</typeparam>
    public interface IRepositoryBase<T> where T : class
    {
        /// <summary>
        /// Retrieves all entities of type T from the repository.
        /// </summary>
        /// <returns>An IQueryable representing the collection of entities.</returns>
        IQueryable<T> Get(/*bool isActive = true*/);

        /// <summary>
        /// Retrieves entities of type T from the repository based on the specified predicate.
        /// </summary>
        /// <param name="predicate">A predicate to filter the entities.</param>
        /// <returns>An IQueryable representing the filtered collection of entities.</returns>
        IQueryable<T> Get(Expression<Func<T, bool>> predicate/*, bool isActive = true*/);
    }
}
