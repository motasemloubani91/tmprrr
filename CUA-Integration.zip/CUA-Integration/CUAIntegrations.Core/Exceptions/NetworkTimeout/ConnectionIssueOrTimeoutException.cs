﻿using CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse;

namespace CUA_GCC_Integration.Core.Exceptions.NetworkTimeout
{
    public class ConnectionIssueOrTimeoutException : Exception
    {
        public int ErrorCode { get; private set; } //mapped to Status property in ErrorResponse
        public string Message { get; private set; } = "The request was rejected because the Issuing Country Code is invalid";
        public string Reason { get; private set; } = "ValidationError";
        public List<ErrorDetail>? Details { get; set; }

        public ConnectionIssueOrTimeoutException()
        {
            ErrorCode = 504;
        }
        public ConnectionIssueOrTimeoutException(List<ErrorDetail>? errorDetails)
        {
            ErrorCode = 504;
            Details = errorDetails;
        }

        protected ConnectionIssueOrTimeoutException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }
    }


}
