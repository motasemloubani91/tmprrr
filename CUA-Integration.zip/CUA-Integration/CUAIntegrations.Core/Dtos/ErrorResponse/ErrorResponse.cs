﻿namespace CUAIntegrations.Kernel.Domain.Dtos.ErrorResponse
{

    public class ErrorResponse
    {
        public int Status { get; set; }
        public string Reason { get; set; }
        public string? Message { get; set; }
        public List<ErrorDetail>? Details { get; set; }
    }

    public class ErrorDetail
    {
        public string Location { get; set; }
        public string Message { get; set; }
        public string? Reason { get; set; }
        public string? InnerCode { get; set; }
        public string? Severity { get; set; }
    }
}


