﻿using CUA_GCC_Integration.Core.Helpers;
using Microsoft.OpenApi.Any;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace CUAIntegrations.Swagger
{
    public class AddHeaderParameters : IOperationFilter
    {
        public void Apply(OpenApiOperation operation, OperationFilterContext context)
        {
            if (operation.Parameters == null)
                operation.Parameters = new List<OpenApiParameter>();

            operation.Parameters.Add(new OpenApiParameter
            {
                Name = RequestHeadersConstants.X_CORRELATION_ID,
                In = ParameterLocation.Header,
                AllowEmptyValue = false,
                Required = true,
                Schema = new OpenApiSchema
                {
                    Type = "string",
                    Default = new OpenApiString(Guid.NewGuid().ToString())
                }
            });

            operation.Parameters.Add(new OpenApiParameter
            {
                Name = RequestHeadersConstants.X_REQUEST_ID,
                In = ParameterLocation.Header,
                AllowEmptyValue = false,
                Required = true,
                Schema = new OpenApiSchema
                {
                    Type = "string",
                    Default = new OpenApiString(Guid.NewGuid().ToString())
                }
            });

            operation.Parameters.Add(new OpenApiParameter
            {
                Name = RequestHeadersConstants.X_Client_ID,
                In = ParameterLocation.Header,
                AllowEmptyValue = false,
                Required = true,
                Schema = new OpenApiSchema
                {
                    Type = "string",
                    Default = new OpenApiString("QA")
                }
            });

            operation.Parameters.Add(new OpenApiParameter
            {
                Name = RequestHeadersConstants.X_Request_Timestamp,
                In = ParameterLocation.Header,
                AllowEmptyValue = false,
                Required = true,
                Schema = new OpenApiSchema
                {
                    Type = "string",
                    Default = new OpenApiString(DateTime.UtcNow.ToString())
                }
            });

            operation.Parameters.Add(new OpenApiParameter
            {
                Name = RequestHeadersConstants.X_AppKey,
                In = ParameterLocation.Header,
                AllowEmptyValue = false,
                Required = false,
                Schema = new OpenApiSchema
                {
                    Type = "string",
                    Default = new OpenApiString("a3f9b8d1c24e4f12b9a87e3d5f6a9c21")
                }
            });

            operation.Parameters.Add(new OpenApiParameter
            {
                Name = RequestHeadersConstants.X_SecretKey,
                In = ParameterLocation.Header,
                AllowEmptyValue = false,
                Required = false,
                Schema = new OpenApiSchema
                {
                    Type = "string",
                    Default = new OpenApiString("Q1x8K9mP0sN4R7aB2uT6yW3vZ8pH5jL0gX4qS9rE1fC7dU2wM8tB6nV3")
                }
            });
        }
    }
}
