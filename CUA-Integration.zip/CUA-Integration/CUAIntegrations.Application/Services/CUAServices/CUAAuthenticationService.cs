﻿using CUA_GCC_Integration.Core.Helpers;
using CUAIntegrations.Application.Services.CUAServices.Exceptions;
using CUAIntegrations.Kernel.Core.InstanseScopeTypes;
using CUAIntegrations.Repository.Base;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System.Data.Entity;
using System.Security.Cryptography.X509Certificates;
using static CUAIntegrations.Application.Services.CUAServices.DTOs.AuthenticationServiceDTOs;

namespace CUAIntegrations.Application.Services.CUAServices
{
    public class CUAAuthenticationService : IScoped, ICUAAuthenticationService
    {
        private readonly SemaphoreSlim _refreshLock = new SemaphoreSlim(1, 1);
        private readonly SemaphoreSlim _authorizeLock = new SemaphoreSlim(1, 1);

        private readonly HttpClient _client;
        private readonly IConfiguration _configuration;
        private readonly ICUAIntegrationUnitOfWork _unitOfWork;
        private readonly ITimeHelper _timeHelper;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public CUAAuthenticationService(
            HttpClient client,
            IConfiguration configuration,
            ICUAIntegrationUnitOfWork unitOfWork,
            ITimeHelper timeHelper,
            IHttpContextAccessor httpContextAccessor)
        {
            _client = client;
            _configuration = configuration;
            _unitOfWork = unitOfWork;


            HttpClientHandler clientHandler = new HttpClientHandler()
            {
                SslProtocols = System.Security.Authentication.SslProtocols.Tls12
            };
            _client = new HttpClient(clientHandler);
            _timeHelper = timeHelper;
            _httpContextAccessor = httpContextAccessor;
        }

        public async Task<HttpClient> PrepareClient(HttpClient _httpClient)
        {
            var localAuth = await LocalAuthenticate();

            var headers = new Dictionary<string, string>();
            var httpHeaders = _httpContextAccessor.HttpContext.Request.Headers;
            headers[RequestHeadersConstants.X_REQUEST_ID] = Guid.NewGuid().ToString();
            headers[RequestHeadersConstants.X_CORRELATION_ID] = httpHeaders[RequestHeadersConstants.X_CORRELATION_ID].ToString();
            headers["X-Request-Timestamp"] = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ssZ");
            headers["X-Client-ID"] = "";
            headers["Authorization"] = localAuth.accessToken;

            _httpClient.DefaultRequestHeaders.Clear();
            if (headers != null)
            {
                foreach (var header in headers)
                    _httpClient.DefaultRequestHeaders.Add(header.Key, header.Value);
            }

            return _httpClient;
        }

        async Task<(bool succeeded, string accessToken)> LocalAuthenticate()
        {
            //todo: can be enhanced to use caching like Redis
            var integrationAuthentication = await _unitOfWork.IntegrationsAuthenticationRepository.Get()
                .FirstOrDefaultAsync();

            if (integrationAuthentication is null)
            {
                return (true, await AuthorizeIntegrationPoint());
            }
            if (integrationAuthentication.AccessTokenExpiresAt > DateTime.UtcNow)
            {
                return (succeeded: true, accessToken: integrationAuthentication.AccessToken);
            }
            if (string.IsNullOrEmpty(integrationAuthentication.RefreshToken))
            {
                return (true, await AuthorizeIntegrationPoint());
            }

            // Token is close to expire → try refresh but safely
            if (_refreshLock.CurrentCount == 0)
            {
                // Someone else is refreshing → return old token immediately if still valid
                if (integrationAuthentication.AccessTokenExpiresAt > DateTime.UtcNow.AddMinutes(5))
                {
                    return (succeeded: true, accessToken: integrationAuthentication.AccessToken);
                }
            }

            // Only one request reaches here
            await _refreshLock.WaitAsync();

            try
            {
                // Double check inside lock (maybe already refreshed)
                if (integrationAuthentication.AccessTokenExpiresAt > DateTime.UtcNow.AddMinutes(5))
                {
                    return (succeeded: true, accessToken: integrationAuthentication.AccessToken);
                }

                var authenticationResult = await Authenticate(new AuthenticateDTO
                {
                    RefreshToken = integrationAuthentication.RefreshToken,
                    GrantType = "refresh_token"
                });

                integrationAuthentication.UpdateAccessToken(

                    code: integrationAuthentication.Code,
                     scope: integrationAuthentication.Scope,
                     accessToken: authenticationResult.Access_Token,
                     refreshToken: authenticationResult.Refresh_Token,
                     accessTokenExpiresAt: _timeHelper.GetUTCTime().AddSeconds(authenticationResult.Expires_In)
                );
                _unitOfWork.IntegrationsAuthenticationRepository.Update(integrationAuthentication);
                await _unitOfWork.CommitAsync();

                return (succeeded: true, accessToken: integrationAuthentication.AccessToken);
            }
            finally
            {
                _refreshLock.Release();
            }
        }

        private async Task<string> AuthorizeIntegrationPoint()
        {
            try
            {
                // Only one request reaches here
                await _authorizeLock.WaitAsync();

                var token = await Authorize();
                var currentTryNumber = 1;
                var numberOfTries = Convert.ToInt32(_configuration["Authentication:ProxyToCUA:AuthorizeNumberOfTries"]);
                var tryDurationInSeconds = Convert.ToInt32(_configuration["Authentication:ProxyToCUA:AuthorizeTryDurationInSeconds"]);
                while (currentTryNumber <= numberOfTries)
                {
                    await Task.Delay(tryDurationInSeconds);
                    var integrationAuthentication = await _unitOfWork.IntegrationsAuthenticationRepository.Get()
                   .FirstOrDefaultAsync();

                    if (integrationAuthentication is null)
                    {
                        continue;
                    }

                    return integrationAuthentication.AccessToken;
                }
                throw new CUAAuthorizationFailedException("Authorization call back failed for the proxy server");
            }
            finally
            {
                _authorizeLock.Release();
            }
        }

        private async Task<bool> Authorize()
        {
            var authorizeAPI = _configuration["Authentication:ProxyToCUA:AuthorizeAPI"];
            var responseType = _configuration["Authentication:ProxyToCUA:AuthorizeAPIResponseType"];
            var clientId = _configuration["Authentication:ProxyToCUA:ClientId"];
            var RedirectURI = _configuration["Authentication:ProxyToCUA:RedirectUrl"];
            var scope = _configuration["Authentication:ProxyToCUA:Scope"];
            var state = _configuration["Authentication:ProxyToCUA:State"];

            authorizeAPI = string.Format(authorizeAPI, responseType, clientId, RedirectURI, scope, state);

            var res = await _client.GetAsync(authorizeAPI);
            var response = await res.Content.ReadAsStringAsync();
            if (res.IsSuccessStatusCode)
            {
                return true;
            }

            throw new CUAAuthorizationFailedException("Authorization failed for the proxy server");
        }

        public async Task<GetAuthenticateDTO> Authenticate(AuthenticateDTO authenticateDTO)
        {
            // Prepare form data
            var formData = new Dictionary<string, string>
                {
                    { "grant_type", authenticateDTO.GrantType }
                };

            if (!string.IsNullOrWhiteSpace(authenticateDTO.Code))
            {
                formData.Add("code", authenticateDTO.Code);
            }
            if (!string.IsNullOrWhiteSpace(authenticateDTO.RefreshToken))
            {
                formData.Add("refresh_token", authenticateDTO.RefreshToken);
            }

            var content = new FormUrlEncodedContent(formData);
            _client.DefaultRequestHeaders.Clear();
            var res = await _client.PostAsync(_configuration["Authentication:ProxyToCUA:TokenAPI"], content);
            var response = await res.Content.ReadAsStringAsync();
            if (res.IsSuccessStatusCode)
            {
                var result = JsonConvert.DeserializeObject<GetAuthenticateDTO>(response);
            }
            else
            {
                return null;
            }
            //todo: need to be checked in case what is the result when refresh token is sent and when failed access/refresh token generation
            throw new CUAAuthorizationFailedException("Access/Refresh Token Authorization Failed");
        }
    }
}
