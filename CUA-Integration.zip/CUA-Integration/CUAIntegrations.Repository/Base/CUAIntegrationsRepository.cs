﻿using CUAIntegrations.Kernel.Core.Persistence;
using CUAIntegrations.Persistence.DataAccess.Context;

namespace CUAIntegrations.Repository.Base
{
    public class CUAIntegrationsRepository<T> : CUAIntegrationRepositoryBase<T>, IRepository<T> where T : class
    {
        public CUAIntegrationsRepository(CUAIntegrationDbContext context)
            : base(context)
        {
        }

        public virtual T Add(T entity)
        {
            return context.Set<T>().Add(entity).Entity;
        }

        public virtual async Task<T> AddAsync(T entity)
        {
            //context.Entry(entity).State = EntityState.Added;
            //context.Set<T>().Attach(entity);
            return (await context.Set<T>().AddAsync(entity)).Entity;
        }

        public virtual async Task AddRangeAsync(T[] entities)
        {
            //context.Entry(entities).State = EntityState.Added;
            //context.Set<T>().AttachRange(entities);
            await context.Set<T>().AddRangeAsync(entities);
        }

        public virtual void Remove(T entity)
        {
            //    T existing = context.Set<T>().Find(entity);
            //    if (existing != null) 
            //context.Entry(entity).State = EntityState.Deleted;
            //context.Set<T>().Attach(entity);
            context.Set<T>().Remove(entity);
        }

        public virtual void RemoveRange(T[] entities)
        {
            //    T existing = context.Set<T>().Find(entity);
            //    if (existing != null) 
            //context.Entry(entities).State = EntityState.Deleted;
            //context.Set<T>().AttachRange(entities);
            context.Set<T>().RemoveRange(entities);
        }

        public virtual T Update(T entity)
        {
            //context.Entry(entity).State = EntityState.Modified;
            //context.Set<T>().Attach(entity);
            context.Set<T>().Update(entity);
            return entity;
        }
    }
}
