﻿using CUA_GCC_Integration.Core.Helpers;
using CUAIntegrations.Application.Features.V1.Queries.CUA;
using FluentValidation;
using System.Text.RegularExpressions;

namespace CUAIntegrations.Application.Features.V1.Queries.CUA.CustomsDeclarations
{
    public class GetOutBoundedCustomsDeclarationQueryValidator
        : AbstractValidator<GetOutBoundedCustomsDeclarationQuery>
    {
        private readonly ISharedValidationHelper _validationHelper;

        public GetOutBoundedCustomsDeclarationQueryValidator(ISharedValidationHelper validationHelper)
        {
            _validationHelper = validationHelper;

            RuleFor(x => x.DeclarationNumber)
                .NotEmpty()
                .WithErrorCode("ERR-02")
                .WithMessage("DeclarationNumber is mandatory.");

            RuleFor(x => x.DeclarationNumber)
                .MaximumLength(70)
                .WithErrorCode("ERR-03")
                .WithMessage("DeclarationNumber must not exceed 70 characters.");

            RuleFor(x => x.DeclarationNumber)
                .Matches("^[A-Za-z0-9]+$")
                .WithErrorCode("ERR-03")
                .WithMessage("DeclarationNumber must be alphanumeric.");
            ///DeclarationType
            RuleFor(x => x.DeclarationType)
                   .NotEmpty()
                   .WithErrorCode("ERR-02")
                   .WithMessage($"DeclarationType is mandatory for {ApplicationClientsConstants.Kuwait}.");

            RuleFor(x => x.DeclarationType)
                .Length(3)
                .WithErrorCode("ERR-03")
                .WithMessage("DeclarationType must be exactly 3 characters.");
            ///Year
            RuleFor(x => x.Year)
                .NotEmpty()
                .WithErrorCode("ERR-02")
                .WithMessage($"Year is mandatory for {ApplicationClientsConstants.Kuwait}.");

            RuleFor(x => x.Year)
                .Matches("^[0-9]{4}$")
                .WithErrorCode("ERR-03")
                .WithMessage("Year must be a 4-digit number.");

            // Port
            RuleFor(x => x.Port)
                .NotEmpty()
                .WithErrorCode("ERR-02")
                .WithMessage($"Port is mandatory for {ApplicationClientsConstants.Kuwait}.");

            RuleFor(x => x.Port)
                .Length(3)
                .WithErrorCode("ERR-03")
                .WithMessage("Port must be exactly 3 characters.");

            RuleFor(x => x.Port)
                .Matches("^[A-Za-z0-9]+$")
                .WithErrorCode("ERR-03")
                .WithMessage("Port must be alphanumeric.");



        }

    }
}
