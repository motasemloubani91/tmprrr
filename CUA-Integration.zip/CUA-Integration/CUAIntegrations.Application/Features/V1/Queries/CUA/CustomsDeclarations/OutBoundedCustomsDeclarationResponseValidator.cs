﻿using CUAIntegrations.Application.Features.V1.Queries.Mc.DownloadDocument;
using FluentValidation;

namespace CUAIntegrations.Application.Features.V1.Queries.CUA.CustomsDeclarations
{



    public class OutBoundedCustomsDeclarationResponseValidator : AbstractValidator<OutBoundedCustomsDeclarationResponse>
    {
        public OutBoundedCustomsDeclarationResponseValidator()
        {

            RuleFor(x => x.CustomsDeclarationEntity)
               .SetValidator(new CUACustomsDeclarationsDTOValidator());

        }

    }

    #region Declaration DTO Validator

    public class CUACustomsDeclarationsDTOValidator : AbstractValidator<CUACustomsDeclarationsDTO>
    {
        public CUACustomsDeclarationsDTOValidator()
        {
            // declarationNumber 
            RuleFor(x => x.DeclarationNumber)
                .NotEmpty()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: declarationNumber.");

            RuleFor(x => x.DeclarationNumber)
                .MaximumLength(70)
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: declarationNumber max length is 70.");

            RuleFor(x => x.DeclarationNumber)
                .Matches("^[A-Za-z0-9]+$")
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid format: declarationNumber must be alphanumeric.");

            // declarationDate 
            RuleFor(x => x.DeclarationDate)
                .NotNull()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: declarationDate.");

            RuleFor(x => x.DeclarationDate)
                .Must(BeValidDate)
                .WithErrorCode("ERR-22")
                .WithMessage("Invalid date format: declarationDate must be YYYYMMDDHHMMSS.");

            // declarationType
            RuleFor(x => x.DeclarationType)
                .NotEmpty()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: declarationType.");

            RuleFor(x => x.DeclarationType)
                .Length(3)
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: declarationType must be 3 characters.");

            // portType 
            RuleFor(x => x.PortType)
                .NotEmpty()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: portType.");

            RuleFor(x => x.PortType)
                .Length(3)
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: portType must be 3 characters.");

            // deliveryOrderNumber 
            RuleFor(x => x.DeliveryOrderNumber)
                .MaximumLength(70)
                .When(x => !string.IsNullOrEmpty(x.DeliveryOrderNumber))
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: deliveryOrderNumber max length is 70.");

            // importerExporterName 
            RuleFor(x => x.ImporterExporterName)
                .NotEmpty()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: importerExporterName.");

            RuleFor(x => x.ImporterExporterName)
                .MaximumLength(70)
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: importerExporterName max length is 70.");

            // importerExporterCustomsId 
            RuleFor(x => x.ImporterExporterCustomsId)
                .NotEmpty()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: importerExporterCustomsId.");

            RuleFor(x => x.ImporterExporterCustomsId)
                .MaximumLength(35)
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: importerExporterCustomsId max length is 35.");

            // netWeight 
            RuleFor(x => x.NetWeight)
                .NotNull()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: netWeight.");

            RuleFor(x => x.NetWeight)
                .GreaterThanOrEqualTo(0)
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid value: netWeight must be >= 0.");

            // carrierCaptainDriver
            RuleFor(x => x.CarrierCaptainDriver)
                .MaximumLength(70)
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: carrierCaptainDriver max length is 70.");

            //  intercessorCompany 
            RuleFor(x => x.IntercessorCompany)
                .MaximumLength(70)
                .When(x => !string.IsNullOrEmpty(x.IntercessorCompany))
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: intercessorCompany max length is 70.");

            // grossWeight
            RuleFor(x => x.GrossWeight)
                .NotNull()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: grossWeight.");

            RuleFor(x => x.GrossWeight)
                .GreaterThanOrEqualTo(0)
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid value: grossWeight must be >= 0.");

            // carrierName 
            RuleFor(x => x.CarrierName)
                .MaximumLength(70)
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: carrierName max length is 70.");

            // commercialRegistrationNumber
            RuleFor(x => x.CommercialRegistrationNumber)
                .MaximumLength(35)
                .When(x => !string.IsNullOrEmpty(x.CommercialRegistrationNumber))
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: commercialRegistrationNumber max length is 35.");

            // tinNumber
            RuleFor(x => x.TinNumber)
                .MaximumLength(35)
                .When(x => !string.IsNullOrEmpty(x.TinNumber))
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: tinNumber max length is 35.");

            // measurement 
            RuleFor(x => x.Measurement)
                .NotEmpty()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: measurement.");

            RuleFor(x => x.Measurement)
                .Length(3)
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: measurement must be 3 characters.");

            //  voyageFlightNumber 
            RuleFor(x => x.VoyageFlightNumber)
                .MaximumLength(17)
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: voyageFlightNumber max length is 17.");

            //  exportedTo 
            RuleFor(x => x.ExportedTo)
                .MaximumLength(70)
                .When(x => !string.IsNullOrEmpty(x.ExportedTo))
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: exportedTo max length is 70.");

            //  numberOfPackages
            RuleFor(x => x.NumberOfPackages)
                .InclusiveBetween(0, 99999999)
                .When(x => x.NumberOfPackages.HasValue)
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid value: numberOfPackages must be numeric up to 8 digits.");

            // blAwbManifestNo 
            RuleFor(x => x.BlAwbManifestNo)
                .MaximumLength(70)
                .When(x => !string.IsNullOrEmpty(x.BlAwbManifestNo))
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: blAwbManifestNo max length is 70.");

            //portOfLoading
            RuleFor(x => x.PortOfLoading)
                .MaximumLength(256)
                .When(x => !string.IsNullOrEmpty(x.PortOfLoading))
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: portOfLoading max length is 256.");

            //  marksAndNumbers 

            RuleFor(x => x.MarksAndNumbers)
                .MaximumLength(512)
                .When(x => !string.IsNullOrEmpty(x.PortOfLoading))
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: marksAndNumbers max length is 512.");

            // portOfDischarge 
            RuleFor(x => x.PortOfDischarge)
                .MaximumLength(256)
                .When(x => !string.IsNullOrEmpty(x.PortOfDischarge))
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: portOfDischarge max length is 256.");

            // destinationCountryCode 
            RuleFor(x => x.DestinationCountryCode)
                .Matches("^[A-Za-z]{2}$")
                .When(x => !string.IsNullOrEmpty(x.DestinationCountryCode))
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid format: destinationCountryCode must be 2 alphabetic characters.");

            // items 
            RuleFor(x => x.Items)
                .NotEmpty()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: items.");

            RuleForEach(x => x.Items).SetValidator(new CuaItemsDtoValidator());

            // ClearingAgentName
            RuleFor(x => x.ClearingAgentName)
                .MaximumLength(70)
                .When(x => !string.IsNullOrEmpty(x.ClearingAgentName))
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: clearingAgentName max length is 70.");
            // ClearingAgentCode
            RuleFor(x => x.ClearingAgentCode)
                .MaximumLength(35)
                .When(x => !string.IsNullOrEmpty(x.ClearingAgentCode))
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: clearingAgentCode max length is 35.");
            // LicenseNumber
            RuleFor(x => x.LicenseNumber)
                .MaximumLength(35)
                .When(x => !string.IsNullOrEmpty(x.LicenseNumber))
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: licenseNumber max length is 35.");
            // RiskOutcome
            RuleFor(x => x.RiskOutcome)
                .MaximumLength(10)
                .When(x => !string.IsNullOrEmpty(x.RiskOutcome))
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: riskOutcome max length is 10.");
            // ValuationMethod
            RuleFor(x => x.ValuationMethod)
                .MaximumLength(3)
                .When(x => !string.IsNullOrEmpty(x.ValuationMethod))
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: valuationMethod max length is 3.");
            // OtherRemarks
            RuleFor(x => x.OtherRemarks)
                .MaximumLength(512)
                .When(x => !string.IsNullOrEmpty(x.OtherRemarks))
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: otherRemarks max length is 512.");

            // releaseDate 
            RuleFor(x => x.ReleaseDate)
                .NotNull()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: releaseDate.");

            RuleFor(x => x.ReleaseDate)
                .Must(BeValidDate)
                .WithErrorCode("ERR-22")
                .WithMessage("Invalid date format: releaseDate must be YYYYMMDDHHMMSS.");

            // route  
            RuleFor(x => x.Route)
                .MaximumLength(256)
                .When(x => !string.IsNullOrEmpty(x.Route))
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: route max length is 256.");
            // exitPort
            RuleFor(x => x.ExitPort)
                .MaximumLength(256)
                .When(x => !string.IsNullOrEmpty(x.ExitPort))
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: exitPort max length is 256.");

            // 34. totalDuty
            RuleFor(x => x.TotalDuty)
                .NotNull()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: totalDuty.");

            RuleFor(x => x.TotalDuty)
                .GreaterThanOrEqualTo(0)
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid value: totalDuty must be >= 0.");


            //  dueNumber 
            RuleFor(x => x.DueNumber)
                .Length(65)
                .When(x => !string.IsNullOrEmpty(x.DueNumber))
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: dueNumber must be 65 characters.");

            RuleFor(x => x.DueNumber)
                .Matches("^[0-9]+$")
                .When(x => !string.IsNullOrEmpty(x.DueNumber))
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid format: dueNumber must be numeric.");

            //  unifiedCustomsCode 
            RuleFor(x => x.UnifiedCustomsCode)
                .MaximumLength(35)
                .When(x => !string.IsNullOrEmpty(x.UnifiedCustomsCode))
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: unifiedCustomsCode max length is 35.");

            //  definiteFee
            RuleFor(x => x.DefiniteFee)
                .NotNull()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: definiteFee.");

            RuleFor(x => x.DefiniteFee)
                .GreaterThanOrEqualTo(0)
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid value: definiteFee must be >= 0.");



            // 42. payments 
            RuleForEach(x => x.Payments ?? new List<CuaPaymentsDto>())
                .SetValidator(new CuaPaymentsDtoValidator());
        }

        private bool BeValidDate(string date)
        {
            
            return date.Length == 14;
        }
    }
    #endregion

    #region Items Validator
    public class CuaItemsDtoValidator : AbstractValidator<CuaItemsDto>
    {
        public CuaItemsDtoValidator()
        {
            // hsCode 
            RuleFor(x => x.HsCode)
                .NotEmpty()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: hsCode.");

            RuleFor(x => x.HsCode)
                .MaximumLength(12)
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: hsCode max length 12.");

            // goodsDescription 
            RuleFor(x => x.GoodsDescription)
                .NotEmpty()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: goodsDescription.");

            RuleFor(x => x.GoodsDescription)
                .MaximumLength(512)
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: goodsDescription max length 512.");

            // originCountryCode
            RuleFor(x => x.OriginCountryCode)
                .NotEmpty()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: originCountryCode.");

            RuleFor(x => x.OriginCountryCode)
                .Matches("^[A-Za-z]{2}$")
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: originCountryCode must be 2 alphabetic characters.");

            // cifForeignValue 
            RuleFor(x => x.CifForeignValue)
                .NotNull()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: cifForeignValue.");

            RuleFor(x => x.CifForeignValue)
                .GreaterThanOrEqualTo(0)
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid value: cifForeignValue must be >= 0.");

            // currency 
            RuleFor(x => x.Currency)
                .NotNull()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: currency.");

            RuleFor(x => x.Currency)
                .SetValidator(new CuaCurrenciesDtoValidator());

            // cifLocalValue
            RuleFor(x => x.CifLocalValue)
                .NotNull()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: cifLocalValue.");

            RuleFor(x => x.CifLocalValue)
                .GreaterThanOrEqualTo(0)
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid value: cifLocalValue must be >= 0.");

            // dutyRate 
            RuleFor(x => x.DutyRate)
                .NotEmpty()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: dutyRate.");

            RuleFor(x => x.DutyRate)
                .MaximumLength(70)
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: dutyRate max length 70.");

            // incomeType
            RuleFor(x => x.IncomeType)
                .MaximumLength(70)
                .When(x => !string.IsNullOrEmpty(x.IncomeType))
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: incomeType max length 70.");

            // totalDuty 
            RuleFor(x => x.TotalDuty)
                .NotNull()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: totalDuty.");

            RuleFor(x => x.TotalDuty)
                .GreaterThanOrEqualTo(0)
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid value: totalDuty must be >= 0.");

            // packages
            RuleFor(x => x.Packages)
                .SetValidator(new CuaPackagesDtoValidator())
                .When(x => x.Packages != null);

            //  item 
            RuleFor(x => x.Item)
                .NotNull()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: item.");

            RuleFor(x => x.Item)
                .SetValidator(new CuaItemDetailsDtoValidator());

            // netWeight
            RuleFor(x => x.NetWeight)
                .NotNull()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: netWeight.");

            RuleFor(x => x.NetWeight)
                .GreaterThanOrEqualTo(0)
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid value: netWeight must be >= 0.");

            // grossWeight 
            RuleFor(x => x.GrossWeight)
                .NotNull()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: grossWeight.");

            RuleFor(x => x.GrossWeight)
                .GreaterThanOrEqualTo(0)
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid value: grossWeight must be >= 0.");

            // AIP 
            RuleFor(x => x.AIP)
                .SetValidator(new CuaAIPsDtoValidator())
                .When(x => x.AIP != null);

            // Restrictions 
            RuleForEach(x => x.Restrictions ?? new List<CuaRestrictionsDto>())
                .SetValidator(new CuaRestrictionsDtoValidator());

            // exemptionApprovalRef
            RuleFor(x => x.ExemptionApprovalRef)
                .MaximumLength(35)
                .When(x => !string.IsNullOrEmpty(x.ExemptionApprovalRef))
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: exemptionApprovalRef max length 35.");
        }
    }
    #endregion

    #region Payment Validator
    public class CuaPaymentsDtoValidator : AbstractValidator<CuaPaymentsDto>
    {
        public CuaPaymentsDtoValidator()
        {
            // method 
            RuleFor(x => x.Method)
                .MaximumLength(1)
                .When(x => !string.IsNullOrEmpty(x.Method))
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: method max length 1.");

            // noumber
            RuleFor(x => x.No)
                .MaximumLength(35)
                .When(x => !string.IsNullOrEmpty(x.No))
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: no max length 35.");

            // date 
            RuleFor(x => x.Date)
                .Length(14)
                 .When(x => !string.IsNullOrEmpty(x.Date))
                .WithErrorCode("ERR-22")
                .WithMessage("Invalid date format: Date must be YYYYMMDDHHMMSS.");

            // bank 
            RuleFor(x => x.Bank)
                .MaximumLength(70)
                .When(x => !string.IsNullOrEmpty(x.Bank))
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: bank max length 70.");
        }

       
    }
    #endregion

    #region Currency Validator
    public class CuaCurrenciesDtoValidator : AbstractValidator<CuaCurrenciesDto>
    {
        public CuaCurrenciesDtoValidator()
        {
            // type 
            RuleFor(x => x.Type)
                .NotEmpty()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: type.");

            RuleFor(x => x.Type)
                .MaximumLength(3)
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: type max length 3.");

            // value 
            RuleFor(x => x.Value)
                .NotNull()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: value.");

            RuleFor(x => x.Value)
                .GreaterThanOrEqualTo(0)
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid value: value must be >= 0.");
        }
    }
    #endregion

    #region Packages Validator
    public class CuaPackagesDtoValidator : AbstractValidator<CuaPackagesDto>
    {
        public CuaPackagesDtoValidator()
        {
            // quantity
            RuleFor(x => x.Quantity)
                .GreaterThanOrEqualTo(0)
                .When(x => x.Quantity.HasValue)
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid value: quantity must be >= 0.");

            // type
            RuleFor(x => x.Type)
                .MaximumLength(3)
                .When(x => !string.IsNullOrEmpty(x.Type))
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: type max length 3.");
        }
    }
    #endregion

    #region Item Details Validator
    public class CuaItemDetailsDtoValidator : AbstractValidator<CuaItemDetailsDto>
    {
        public CuaItemDetailsDtoValidator()
        {
            // quantity
            RuleFor(x => x.Quantity)
                .NotNull()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: quantity.");

            RuleFor(x => x.Quantity)
                .GreaterThanOrEqualTo(0)
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid value: quantity must be >= 0.");

            // unit 
            RuleFor(x => x.Unit)
                .NotEmpty()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: unit.");

            RuleFor(x => x.Unit)
                .Length(3)
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: unit must be 3.");
        }
    }
    #endregion

    #region AIP Validator
    public class CuaAIPsDtoValidator : AbstractValidator<CuaAIPsDto>
    {
        public CuaAIPsDtoValidator()
        {
            // gazetteNumber 
            RuleFor(x => x.GazetteNumber)
                .MaximumLength(35)
                .When(x => !string.IsNullOrEmpty(x.GazetteNumber))
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: gazetteNumber max length 35.");

            // duty 
            RuleFor(x => x.Duty)
                .GreaterThanOrEqualTo(0)
                .When(x => x.Duty.HasValue)
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid value: duty must be >= 0.");
        }
    }
    #endregion

    #region Restrictions Validator
    public class CuaRestrictionsDtoValidator : AbstractValidator<CuaRestrictionsDto>
    {
        public CuaRestrictionsDtoValidator()
        {
            // agency 
            RuleFor(x => x.Agency)
                .NotEmpty()
                .WithErrorCode("ERR-08")
                .WithMessage("Missing mandatory field: agency.");

            RuleFor(x => x.Agency)
                .MaximumLength(70)
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: agency max length 70.");

            // releaseRef 
            RuleFor(x => x.ReleaseRef)
                .MaximumLength(70)
                .When(x => !string.IsNullOrEmpty(x.ReleaseRef))
                .WithErrorCode("ERR-11")
                .WithMessage("Invalid field length: releaseRef max length 70.");
        }
    }
    #endregion
}
