﻿using System.Security.Principal;

namespace CUAIntegrations.Kernel.Domain.Entities.Lookups
{
    public class LanguageCodesLookup
    {
        public long Id { get; set; }
        public string? Code { get; set; }
        public string? ArabicLanguageName { get; set; }
        public string? EnglishLanguageName { get; set; }
        public string? LanguageFamily { get; set; }
        public string? NativeName { get; set; }


    }
}
