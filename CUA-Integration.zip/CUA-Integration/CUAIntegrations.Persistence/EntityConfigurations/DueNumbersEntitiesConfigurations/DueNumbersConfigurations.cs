﻿using CUAIntegrations.Kernel.Domain.Entities.DueNumbers;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace CUA_GCC_Integration.Persistence.EntityConfigurations.DueNumbersEntityConfigurations
{
    public class DueNumbersConfiguration : IEntityTypeConfiguration<DueNumber>
    {
        public void Configure(EntityTypeBuilder<DueNumber> entity)
        {
            entity.ToTable("GCC_DueNumbers", schema: "GCC");

            entity.HasKey(e => e.Id);
            entity.Property(e => e.Id)
                 .ValueGeneratedOnAdd();

            entity.Property(e => e.Id)
                  .ValueGeneratedOnAdd();
            entity.Property(a => a.Version)
                  .IsRequired()
                  .HasDefaultValue(1);
            entity.Property(e => e.TransferDeclarationNumber)
                  .IsRequired()
                  .HasMaxLength(100);

            entity.Property(e => e.TransferPort)
                  .IsRequired()
                  .HasMaxLength(3);

            entity.Property(e => e.TransferDeclarationDate)
                  .IsRequired();

            entity.Property(e => e.DueAmount)
                  .IsRequired();

            entity.Property(e => e.DestinationCountry)
                  .IsRequired()
                  .HasMaxLength(3);

            entity.Property(e => e.FirstEntryCountry)
                  .IsRequired()
                  .HasMaxLength(3);

            entity.Property(e => e.FirstEntryPort)
                  .IsRequired()
                  .HasMaxLength(3);

            entity.Property(e => e.FirstEntryDeclarationNumber)
                  .IsRequired()
                  .HasMaxLength(100);

            entity.Property(e => e.FirstEntryDeclarationDate)
                  .IsRequired();

            entity.Property(e => e.Status)
                  .IsRequired()
                  .HasMaxLength(3);

            entity.Property(e => e.ReceiptFileRef)
                  .HasMaxLength(10);

           
        }
    }

}
