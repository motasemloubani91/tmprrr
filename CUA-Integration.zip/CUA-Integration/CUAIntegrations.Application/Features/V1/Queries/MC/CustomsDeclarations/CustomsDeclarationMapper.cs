﻿using CUAIntegrations.Application.Features.V1.Queries.OutBoundedForMC.CustomsDeclarations;
using CUAIntegrations.Kernel.Domain.Entities.CustomsDeclarationsEntities;

public static class CustomsDeclarationMapper
{
    // ------------------- PARENT: CUSTOMS DECLARATION -------------------
    public static CUACustomsDeclarationsDto ToDto(CustomsDeclarationsEntities entity)
    {
        if (entity == null) return null;

        var dto = new CUACustomsDeclarationsDto();

        dto.Id = entity.Id;
        dto.DeclarationNumber = entity.DeclarationNumber;
        dto.DeclarationDate = entity.DeclarationDate;
        dto.DeclarationType = entity.DeclarationType;
        dto.PortType = entity.PortType;
        dto.DeliveryOrderNumber = entity.DeliveryOrderNumber;
        dto.ImporterExporterName = entity.ImporterExporterName;
        dto.ImporterExporterCustomsId = entity.ImporterExporterCustomsId;
        dto.NetWeight = entity.NetWeight;
        dto.GrossWeight = entity.GrossWeight;
        dto.Measurement = entity.Measurement;
        dto.CarrierCaptainDriver = entity.CarrierCaptainDriver;
        dto.CarrierName = entity.CarrierName;
        dto.CommercialRegistrationNumber = entity.CommercialRegistrationNumber;
        dto.TinNumber = entity.TinNumber;
        dto.VoyageFlightNumber = entity.VoyageFlightNumber;
        dto.ExportedTo = entity.ExportedTo;
        dto.NumberOfPackages = entity.NumberOfPackages;
        dto.BlAwbManifestNo = entity.BlAwbManifestNo;
        dto.PortOfLoading = entity.PortOfLoading;
        dto.MarksAndNumbers = entity.MarksAndNumbers;
        dto.PortOfDischarge = entity.PortOfDischarge;
        dto.DestinationCountryCode = entity.DestinationCountryCode;
        dto.IntercessorCompany = entity.IntercessorCompany;
        dto.ClearingAgentName = entity.ClearingAgentName;
        dto.ClearingAgentCode = entity.ClearingAgentCode;
        dto.LicenseNumber = entity.LicenseNumber;
        dto.RiskOutcome = entity.RiskOutcome;
        dto.ValuationMethod = entity.ValuationMethod;
        dto.OtherRemarks = entity.OtherRemarks;
        dto.ReleaseDate = entity.ReleaseDate;
        dto.Route = entity.Route;
        dto.ExitPort = entity.ExitPort;
        dto.TotalDuty = entity.TotalDuty;
        dto.DefiniteFee = entity.DefiniteFee;
        dto.Vat = entity.Vat;
        dto.ExciseTax = entity.ExciseTax;
        dto.OtherCharges = entity.OtherCharges;
        dto.Insured = entity.Insured;
        dto.DueNumber = entity.DueNumber;
        dto.UnifiedCustomsCode = entity.UnifiedCustomsCode;

        dto.Items = entity.Items?.Select(ToItemDto).ToList() ?? new List<CUAItemsDto>();
        dto.Payments = entity.Payments?.Select(ToPaymentDto).ToList() ?? new List<CUAPaymentsDto>();

        return dto;
    }

    public static CustomsDeclarationsEntities ToEntity(CUACustomsDeclarationsDto dto)
    {
        if (dto == null) return null;

        var entity = new CustomsDeclarationsEntities();

        entity.Id = dto.Id;
        entity.DeclarationNumber = dto.DeclarationNumber;
        entity.DeclarationDate = dto.DeclarationDate;
        entity.DeclarationType = dto.DeclarationType;
        entity.PortType = dto.PortType;
        entity.DeliveryOrderNumber = dto.DeliveryOrderNumber;
        entity.ImporterExporterName = dto.ImporterExporterName;
        entity.ImporterExporterCustomsId = dto.ImporterExporterCustomsId;
        entity.NetWeight = dto.NetWeight;
        entity.GrossWeight = dto.GrossWeight;
        entity.Measurement = dto.Measurement;
        entity.CarrierCaptainDriver = dto.CarrierCaptainDriver;
        entity.CarrierName = dto.CarrierName;
        entity.CommercialRegistrationNumber = dto.CommercialRegistrationNumber;
        entity.TinNumber = dto.TinNumber;
        entity.VoyageFlightNumber = dto.VoyageFlightNumber;
        entity.ExportedTo = dto.ExportedTo;
        entity.NumberOfPackages = dto.NumberOfPackages;
        entity.BlAwbManifestNo = dto.BlAwbManifestNo;
        entity.PortOfLoading = dto.PortOfLoading;
        entity.MarksAndNumbers = dto.MarksAndNumbers;
        entity.PortOfDischarge = dto.PortOfDischarge;
        entity.DestinationCountryCode = dto.DestinationCountryCode;
        entity.IntercessorCompany = dto.IntercessorCompany;
        entity.ClearingAgentName = dto.ClearingAgentName;
        entity.ClearingAgentCode = dto.ClearingAgentCode;
        entity.LicenseNumber = dto.LicenseNumber;
        entity.RiskOutcome = dto.RiskOutcome;
        entity.ValuationMethod = dto.ValuationMethod;
        entity.OtherRemarks = dto.OtherRemarks;
        entity.ReleaseDate = dto.ReleaseDate;
        entity.Route = dto.Route;
        entity.ExitPort = dto.ExitPort;
        entity.TotalDuty = dto.TotalDuty;
        entity.DefiniteFee = dto.DefiniteFee;
        entity.Vat = dto.Vat;
        entity.ExciseTax = dto.ExciseTax;
        entity.OtherCharges = dto.OtherCharges;
        entity.Insured = dto.Insured;
        entity.DueNumber = dto.DueNumber;
        entity.UnifiedCustomsCode = dto.UnifiedCustomsCode;

        entity.Items = dto.Items?.Select(ToItemEntity).ToList() ?? new List<Items>();
        entity.Payments = dto.Payments?.Select(ToPaymentEntity).ToList() ?? new List<Payments>();

        return entity;
    }

    // ------------------- ITEMS -------------------
    private static CUAItemsDto ToItemDto(Items entity)
    {
        if (entity == null) return null;

        var dto = new CUAItemsDto();

        dto.Id = entity.Id;
        dto.DeclarationId = entity.DeclarationId;
        dto.HsCode = entity.HsCode;
        dto.GoodsDescription = entity.GoodsDescription;
        dto.OriginCountryCode = entity.OriginCountryCode;
        dto.CifForeignValue = entity.CifForeignValue;
        dto.CifLocalValue = entity.CifLocalValue;
        dto.DutyRate = entity.DutyRate;
        dto.TotalDuty = entity.TotalDuty;
        dto.NetWeight = entity.NetWeight;
        dto.GrossWeight = entity.GrossWeight;
        dto.ExemptionApprovalRef = entity.ExemptionApprovalRef;
        dto.IncomeType = entity.IncomeType;

        dto.Currency = ToCurrencyDto(entity.Currency);
        dto.Packages = ToPackageDto(entity.Packages);
        dto.Item = ToItemDetailsDto(entity.Item);
        dto.AIP = ToAipDto(entity.AIP);

        dto.Restrictions = entity.Restrictions?.Select(ToRestrictionDto).ToList() ?? new List<CUARestrictionsDto>();

        return dto;
    }

    private static Items ToItemEntity(CUAItemsDto dto)
    {
        if (dto == null) return null;

        var entity = new Items();

        entity.Id = dto.Id;
        entity.DeclarationId = dto.DeclarationId;
        entity.HsCode = dto.HsCode;
        entity.GoodsDescription = dto.GoodsDescription;
        entity.OriginCountryCode = dto.OriginCountryCode;
        entity.CifForeignValue = dto.CifForeignValue;
        entity.CifLocalValue = dto.CifLocalValue;
        entity.DutyRate = dto.DutyRate;
        entity.TotalDuty = dto.TotalDuty;
        entity.NetWeight = dto.NetWeight;
        entity.GrossWeight = dto.GrossWeight;
        entity.ExemptionApprovalRef = dto.ExemptionApprovalRef;
        entity.IncomeType = dto.IncomeType;

        entity.Currency = ToCurrencyEntity(dto.Currency);
        entity.Packages = ToPackageEntity(dto.Packages);
        entity.Item = ToItemDetailsEntity(dto.Item);
        entity.AIP = ToAipEntity(dto.AIP);

        entity.Restrictions = dto.Restrictions?.Select(ToRestrictionEntity).ToList() ?? new List<Restrictions>();

        return entity;
    }

    // ------------------- CURRENCY -------------------
    private static CUACurrenciesDto ToCurrencyDto(Currencies entity)
    {
        if (entity == null) return null;

        var dto = new CUACurrenciesDto();

        dto.Id = entity.Id;
        dto.ItemId = entity.ItemId;
        dto.Type = entity.Type;
        dto.Value = entity.Value;

        return dto;
    }

    private static Currencies ToCurrencyEntity(CUACurrenciesDto dto)
    {
        if (dto == null) return null;

        var entity = new Currencies();

        entity.Id = (dto?.Id ?? 0);
        entity.ItemId = (dto?.ItemId ?? 0) ;
        entity.Type = dto.Type;
        entity.Value = dto.Value;

        return entity;
    }

    // ------------------- PACKAGES -------------------
    private static CUAPackagesDto ToPackageDto(Packages entity)
    {
        if (entity == null) return null;

        var dto = new CUAPackagesDto();

        dto.Id = entity.Id;
        dto.ItemId = entity.ItemId;
        dto.Quantity = entity.Quantity;
        dto.Type = entity.Type;

        return dto;
    }

    private static Packages ToPackageEntity(CUAPackagesDto dto)
    {
        if (dto == null) return null;

        var entity = new Packages();

        entity.Id = dto.Id;
        entity.ItemId = dto.ItemId;
        entity.Quantity = dto.Quantity;
        entity.Type = dto.Type;

        return entity;
    }

    // ------------------- ITEM DETAILS -------------------
    private static CUAItemDetailsDto ToItemDetailsDto(ItemDetails entity)
    {
        if (entity == null) return null;

        var dto = new CUAItemDetailsDto();

        dto.Id = entity.Id;
        dto.ItemId = entity.ItemId;
        dto.Quantity = entity.Quantity;
        dto.Unit = entity.Unit;

        return dto;
    }

    private static ItemDetails ToItemDetailsEntity(CUAItemDetailsDto dto)
    {
        if (dto == null) return null;

        var entity = new ItemDetails();

        entity.Id = dto.Id;
        entity.ItemId = dto.ItemId;
        entity.Quantity = dto.Quantity;
        entity.Unit = dto.Unit;

        return entity;
    }

    // ------------------- AIP -------------------
    private static CUAAIPsDto ToAipDto(AIPs entity)
    {
        if (entity == null) return null;

        var dto = new CUAAIPsDto();

        dto.Id = entity.Id;
        dto.ItemId = entity.ItemId;
        dto.GazetteNumber = entity.GazetteNumber;
        dto.Duty = entity.Duty;

        return dto;
    }

    private static AIPs ToAipEntity(CUAAIPsDto dto)
    {
        if (dto == null) return null;

        var entity = new AIPs();

        entity.Id = dto.Id;
        entity.ItemId = dto.ItemId;
        entity.GazetteNumber = dto.GazetteNumber;
        entity.Duty = dto.Duty;

        return entity;
    }

    // ------------------- RESTRICTIONS -------------------
    private static CUARestrictionsDto ToRestrictionDto(Restrictions entity)
    {
        if (entity == null) return null;

        var dto = new CUARestrictionsDto();

        dto.Id = entity.Id;
        dto.ItemId = entity.ItemId;
        dto.Agency = entity.Agency;
        dto.ReleaseRef = entity.ReleaseRef;

        return dto;
    }

    private static Restrictions ToRestrictionEntity(CUARestrictionsDto dto)
    {
        if (dto == null) return null;

        var entity = new Restrictions();

        entity.Id = dto.Id;
        entity.ItemId = dto.ItemId;
        entity.Agency = dto.Agency;
        entity.ReleaseRef = dto.ReleaseRef;

        return entity;
    }

    // ------------------- PAYMENTS -------------------
    private static CUAPaymentsDto ToPaymentDto(Payments entity)
    {
        if (entity == null) return null;

        var dto = new CUAPaymentsDto();

        dto.Id = entity.Id;
        dto.DeclarationId = entity.DeclarationId;
        dto.Method = entity.Method;
        dto.No = entity.No;
        dto.Date = entity.Date;
        dto.Bank = entity.Bank;

        return dto;
    }

    private static Payments ToPaymentEntity(CUAPaymentsDto dto)
    {
        if (dto == null) return null;

        var entity = new Payments();

        entity.Id = dto.Id;
        entity.DeclarationId = dto.DeclarationId;
        entity.Method = dto.Method;
        entity.No = dto.No;
        entity.Date = dto.Date;
        entity.Bank = dto.Bank;

        return entity;
    }
}
