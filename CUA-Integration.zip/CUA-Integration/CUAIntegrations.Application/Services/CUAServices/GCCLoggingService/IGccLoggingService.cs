﻿using Microsoft.AspNetCore.Http;



namespace CUAIntegrations.Application.Services.CUAServices.GCCLoggingService
{
    public interface IGccLoggingService
    {
        Task<int> CreateGccLoggingObjectAsync(HttpContext context, Exception exception,string level);
    }

}
