﻿using CUA_GCC_Integration.Core.Exceptions.DataNotFound;
using CUA_GCC_Integration.Core.Helpers;
using CUAIntegrations.Persistence.DataAccess.ADO.NET;
using MediatR;
using Microsoft.AspNetCore.Http;

namespace CUAIntegrations.Application.Features.V1.Queries.CUA.CustomsDeclarations
{
    public class GetOutBoundedCustomsDeclarationHandler
        : IRequestHandler<GetOutBoundedCustomsDeclarationQuery, OutBoundedCustomsDeclarationResponse>
    {
        private readonly ICUADataAccessDataAccess _dataAccessService;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public GetOutBoundedCustomsDeclarationHandler(
            ICUADataAccessDataAccess dataAccessService,
            IHttpContextAccessor httpContextAccessor)
        {
            _dataAccessService = dataAccessService;
            _httpContextAccessor = httpContextAccessor;
        }

        public async Task<OutBoundedCustomsDeclarationResponse> Handle(
            GetOutBoundedCustomsDeclarationQuery request,
            CancellationToken cancellationToken)
        {
            var response = new OutBoundedCustomsDeclarationResponse();
            var requestingCountryCode = _httpContextAccessor.HttpContext.Request.Headers[RequestHeadersConstants.X_Client_ID].ToString();

            var issuingCountryCode = ApplicationClientsConstants.Kuwait;
            var declarationId = await _dataAccessService.GetDeclarationIdAsync(
                request.DeclarationNumber,
                request.DeclarationType,
                request.Year,
                request.Port,
                issuingCountryCode,
                requestingCountryCode
            );

            //var declarationId = "14190986"; for test only 
            if (string.IsNullOrWhiteSpace(declarationId))
                throw new DeclarationNotFoundException();

            var declaration = await _dataAccessService.GetDeclarationBayanPrintPreviewAsync(declarationId);

            if (declaration is null)
                throw new DeclarationNotFoundException();

            var declarationResult = CustomsDeclarationMapper.ModelToDTO(declaration);

            response.CustomsDeclarationEntity = declarationResult;

            return response;
        }
    }
}
