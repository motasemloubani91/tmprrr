﻿namespace CUAIntegrations.Kernel.Core.Logging
{
    public interface IRequestLogger
    {
        void LogInformation(string message, params object?[]? propertyValues);
        void LogException(Exception exception, string message = "", params object?[]? propertyValues);
    }
}
